data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition
  region     = data.aws_region.current.region

  glue_resources = concat(
    ["arn:${local.partition}:glue:${local.region}:${local.account_id}:catalog"],
    [for database in sort(keys(var.glue_tables)) : "arn:${local.partition}:glue:${local.region}:${local.account_id}:database/${database}"],
    flatten([
      for database, tables in var.glue_tables : [
        for table in sort(tolist(tables)) : "arn:${local.partition}:glue:${local.region}:${local.account_id}:table/${database}/${table}"
      ]
    ])
  )

  bucket_arns    = [for name in sort(tolist(var.s3_bucket_names)) : "arn:${local.partition}:s3:::${name}"]
  object_arns    = [for arn in local.bucket_arns : "${arn}/*"]
  log_group_name = "/aws/kinesisfirehose/${var.stream_name}"
  log_group_arn  = "arn:${local.partition}:logs:${local.region}:${local.account_id}:log-group:${local.log_group_name}"

  statements = concat(
    [
      {
        Sid      = "GlueIcebergTableAccess"
        Effect   = "Allow"
        Action   = ["glue:GetDatabase", "glue:GetTable", "glue:GetTableVersion", "glue:GetTableVersions", "glue:UpdateTable"]
        Resource = local.glue_resources
      },
      {
        Sid      = "S3BucketAccess"
        Effect   = "Allow"
        Action   = ["s3:GetBucketLocation", "s3:ListBucket", "s3:ListBucketMultipartUploads"]
        Resource = local.bucket_arns
      },
      {
        Sid      = "S3ObjectAccess"
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:AbortMultipartUpload"]
        Resource = local.object_arns
      },
      {
        Sid      = "FirehoseLogging"
        Effect   = "Allow"
        Action   = ["logs:PutLogEvents"]
        Resource = ["${local.log_group_arn}:log-stream:DestinationDelivery", "${local.log_group_arn}:log-stream:BackupDelivery"]
      }
    ],
    length(var.s3_kms_key_arns) > 0 ? [
      {
        Sid      = "S3KmsEncryption"
        Effect   = "Allow"
        Action   = ["kms:GenerateDataKey", "kms:Decrypt"]
        Resource = sort(tolist(var.s3_kms_key_arns))
        Condition = {
          StringEquals = {
            "kms:ViaService" = "s3.${local.region}.${data.aws_partition.current.dns_suffix}"
          }
          StringLike = {
            "kms:EncryptionContext:aws:s3:arn" = concat(local.bucket_arns, local.object_arns)
          }
        }
      }
    ] : [],
    var.enable_lakeformation ? [
      {
        Sid      = "LakeFormationDataAccess"
        Effect   = "Allow"
        Action   = ["lakeformation:GetDataAccess"]
        Resource = ["*"]
      }
    ] : []
  )
}

resource "aws_iam_role" "this" {
  name                 = var.role_name
  path                 = var.iam_path
  description          = "Amazon Data Firehose delivery role for existing Glue Iceberg tables."
  permissions_boundary = var.permissions_boundary_arn
  tags                 = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "firehose.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  lifecycle {
    precondition {
      condition     = local.account_id == var.expected_account_id
      error_message = "AWS credentials point to a different account than expected_account_id."
    }
  }
}

resource "aws_iam_policy" "this" {
  name        = var.policy_name
  path        = var.iam_path
  description = "Scoped Glue, S3 and logging permissions for Firehose Iceberg delivery."
  policy      = jsonencode({ Version = "2012-10-17", Statement = local.statements })
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "this" {
  role       = aws_iam_role.this.name
  policy_arn = aws_iam_policy.this.arn
}

resource "aws_cloudwatch_log_group" "this" {
  count             = var.create_log_group ? 1 : 0
  name              = local.log_group_name
  retention_in_days = var.log_retention_days
  tags              = var.tags
}

resource "aws_cloudwatch_log_stream" "this" {
  for_each       = var.create_log_group ? toset(["DestinationDelivery", "BackupDelivery"]) : toset([])
  name           = each.value
  log_group_name = aws_cloudwatch_log_group.this[0].name
}
