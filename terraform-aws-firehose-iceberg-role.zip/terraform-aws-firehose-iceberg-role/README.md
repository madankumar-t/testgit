# Terraform AWS Firehose Iceberg IAM role

Reusable module for a **Direct PUT → existing Glue Iceberg table in a general-purpose S3 bucket** delivery role. Creates an IAM service role, a customer-managed IAM policy and its attachment. Optionally creates a CloudWatch log group and delivery log streams.

Does not create the Firehose stream, Glue database/table, S3 buckets, KMS keys, Lake Formation grants, producer permissions or an application Pod Identity association. It is not a module for the separate Amazon S3 Tables service (`s3tables`).

## Repository layout

```text
terraform-aws-firehose-iceberg-role/
├── main.tf
├── variables.tf
├── outputs.tf
├── versions.tf
├── README.md
├── examples/gps-dev/main.tf
├── tests/policy.tftest.hcl
└── .github/workflows/terraform.yml
```

## GPS dev example

The runnable example in `examples/gps-dev` uses:

| Setting | Value |
| --- | --- |
| Account | `089931949779` |
| Region | `us-east-2` |
| Role | `dcli-gps-PUT-CAH-DEV-iam-role` |
| Managed policy | `dcli-gps-PUT-CAH-DEV-iam-policy` |
| Glue database/table | `gps_warehouse.customer_association_history` |
| Existing bucket | `dcli-gps-customer-association-history-dev` |
| Stream name for logging | `PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY` |

Requirements: Terraform >= 1.6 and < 2.0, AWS provider >= 6.0 and < 7.0, and AWS credentials for the target account. Mock tests require Terraform >= 1.7. CI uses 1.9.8. No static AWS access keys belong in this repository.

```bash
cd examples/gps-dev
aws sts get-caller-identity
terraform init
terraform fmt -check -recursive ../..
terraform validate
terraform plan -out=gps-dev.tfplan
terraform apply gps-dev.tfplan
terraform output -raw firehose_role_arn
```

Use a named AWS profile through `AWS_PROFILE` if running locally, or your existing AWS role integration in CI/Spacelift. The example provider allows only account `089931949779`; the module also checks `expected_account_id` before creating the role.

If the role/policy or log group already exists, follow **Import existing resources** before planning an apply. Run mock tests without AWS access from the repository root:

```bash
terraform init -backend=false
terraform test
```

## Use from another GitHub repository

Upload this directory's contents to your own GitHub repository and create a release tag such as `v1.0.0`. Replace `YOUR_ORG` below with your actual organization; this is a source template, not a published repository.

```hcl
provider "aws" {
  region              = "us-east-2"
  allowed_account_ids = ["089931949779"]
}

module "firehose_role" {
  source = "git::https://github.com/YOUR_ORG/terraform-aws-firehose-iceberg-role.git?ref=v1.0.0"

  role_name           = "dcli-gps-PUT-CAH-DEV-iam-role"
  policy_name         = "dcli-gps-PUT-CAH-DEV-iam-policy"
  expected_account_id = "089931949779"
  stream_name         = "PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY"

  glue_tables = {
    gps_warehouse = ["customer_association_history"]
  }
  s3_bucket_names   = ["dcli-gps-customer-association-history-dev"]
  create_log_group = true

  tags = {
    Project     = "GPS"
    Environment = "dev"
    ManagedBy   = "Terraform"
  }
}
```

Multiple tables are supported by adding names under an existing database or additional map entries. Add each table's actual data/metadata buckets and the backup bucket to `s3_bucket_names`. Glue catalog and bucket region are assumed to match the configured provider; cross-account/cross-region catalog access is outside this module's scope.

## Inputs

| Input | Type | Default | Purpose |
| --- | --- | --- | --- |
| `role_name` | string | required | IAM role name |
| `policy_name` | string | required | Customer-managed policy name |
| `expected_account_id` | string | required | Deployment account guard |
| `glue_tables` | map(set(string)) | required | Databases and explicit existing tables |
| `s3_bucket_names` | set(string) | required | Table and error/backup buckets |
| `stream_name` | string | required | Scopes the log group name |
| `create_log_group` | bool | false | Creates log group and two log streams |
| `log_retention_days` | number | 30 | Retention for created log group |
| `s3_kms_key_arns` | set(string) | [] | Optional S3 encryption key ARNs |
| `enable_lakeformation` | bool | false | Adds IAM credential-vending permission only |
| `permissions_boundary_arn` | string | null | Optional role permissions boundary |
| `iam_path` | string | `/` | Role and managed policy path |
| `tags` | map(string) | {} | Resource tags |

## Outputs

`role_name`, `role_arn`, `policy_arn`, `policy_json`, `log_group_name`.

When another Terraform module creates the Firehose stream, use `module.firehose_role.role_arn` as its delivery role ARN. The role output depends on policy attachment. If it also uses the log resources created here, add `depends_on = [module.firehose_role]` to the Firehose resource/module to ensure logging resources exist first. IAM propagation can still take a short time.

## Permissions and operation

* Trust is restricted to the Firehose service principal, following AWS's documented service-role trust policy. Application pods do not assume this delivery role.
* Glue access includes `GetDatabase`, table metadata reads and `UpdateTable` for only the configured catalog/database/table ARNs. Table auto-creation and schema-evolution permissions are not included; use existing tables with those optional features disabled.
* Bucket listing/location and object read/write/multipart permissions are restricted to the configured buckets. `DeleteObject` is included for cleanup, consistent with the preceding role policy; it is not required merely to represent an Iceberg row deletion. This grants bucket-wide object access, so use dedicated buckets.
* CloudWatch allows `PutLogEvents` only to `DestinationDelivery` and `BackupDelivery` in `/aws/kinesisfirehose/<stream_name>`. The delivery role does not create log resources. Set `create_log_group = true`, import them, or provision them separately.
* Optional KMS permissions allow `GenerateDataKey` and `Decrypt` only on supplied key ARNs, via S3, with encryption context restricted to the configured buckets/objects. Both bucket-level contexts (S3 Bucket Keys) and object contexts are covered. KMS key policies must also permit this role. KMS encryption for the Firehose stream itself or for CloudWatch logs is outside scope.
* `enable_lakeformation = true` adds `lakeformation:GetDataAccess` on `*`, as required for this non-resource-scoped API. It does not grant database/table access in Lake Formation; configure the appropriate grants separately if your table is governed there.
* No Kafka, Kinesis source or Lambda transformation permissions are included because the selected source is Direct PUT without transformation. Producers need separate `firehose:PutRecord`/`firehose:PutRecordBatch` permissions on the actual stream.

## Configure Firehose after apply

1. Choose Direct PUT and Apache Iceberg Tables; use the stream name configured above.
2. Select the current Glue account, Ohio region, database `gps_warehouse` and table `customer_association_history`; configure routing to that single table. The existing table must be a supported Iceberg V2 table.
3. Under Permissions choose the existing role `dcli-gps-PUT-CAH-DEV-iam-role`.
4. For backup/errors use `dcli-gps-customer-association-history-dev` with a separate error prefix such as `firehose-errors/`, or add your chosen backup bucket to the module inputs.
5. Enable delivery logging using the log group output and the corresponding delivery streams. Keep names consistent if you rename the Firehose stream.
6. Create the stream and test with a record matching your actual table schema. Confirm Firehose delivery metrics, CloudWatch errors, S3 data/metadata and a query through your existing Athena setup.

## Import existing resources

The policy resource is a **customer-managed policy**, not an inline role policy. These commands assume the default IAM path `/`. Use the real ARN if you used a different path. Run from `examples/gps-dev` with the correct AWS account credentials:

```bash
terraform init
terraform import 'module.firehose_role.aws_iam_role.this' 'dcli-gps-PUT-CAH-DEV-iam-role'
terraform import 'module.firehose_role.aws_iam_policy.this' 'arn:aws:iam::089931949779:policy/dcli-gps-PUT-CAH-DEV-iam-policy'
terraform import 'module.firehose_role.aws_iam_role_policy_attachment.this' 'dcli-gps-PUT-CAH-DEV-iam-role/arn:aws:iam::089931949779:policy/dcli-gps-PUT-CAH-DEV-iam-policy'
terraform plan
```

If the named policy exists only as an **inline policy** under the role, it cannot be imported as `aws_iam_policy`. Import the role, let this module create and attach the managed policy, review/test effective access, then remove the duplicate old inline policy through your normal change process. Until removed, that inline policy can grant additional permissions; this module does not manage or delete it or other existing attachments.

If logs already exist and `create_log_group = true`, import them too before apply:

```bash
terraform import 'module.firehose_role.aws_cloudwatch_log_group.this[0]' '/aws/kinesisfirehose/PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY'
terraform import 'module.firehose_role.aws_cloudwatch_log_stream.this["DestinationDelivery"]' '/aws/kinesisfirehose/PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY:DestinationDelivery'
terraform import 'module.firehose_role.aws_cloudwatch_log_stream.this["BackupDelivery"]' '/aws/kinesisfirehose/PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY:BackupDelivery'
terraform plan
```

Alternatively set `create_log_group = false` to leave existing logs unmanaged. Review imported-resource diffs before applying: Terraform will reconcile trust, permissions, tags and configured log retention.

## GitHub and Spacelift

GitHub Actions performs formatting, init, validation and mocked policy tests without AWS credentials. It does not plan against AWS or apply changes. The workflow uses tagged upstream actions; pin their approved commit SHAs if required by your organization.

For Spacelift, connect this repository, set project root to `examples/gps-dev`, choose Terraform >= 1.7 and < 2.0 (1.9.8 matches CI), and attach your existing AWS integration for account `089931949779`. Leave approvals and state management to your existing stack configuration. The runtime identity needs IAM role/policy/attachment management, relevant IAM read/tag operations and CloudWatch log management if enabled. The delivery role's permissions are separate from Terraform's deployment permissions. Never configure this module to assume its own Firehose delivery role.

For local/shared deployments configure your organization's remote Terraform backend in the example/root configuration. Commit root configuration dependency lock files after reviewing provider selections. Do not commit state files, saved plans or credentials. This module does not configure an S3 backend or create an OIDC deployment role.

## Validation status for this package

`terraform fmt -check -recursive` passed using Terraform 1.9.8. Full `terraform validate` and the included mocked tests could not complete in the authoring environment because the installed AWS provider had checksum/loading failures. No AWS plan or apply was performed. Run the supplied GitHub workflow or the local commands above with a fresh, verified provider installation before deployment. Generated authoring-environment provider caches, state and lock files are not included in the archive.

## References

* [AWS Firehose access policies and service trust](https://docs.aws.amazon.com/firehose/latest/dev/controlling-access.html)
* [AWS Firehose Iceberg prerequisites](https://docs.aws.amazon.com/firehose/latest/dev/apache-iceberg-prereq.html)
* [AWS provider IAM role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role)

