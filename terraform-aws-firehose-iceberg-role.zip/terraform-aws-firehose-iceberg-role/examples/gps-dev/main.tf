terraform {
  required_version = ">= 1.6.0, < 2.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0, < 7.0"
    }
  }
}

provider "aws" {
  region              = "us-east-2"
  allowed_account_ids = ["089931949779"]
}

module "firehose_role" {
  source = "../.."

  role_name           = "dcli-gps-PUT-CAH-DEV-iam-role"
  policy_name         = "dcli-gps-PUT-CAH-DEV-iam-policy"
  expected_account_id = "089931949779"
  stream_name         = "PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY"

  glue_tables = {
    gps_warehouse = ["customer_association_history"]
  }

  # Include a different backup/error bucket here too if you use one.
  s3_bucket_names = ["dcli-gps-customer-association-history-dev"]

  # Set false when these logging resources already exist outside Terraform.
  create_log_group   = true
  log_retention_days = 30

  # For SSE-KMS, supply actual key ARNs and grant this role access in key policies.
  s3_kms_key_arns = []

  tags = {
    Project     = "GPS"
    Environment = "dev"
    ManagedBy   = "Terraform"
  }
}

output "firehose_role_arn" {
  value = module.firehose_role.role_arn
}

output "firehose_log_group_name" {
  value = module.firehose_role.log_group_name
}

output "firehose_policy_json" {
  value = module.firehose_role.policy_json
}
