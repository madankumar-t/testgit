mock_provider "aws" {
  mock_data "aws_caller_identity" {
    defaults = {
      account_id = "089931949779"
      arn        = "arn:aws:iam::089931949779:user/test"
      user_id    = "test"
    }
  }
  mock_data "aws_partition" {
    defaults = {
      partition  = "aws"
      dns_suffix = "amazonaws.com"
    }
  }
  mock_data "aws_region" {
    defaults = {
      region = "us-east-2"
      name   = "us-east-2"
    }
  }
}

variables {
  role_name           = "dcli-gps-PUT-CAH-DEV-iam-role"
  policy_name         = "dcli-gps-PUT-CAH-DEV-iam-policy"
  expected_account_id = "089931949779"
  stream_name         = "PUT-ICEBERG-CUSTOMER-ASSOCIATION-HISTORY"
  glue_tables         = { gps_warehouse = ["customer_association_history"] }
  s3_bucket_names     = ["dcli-gps-customer-association-history-dev"]
}

run "scoped_default_policy" {
  command = plan
  assert {
    condition = (
      length(jsondecode(aws_iam_policy.this.policy).Statement) == 4 &&
      contains(jsondecode(aws_iam_policy.this.policy).Statement[0].Action, "glue:UpdateTable") &&
      contains(jsondecode(aws_iam_policy.this.policy).Statement[0].Resource, "arn:aws:glue:us-east-2:089931949779:table/gps_warehouse/customer_association_history") &&
      !contains(jsondecode(aws_iam_policy.this.policy).Statement[0].Resource, "*") &&
      jsondecode(aws_iam_role.this.assume_role_policy).Statement[0].Principal.Service == "firehose.amazonaws.com" &&
      length(aws_cloudwatch_log_group.this) == 0
    )
    error_message = "Default policy must scope metadata updates to the configured table and trust only Firehose."
  }
}

run "optional_encryption_and_logging" {
  command = plan
  variables {
    create_log_group     = true
    enable_lakeformation = true
    s3_kms_key_arns      = ["arn:aws:kms:us-east-2:089931949779:key/11111111-2222-3333-4444-555555555555"]
  }
  assert {
    condition = (
      length(jsondecode(aws_iam_policy.this.policy).Statement) == 6 &&
      jsondecode(aws_iam_policy.this.policy).Statement[4].Condition.StringEquals["kms:ViaService"] == "s3.us-east-2.amazonaws.com" &&
      contains(jsondecode(aws_iam_policy.this.policy).Statement[4].Condition.StringLike["kms:EncryptionContext:aws:s3:arn"], "arn:aws:s3:::dcli-gps-customer-association-history-dev") &&
      length(aws_cloudwatch_log_stream.this) == 2
    )
    error_message = "Optional features must include constrained S3 KMS permissions, Lake Formation and both delivery logs."
  }
}

run "reject_wrong_account" {
  command = plan
  variables {
    expected_account_id = "111111111111"
  }
  expect_failures = [aws_iam_role.this]
}
