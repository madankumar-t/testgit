output "role_name" {
  description = "Delivery role name."
  value       = aws_iam_role.this.name
}

output "role_arn" {
  description = "Delivery role ARN; attachment is completed before dependent consumers use it."
  value       = aws_iam_role.this.arn
  depends_on  = [aws_iam_role_policy_attachment.this]
}

output "policy_arn" {
  description = "Customer-managed policy ARN."
  value       = aws_iam_policy.this.arn
}

output "policy_json" {
  description = "Rendered IAM permissions for review or IAM Access Analyzer validation."
  value       = aws_iam_policy.this.policy
}

output "log_group_name" {
  description = "CloudWatch log group to configure on the Firehose destination."
  value       = local.log_group_name
}
