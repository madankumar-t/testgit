variable "role_name" {
  description = "Name of the Firehose service role."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9_+=,.@-]{1,64}$", var.role_name))
    error_message = "role_name must be a valid IAM role name (1-64 characters)."
  }
}

variable "policy_name" {
  description = "Name of the customer-managed IAM policy attached to the role."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9_+=,.@-]{1,128}$", var.policy_name))
    error_message = "policy_name must be a valid IAM policy name (1-128 characters)."
  }
}

variable "expected_account_id" {
  description = "Expected deployment account. A mismatch fails the plan."
  type        = string
  validation {
    condition     = can(regex("^[0-9]{12}$", var.expected_account_id))
    error_message = "expected_account_id must contain 12 digits."
  }
}

variable "glue_tables" {
  description = "Existing Glue databases mapped to sets of existing Iceberg table names. Wildcards are not allowed."
  type        = map(set(string))
  validation {
    condition = length(var.glue_tables) > 0 && alltrue([
      for database, tables in var.glue_tables :
      can(regex("^[A-Za-z0-9_-]+$", database)) && length(tables) > 0 &&
      alltrue([for table in tables : can(regex("^[A-Za-z0-9_-]+$", table))])
    ])
    error_message = "Provide at least one database and table; names may contain letters, digits, underscores and hyphens."
  }
}

variable "s3_bucket_names" {
  description = "Existing general-purpose S3 buckets for table data/metadata and backup/errors. Grants access across each bucket."
  type        = set(string)
  validation {
    condition = length(var.s3_bucket_names) > 0 && alltrue([
      for name in var.s3_bucket_names : can(regex("^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$", name))
    ])
    error_message = "Provide existing bucket names, without s3://, paths or wildcards."
  }
}

variable "stream_name" {
  description = "Firehose stream name used to scope CloudWatch logging. Does not create a Firehose stream."
  type        = string
  validation {
    condition     = can(regex("^[A-Za-z0-9_.-]{1,64}$", var.stream_name))
    error_message = "stream_name must be a valid Firehose stream name (1-64 characters)."
  }
}

variable "create_log_group" {
  description = "Create the scoped CloudWatch log group and DestinationDelivery/BackupDelivery streams. False uses existing logging resources."
  type        = bool
  default     = false
}

variable "log_retention_days" {
  description = "Retention for a log group created by this module."
  type        = number
  default     = 30
  validation {
    condition     = contains([1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653], var.log_retention_days)
    error_message = "Choose a supported positive CloudWatch retention period."
  }
}

variable "s3_kms_key_arns" {
  description = "Optional customer-managed KMS key ARNs used by the configured S3 buckets. Key policies must also permit the role."
  type        = set(string)
  default     = []
  validation {
    condition     = alltrue([for arn in var.s3_kms_key_arns : can(regex("^arn:[^:]+:kms:[^:]+:[0-9]{12}:key/.+$", arn))])
    error_message = "Use KMS key ARNs, not aliases or wildcards."
  }
}

variable "enable_lakeformation" {
  description = "Add lakeformation:GetDataAccess. Lake Formation table/data-location grants must be configured separately."
  type        = bool
  default     = false
}

variable "permissions_boundary_arn" {
  description = "Optional permissions boundary for the IAM role."
  type        = string
  default     = null
}

variable "iam_path" {
  description = "IAM path for the role and managed policy."
  type        = string
  default     = "/"
}

variable "tags" {
  description = "Tags applied to supported resources."
  type        = map(string)
  default     = {}
}
