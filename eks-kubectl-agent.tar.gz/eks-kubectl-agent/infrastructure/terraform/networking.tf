# ---------------------------------------------------------------------------
# Networking — automatic mode detection
#
# BRING-YOUR-OWN (when vpc_subnet_ids AND vpc_security_group_ids are provided):
#   Terraform creates no VPC resources. Existing subnets and security groups
#   are used directly for Lambda ENI placement.
#   Use this when you already have a VPC with private subnets and network
#   connectivity (Transit Gateway / VPC Peering) to spoke account VPCs.
#
# AUTO-CREATE (when vpc_subnet_ids OR vpc_security_group_ids are empty):
#   Terraform automatically creates:
#     • VPC with DNS support
#     • 2 private subnets (Lambda ENIs, one per AZ)
#     • 1 public subnet + Internet Gateway
#     • NAT Gateway (Lambda outbound to public AWS APIs)
#     • Security Group (HTTPS 443 egress to spoke VPC CIDRs)
#     • VPC Gateway Endpoints: DynamoDB, S3  (free — no NAT cost)
#     • VPC Interface Endpoints: STS, EKS, EC2, ELB, AutoScaling, Logs
#       (only when create_vpc_endpoints = true — reduces NAT traffic)
#
# TGW ATTACHMENT (when existing_tgw_id is provided):
#   Attaches the central VPC to the specified Transit Gateway so Lambda
#   can reach private EKS API endpoints in spoke account VPCs.
#   Skip if the TGW attachment already exists or you use VPC Peering.
# ---------------------------------------------------------------------------

# ── AZ discovery ────────────────────────────────────────────────────────────
data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  # ── Auto-detect networking mode ─────────────────────────────────────────
  # true  → subnets or SGs not provided → Terraform creates VPC, subnets, SG
  # false → both subnets and SGs provided → reuse existing resources
  create_networking = length(var.vpc_subnet_ids) == 0 || length(var.vpc_security_group_ids) == 0

  # Auto-detect TGW attachment: attach when an existing TGW ID is supplied
  attach_to_tgw = var.existing_tgw_id != ""

  # Use explicit AZs if provided, otherwise auto-pick first 2 in the region
  azs = length(var.availability_zones) > 0 ? var.availability_zones : slice(
    data.aws_availability_zones.available.names, 0, 2
  )

  # Effective subnet + SG IDs for Lambda vpc_config — resolved from either
  # the newly created resources or the user-supplied existing IDs
  effective_subnet_ids = local.create_networking ? aws_subnet.private[*].id : var.vpc_subnet_ids
  effective_sg_ids     = local.create_networking ? [aws_security_group.lambda[0].id] : var.vpc_security_group_ids

  # VPC ID used for TGW attachment
  tgw_vpc_id = local.create_networking ? aws_vpc.central[0].id : var.existing_vpc_id

  # Spoke CIDRs for the Lambda SG egress rule; fall back to 0.0.0.0/0 if not set
  egress_cidrs = length(var.spoke_vpc_cidrs) > 0 ? var.spoke_vpc_cidrs : ["0.0.0.0/0"]
}

# ── Guard: TGW attachment requires VPC ID when using existing networking ─────
check "tgw_inputs" {
  assert {
    condition = (
      !local.attach_to_tgw ||
      (local.create_networking || var.existing_vpc_id != "")
    )
    error_message = "When existing_tgw_id is set and vpc_subnet_ids are provided (existing VPC mode), existing_vpc_id is also required for the TGW attachment."
  }
}

# ============================================================================
# Resources created ONLY when create_networking = true
# ============================================================================

# ── VPC ─────────────────────────────────────────────────────────────────────
resource "aws_vpc" "central" {
  count                = local.create_networking ? 1 : 0
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags                 = { Name = "${local.prefix}-vpc" }
}

# ── Private subnets (Lambda ENIs) ───────────────────────────────────────────
resource "aws_subnet" "private" {
  count             = local.create_networking ? length(local.azs) : 0
  vpc_id            = aws_vpc.central[0].id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, count.index + 10)
  availability_zone = local.azs[count.index]
  tags              = { Name = "${local.prefix}-private-${local.azs[count.index]}" }
}

# ── Public subnet (NAT Gateway) ─────────────────────────────────────────────
resource "aws_subnet" "public" {
  count                   = local.create_networking ? 1 : 0
  vpc_id                  = aws_vpc.central[0].id
  cidr_block              = cidrsubnet(var.vpc_cidr, 8, 0)
  availability_zone       = local.azs[0]
  map_public_ip_on_launch = false
  tags                    = { Name = "${local.prefix}-public" }
}

# ── Internet Gateway ─────────────────────────────────────────────────────────
resource "aws_internet_gateway" "main" {
  count  = local.create_networking ? 1 : 0
  vpc_id = aws_vpc.central[0].id
  tags   = { Name = "${local.prefix}-igw" }
}

# ── NAT Gateway ──────────────────────────────────────────────────────────────
resource "aws_eip" "nat" {
  count  = local.create_networking ? 1 : 0
  domain = "vpc"
  tags   = { Name = "${local.prefix}-nat-eip" }
}

resource "aws_nat_gateway" "main" {
  count         = local.create_networking ? 1 : 0
  allocation_id = aws_eip.nat[0].id
  subnet_id     = aws_subnet.public[0].id
  depends_on    = [aws_internet_gateway.main]
  tags          = { Name = "${local.prefix}-nat" }
}

# ── Route tables ─────────────────────────────────────────────────────────────
resource "aws_route_table" "public" {
  count  = local.create_networking ? 1 : 0
  vpc_id = aws_vpc.central[0].id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main[0].id
  }
  tags = { Name = "${local.prefix}-rt-public" }
}

resource "aws_route_table" "private" {
  count  = local.create_networking ? 1 : 0
  vpc_id = aws_vpc.central[0].id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.main[0].id
  }
  tags = { Name = "${local.prefix}-rt-private" }
}

resource "aws_route_table_association" "public" {
  count          = local.create_networking ? 1 : 0
  subnet_id      = aws_subnet.public[0].id
  route_table_id = aws_route_table.public[0].id
}

resource "aws_route_table_association" "private" {
  count          = local.create_networking ? length(local.azs) : 0
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private[0].id
}

# ── Lambda Security Group ─────────────────────────────────────────────────────
resource "aws_security_group" "lambda" {
  count       = local.create_networking ? 1 : 0
  name        = "${local.prefix}-lambda-sg"
  description = "EKS Agent Lambda — HTTPS egress to spoke VPCs and AWS APIs"
  vpc_id      = aws_vpc.central[0].id

  dynamic "egress" {
    for_each = local.egress_cidrs
    content {
      from_port   = 443
      to_port     = 443
      protocol    = "tcp"
      cidr_blocks = [egress.value]
      description = "HTTPS to spoke VPCs / AWS APIs"
    }
  }

  tags = { Name = "${local.prefix}-lambda-sg" }
}

# ── VPC Endpoints ─────────────────────────────────────────────────────────────

# Gateway endpoints are free and route traffic internally without leaving AWS
resource "aws_vpc_endpoint" "dynamodb" {
  count             = local.create_networking && var.create_vpc_endpoints ? 1 : 0
  vpc_id            = aws_vpc.central[0].id
  service_name      = "com.amazonaws.${var.aws_region}.dynamodb"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = [aws_route_table.private[0].id]
  tags              = { Name = "${local.prefix}-ep-dynamodb" }
}

resource "aws_vpc_endpoint" "s3" {
  count             = local.create_networking && var.create_vpc_endpoints ? 1 : 0
  vpc_id            = aws_vpc.central[0].id
  service_name      = "com.amazonaws.${var.aws_region}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = [aws_route_table.private[0].id]
  tags              = { Name = "${local.prefix}-ep-s3" }
}

# Interface endpoints keep AWS API calls inside the VPC (reduces NAT traffic)
locals {
  interface_endpoints = local.create_networking && var.create_vpc_endpoints ? {
    sts                  = "com.amazonaws.${var.aws_region}.sts"
    eks                  = "com.amazonaws.${var.aws_region}.eks"
    ec2                  = "com.amazonaws.${var.aws_region}.ec2"
    elasticloadbalancing = "com.amazonaws.${var.aws_region}.elasticloadbalancing"
    autoscaling          = "com.amazonaws.${var.aws_region}.autoscaling"
    logs                 = "com.amazonaws.${var.aws_region}.logs"
  } : {}
}

resource "aws_vpc_endpoint" "interface" {
  for_each            = local.interface_endpoints
  vpc_id              = aws_vpc.central[0].id
  service_name        = each.value
  vpc_endpoint_type   = "Interface"
  subnet_ids          = aws_subnet.private[*].id
  security_group_ids  = [aws_security_group.lambda[0].id]
  private_dns_enabled = true
  tags                = { Name = "${local.prefix}-ep-${each.key}" }
}

# ============================================================================
# Optional TGW attachment — works in BOTH modes (existing or new VPC)
# Use this only if the attachment does NOT already exist.
# ============================================================================

resource "aws_ec2_transit_gateway_vpc_attachment" "central" {
  count              = local.attach_to_tgw ? 1 : 0
  transit_gateway_id = var.existing_tgw_id
  vpc_id             = local.tgw_vpc_id
  subnet_ids         = local.effective_subnet_ids
  tags               = { Name = "${local.prefix}-tgw-attachment" }
}
