#!/usr/bin/env python3
"""
Build the Lambda shared layer.

Called by Terraform's null_resource when requirements.txt or shared/ changes:
    python scripts/build_layer.py <backend_dir>

Produces:
    <backend_dir>/.layer_build/python/   ← layer content
    (Terraform's archive_file then zips this into .layer.zip)

Cross-platform: runs on Linux, macOS, Windows, and WSL.
The --platform manylinux2014_aarch64 flag ensures binary extensions
are compatible with the arm64 Lambda runtime regardless of the build host.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys


def main() -> None:
    backend_dir = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(__file__)))
    build_dir = os.path.join(backend_dir, ".layer_build")
    python_dir = os.path.join(build_dir, "python")
    requirements = os.path.join(backend_dir, "requirements.txt")
    shared_src = os.path.join(backend_dir, "shared")

    print(f"[build_layer] backend_dir  = {backend_dir}")
    print(f"[build_layer] build output = {build_dir}")

    # Clean previous build
    shutil.rmtree(build_dir, ignore_errors=True)
    os.makedirs(python_dir, exist_ok=True)

    # Install Python dependencies for arm64 Lambda (manylinux2014_aarch64)
    print("[build_layer] Running pip install...")
    subprocess.run(
        [
            sys.executable, "-m", "pip", "install",
            "--requirement", requirements,
            "--platform", "manylinux2014_aarch64",
            "--only-binary=:all:",
            "--python-version", "3.12",
            "--target", python_dir,
            "--upgrade",
        ],
        check=True,
    )

    # Copy shared modules into the layer so Lambda functions can import them
    shared_dest = os.path.join(python_dir, "shared")
    print(f"[build_layer] Copying shared/ → {shared_dest}")
    shutil.copytree(shared_src, shared_dest)

    print("[build_layer] Done. Layer content ready at:", build_dir)


if __name__ == "__main__":
    main()
