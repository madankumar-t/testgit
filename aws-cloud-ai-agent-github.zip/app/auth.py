from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer
import jwt
from app.config import JWT_SECRET, JWT_ALGO

security = HTTPBearer()

def verify_token(creds=Depends(security)):
    try:
        return jwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALGO])
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")