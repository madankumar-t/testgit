import boto3
def get_network_costs():
    ce = boto3.client("ce")
    return ce.get_cost_and_usage(
        TimePeriod={"Start":"2025-01-01","End":"2025-01-31"},
        Granularity="MONTHLY",
        Metrics=["UnblendedCost"],
        GroupBy=[{"Type":"DIMENSION","Key":"SERVICE"}]
    )