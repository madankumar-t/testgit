def build_topology(data):
    nodes, edges = [], []
    for acct, regions in data.items():
        for region, svcs in regions.items():
            if "vpc" in svcs:
                for v in svcs["vpc"]["vpcs"]:
                    nodes.append({"id": v["VpcId"], "type": "vpc", "account": acct})
                for s in svcs["vpc"]["subnets"]:
                    edges.append({"from": s["VpcId"], "to": s["SubnetId"]})
    return {"nodes": nodes, "edges": edges}