def cis_checks(data):
    findings = []
    for acct, regions in data.items():
        for region, svcs in regions.items():
            if "ec2" in svcs:
                for i in svcs["ec2"]["instances"]:
                    if i.get("PublicIpAddress"):
                        findings.append({
                            "control": "CIS-EC2-1",
                            "severity": "HIGH",
                            "account": acct,
                            "region": region,
                            "resource": i["InstanceId"],
                            "msg": "EC2 instance has public IP"
                        })
    return findings