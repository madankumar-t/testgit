def extract_intent(prompt: str):
    services = [s for s in ["ec2","vpc","s3","iam","rds","eks"] if s in prompt.lower()]
    return {"services": services or ["vpc"]}