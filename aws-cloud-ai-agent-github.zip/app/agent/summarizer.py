def summarize(data):
    return {
        acct: {
            region: {
                svc: {k: len(v) for k,v in res.items()}
                for svc,res in svcs.items()
            }
            for region, svcs in regions.items()
        }
        for acct, regions in data.items()
    }