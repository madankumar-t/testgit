from app.agent.intent import extract_intent
from app.aws.router import route_request
from app.agent.summarizer import summarize
from app.analysis.topology import build_topology
from app.analysis.security import cis_checks
from app.analysis.cost import get_network_costs
from app.analysis.opa import evaluate_policies

def run_agent(prompt: str):
    intent = extract_intent(prompt)
    data = route_request(intent)
    return {
        "summary": summarize(data),
        "topology": build_topology(data),
        "cis_findings": cis_checks(data),
        "policy_violations": evaluate_policies(data),
        "network_costs": get_network_costs()
    }