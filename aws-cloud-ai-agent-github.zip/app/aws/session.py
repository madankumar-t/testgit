import boto3
from app.config import ORG_ROLE_NAME

def assume_role(account_id, region):
    sts = boto3.client("sts")
    role_arn = f"arn:aws:iam::{account_id}:role/{ORG_ROLE_NAME}"
    creds = sts.assume_role(RoleArn=role_arn, RoleSessionName="ai-agent")["Credentials"]
    return boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
        region_name=region
    )