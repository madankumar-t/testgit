import boto3
def list_accounts():
    org = boto3.client("organizations")
    return [a["Id"] for a in org.list_accounts()["Accounts"]]