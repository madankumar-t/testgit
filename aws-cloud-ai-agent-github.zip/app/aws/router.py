from concurrent.futures import ThreadPoolExecutor, as_completed
from app.aws.org import list_accounts
from app.aws.regions import list_regions
from app.aws.session import assume_role
from app.config import MAX_WORKERS
from app.collectors import ec2, s3, iam, rds, eks
from app.collectors.vpc import collect_vpc

SERVICE_MAP = {
    "ec2": ec2.collect,
    "s3": s3.collect,
    "iam": iam.collect,
    "rds": rds.collect,
    "eks": eks.collect,
    "vpc": collect_vpc
}

def route_request(intent):
    results = {}
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as exe:
        futures = [
            exe.submit(run_collect, acct, region, svc)
            for acct in list_accounts()
            for region in list_regions()
            for svc in intent["services"]
        ]
        for f in as_completed(futures):
            acct, region, svc, data = f.result()
            results.setdefault(acct, {}).setdefault(region, {})[svc] = data
    return results

def run_collect(acct, region, svc):
    session = assume_role(acct, region)
    return acct, region, svc, SERVICE_MAP[svc](session)