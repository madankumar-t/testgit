from .vpc import vpcs
from .subnet import subnets
from .route_table import route_tables
from .igw import igws
from .nat import nat_gateways
from .nacl import nacls
from .endpoints import endpoints
from .peering import peerings
from .tgw import tgws

def collect_vpc(s):
    return {
        "vpcs": vpcs(s),
        "subnets": subnets(s),
        "route_tables": route_tables(s),
        "internet_gateways": igws(s),
        "nat_gateways": nat_gateways(s),
        "network_acls": nacls(s),
        "vpc_endpoints": endpoints(s),
        "vpc_peerings": peerings(s),
        "transit_gateways": tgws(s)
    }