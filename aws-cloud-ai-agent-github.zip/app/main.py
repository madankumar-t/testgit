from fastapi import FastAPI, Depends
from app.agent.agent import run_agent
from app.auth import verify_token

app = FastAPI(title="AWS Cloud AI Agent")

@app.post("/query")
def query(prompt: str, user=Depends(verify_token)):
    return run_agent(prompt)