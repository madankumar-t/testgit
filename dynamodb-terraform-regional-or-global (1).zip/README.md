# Terraform DynamoDB – Regional or Global Tables

This project allows you to create:
- REGIONAL DynamoDB tables (single region)
- GLOBAL DynamoDB tables (multi-region replication)

Controlled via:
table_mode = "REGIONAL" | "GLOBAL"

## Usage
terraform init
terraform apply
