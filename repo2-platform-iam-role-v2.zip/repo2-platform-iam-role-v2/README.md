
# Platform IAM Role Deployment

This repository:
1. Creates Spacelift stacks via stack-factory
2. Each stack deploys IAM role using Private Registry module

## Steps

1. Deploy stacks:
   cd stack-factory
   terraform init
   terraform apply

2. Stacks will automatically deploy module from:
   spacelift.io/<your-org>/cross-account-iam-role
