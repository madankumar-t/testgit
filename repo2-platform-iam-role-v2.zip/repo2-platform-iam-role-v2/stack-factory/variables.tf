
variable "api_key_id" {}
variable "api_key_secret" {}

variable "accounts" {
  description = "Accounts to create stacks for"
  type = map(object({
    aws_integration_id = string
  }))
}
