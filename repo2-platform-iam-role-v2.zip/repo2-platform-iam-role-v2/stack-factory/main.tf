
resource "spacelift_stack" "iam_role" {
  for_each = var.accounts

  name         = "iam-role-${each.key}"
  repository   = "your-org/repo2-platform-iam-role-v2"
  branch       = "main"
  project_root = "deployment"

  terraform_workflow_tool = "TERRAFORM_FOSS"

  labels = [
    "iam-role",
    each.key
  ]
}

resource "spacelift_aws_integration_attachment" "attach" {
  for_each = var.accounts

  stack_id       = spacelift_stack.iam_role[each.key].id
  integration_id = each.value.aws_integration_id

  read  = true
  write = true
}
