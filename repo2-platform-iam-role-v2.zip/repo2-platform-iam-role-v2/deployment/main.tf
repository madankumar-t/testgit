
module "iam_role" {
  source  = "spacelift.io/<your-org>/cross-account-iam-role"
  version = "0.1.0"

  role_name = "crossaccountrolewithsharedsvcs2"

  trusted_principals = [
    "arn:aws:iam::123456789012:role/ExampleRole"
  ]
}
