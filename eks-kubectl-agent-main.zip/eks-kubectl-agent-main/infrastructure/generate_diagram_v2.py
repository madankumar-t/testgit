"""
EKS Kubectl Agent — Architecture & Network Diagram (current setup)
Two panels side by side:
  LEFT  — Application Architecture (user → CloudFront → API GW → Lambda → DynamoDB → EKS)
  RIGHT — Network Topology (Central VPC, existing TGW/Peering, spoke VPCs)

Output: architecture_diagram_v2.jpg
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D
import matplotlib.patheffects as pe

OUT_PATH = os.path.join(os.path.dirname(__file__), "architecture_diagram_v2.jpg")

# ── Palette ─────────────────────────────────────────────────────────────────
BG      = "#F7F9FC"
NAVY    = "#0D1B4B"
CLOUD   = "#E3F2FD"
CLOUD_B = "#1565C0"
VPC_F   = "#E8F5E9"
VPC_B   = "#2E7D32"
SUBNET_F= "#F1F8E9"
SUBNET_B= "#558B2F"
MEMBER_F= "#FFF8E1"
MEMBER_B= "#E65100"
SPOKE_F = "#F3E5F5"
SPOKE_B = "#6A1B9A"

CF_C    = "#C2185B"
S3_C    = "#388E3C"
APIGW_C = "#7B1FA2"
LAMBDA_C= "#E65100"
DDB_C   = "#283593"
IAM_C   = "#00695C"
EKS_C   = "#BF360C"
TGW_C   = "#37474F"
NAT_C   = "#F57C00"
EP_C    = "#00838F"
TF_C    = "#5C4EE5"

WHITE   = "#FFFFFF"
TEXT_DK = "#212121"
TEXT_MD = "#546E7A"
TEXT_LT = "#90A4AE"
ARROW   = "#546E7A"
DASHED  = "#90A4AE"
GREEN_A = "#43A047"
ORANGE_A= "#F4511E"
BLUE_A  = "#1E88E5"

# ── Figure: two panels side-by-side ─────────────────────────────────────────
FW, FH = 42, 28
fig = plt.figure(figsize=(FW, FH), dpi=100)
fig.patch.set_facecolor(BG)

axL = fig.add_axes([0.0,  0.0,  0.505, 1.0])   # left panel  — app architecture
axR = fig.add_axes([0.505, 0.0, 0.495, 1.0])   # right panel — network topology

for ax in (axL, axR):
    ax.set_xlim(0, 21)
    ax.set_ylim(0, 28)
    ax.axis("off")
    ax.set_facecolor(BG)

# Vertical divider
fig.add_artist(plt.Line2D([0.505, 0.505], [0.02, 0.98],
                          transform=fig.transFigure,
                          color="#CFD8DC", lw=2.5))


# ═══════════════════════════════════════════════════════════════════════════
# SHARED DRAW HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def rbox(ax, x, y, w, h, fc, ec, lw=1.5, alpha=1.0, r=0.25, z=2, ls="-"):
    p = FancyBboxPatch((x, y), w, h,
                       boxstyle=f"round,pad=0,rounding_size={r}",
                       facecolor=fc, edgecolor=ec, linewidth=lw,
                       alpha=alpha, zorder=z, linestyle=ls)
    ax.add_patch(p)
    return p

def txt(ax, x, y, s, fs=9, fw="normal", color=TEXT_DK,
        ha="center", va="center", z=10, alpha=1.0, wrap=False):
    return ax.text(x, y, s, fontsize=fs, fontweight=fw, color=color,
                   ha=ha, va=va, zorder=z, alpha=alpha,
                   wrap=wrap, fontfamily="DejaVu Sans")

def svc_box(ax, x, y, w, h, line1, line2=None, line3=None,
            fc=LAMBDA_C, tc=WHITE, fs=9, z=5, r=0.2):
    rbox(ax, x, y, w, h, fc, WHITE, lw=0, z=z, r=r)
    lines = [l for l in [line1, line2, line3] if l]
    n = len(lines)
    step = h / (n + 1)
    for i, line in enumerate(lines):
        fsize = fs if i == 0 else fs - 1.5
        fwt   = "bold" if i == 0 else "normal"
        clr   = tc if i == 0 else (tc if tc == WHITE else TEXT_MD)
        alf   = 1.0 if i == 0 else 0.82
        ax.text(x + w/2, y + h - step*(i+1), line,
                fontsize=fsize, fontweight=fwt, color=clr, alpha=alf,
                ha="center", va="center", zorder=z+1)

def arrow(ax, x1, y1, x2, y2, color=ARROW, lw=1.6, style="->",
          label="", z=8, rad=0.0, ls="-"):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(
                    arrowstyle=style, color=color, lw=lw,
                    connectionstyle=f"arc3,rad={rad}",
                    linestyle=ls),
                zorder=z)
    if label:
        mx, my = (x1+x2)/2, (y1+y2)/2
        ax.text(mx, my, label, fontsize=7, color=color,
                ha="center", va="bottom", zorder=z+1)

def section_hdr(ax, x, y, w, title, subtitle=None, fc=NAVY, z=4):
    rbox(ax, x, y, w, 0.65 if subtitle else 0.5, fc, fc, lw=0, z=z, r=0.15)
    if subtitle:
        txt(ax, x+w/2, y+0.48, title,    fs=9.5, fw="bold", color=WHITE, z=z+1)
        txt(ax, x+w/2, y+0.17, subtitle, fs=7.5, color="#90CAF9", z=z+1)
    else:
        txt(ax, x+w/2, y+0.25, title, fs=9.5, fw="bold", color=WHITE, z=z+1)

def tag(ax, x, y, label, fc="#E3F2FD", ec=CLOUD_B, fs=7):
    rbox(ax, x, y, len(label)*0.13+0.3, 0.35, fc, ec, lw=1, z=12, r=0.12)
    txt(ax, x+(len(label)*0.13+0.3)/2, y+0.17, label, fs=fs, color=ec, z=13)

def badge(ax, x, y, label, fc=GREEN_A):
    w = len(label)*0.12 + 0.25
    rbox(ax, x, y, w, 0.3, fc, fc, lw=0, z=12, r=0.1)
    txt(ax, x+w/2, y+0.15, label, fs=6.5, fw="bold", color=WHITE, z=13)

def dashed_rect(ax, x, y, w, h, color=DASHED, lw=1.2, r=0.3, alpha=0.4):
    rbox(ax, x, y, w, h, "none", color, lw=lw, alpha=alpha, r=r, ls="--")

def note(ax, x, y, text, color=TEXT_LT):
    txt(ax, x, y, text, fs=7, color=color, ha="left", z=5)


# ═══════════════════════════════════════════════════════════════════════════
# LEFT PANEL — APPLICATION ARCHITECTURE
# ═══════════════════════════════════════════════════════════════════════════

ax = axL

# ── Panel title ─────────────────────────────────────────────────────────────
rbox(ax, 0, 26.8, 21, 1.2, NAVY, NAVY, lw=0, z=3, r=0)
txt(ax, 10.5, 27.55, "Application Architecture", fs=16, fw="bold", color=WHITE, z=5)
txt(ax, 10.5, 27.1,  "EKS Kubectl Agent  ·  Multi-Account  ·  Serverless Backend",
    fs=9, color="#90CAF9", z=5)

# ── 1. USER ─────────────────────────────────────────────────────────────────
section_hdr(ax, 0.4, 25.55, 20.2, "1  USER ACCESS")

rbox(ax, 1.0, 24.1, 3.5, 1.1, "#ECEFF1", TEXT_MD, lw=1.5, z=4, r=0.3)
txt(ax, 2.75, 24.85, "Browser / User", fs=10, fw="bold", z=6)
txt(ax, 2.75, 24.38, "Web UI  ·  HTTPS only", fs=8, color=TEXT_MD, z=6)

svc_box(ax, 6.5, 24.1, 5.5, 1.1, "CloudFront Distribution",
        "CDN + HTTPS termination", "Origin: S3  &  API Gateway",
        fc=CF_C, fs=9)
badge(ax, 6.55, 25.15, "Global")

svc_box(ax, 14.0, 24.1, 5.8, 1.1, "S3 Bucket (Frontend)",
        "Next.js 14 static export", "Immutable cache headers",
        fc=S3_C, fs=9)
badge(ax, 14.05, 25.15, "Static")

arrow(ax, 4.5,  24.65, 6.5,  24.65, color=BLUE_A, lw=2, label="HTTPS")
arrow(ax, 12.0, 24.95, 14.0, 24.65, color=S3_C,   lw=1.8, label="/* assets", rad=-0.2)

# ── 2. API GATEWAY ──────────────────────────────────────────────────────────
section_hdr(ax, 0.4, 23.1, 20.2, "2  API GATEWAY  (HTTP API v2)")

routes = [
    ("GET /api/v1/accounts",        APIGW_C),
    ("GET /api/v1/clusters",        APIGW_C),
    ("POST /api/v1/diagnose",       APIGW_C),
    ("GET /api/v1/diagnose/{id}",   APIGW_C),
    ("POST /api/v1/logs",           APIGW_C),
    ("POST /api/v1/fix/apply",      APIGW_C),
]
RX = [0.5, 3.85, 7.2, 10.55, 13.9, 17.25]
for i, ((route, color), rx) in enumerate(zip(routes, RX)):
    rbox(ax, rx, 21.95, 3.2, 0.85, color, WHITE, lw=0, z=4, r=0.15)
    txt(ax, rx+1.6, 22.58, route.split()[0], fs=6.5, fw="bold", color="#CE93D8", z=6)
    txt(ax, rx+1.6, 22.2,  route.split()[1], fs=8,   fw="bold", color=WHITE,     z=6)

arrow(ax, 9.5, 24.1, 9.5, 22.8, color=CF_C, lw=2, label="/api/* proxy")

# ── 3. LAMBDA FUNCTIONS ─────────────────────────────────────────────────────
section_hdr(ax, 0.4, 21.55, 20.2,
            "3  LAMBDA FUNCTIONS",
            "Python 3.12  ·  arm64  ·  VPC-attached  ·  Layer: kubernetes>=29, boto3>=1.34")

lambdas = [
    ("list_accounts",   "GET /accounts",    "Returns SPOKE_ACCOUNT_IDS"),
    ("list_clusters",   "GET /clusters",    "eks:ListClusters per account"),
    ("diagnose_start",  "POST /diagnose",   "Create job → invoke worker"),
    ("diagnose_status", "GET /diagnose/{id}","Read DynamoDB job record"),
    ("get_logs",        "POST /logs",       "Stream pod logs via k8s SDK"),
    ("apply_fix",       "POST /fix/apply",  "Allowlisted k8s mutations"),
    ("diagnose_worker", "Async / Event",    "Full diagnostic run (~14 min)"),
]
LW, LH, LG = 5.6, 1.05, 0.18
COLS = [0.45, 6.23, 12.01]
ROWS = [20.2, 18.9, 17.6]

for i, (name, sub1, sub2) in enumerate(lambdas):
    col = i % 3
    row = i // 3
    lx = COLS[col] if col < 3 else COLS[0]
    ly = ROWS[row] if row < 3 else ROWS[2] - 1.3
    if i == 6:  # last one spans slightly wider
        lx = 0.45
    svc_box(ax, lx, ly, LW, LH, f"λ  {name}", sub1, sub2,
            fc=LAMBDA_C, fs=9, z=5)

# Worker async arrow
arrow(ax, 5.75, 20.2+1.05/2, 5.75, 18.9+1.05,
      color=LAMBDA_C, lw=1.2, style="->", label="InvocationType=Event", rad=0.3)

arrow(ax, 10.5, 21.55, 10.5, 21.25, color=APIGW_C, lw=2)

# ── 4. DATA & CROSS-ACCOUNT FLOW ────────────────────────────────────────────
section_hdr(ax, 0.4, 17.25, 20.2, "4  DATA LAYER  &  CROSS-ACCOUNT FLOW")

# DynamoDB
svc_box(ax, 0.5, 14.5, 6.0, 2.45,
        "DynamoDB",
        "Table: eks-agent-jobs",
        "TTL 24h  ·  PAY_PER_REQUEST  ·  PITR",
        fc=DDB_C, fs=9.5, z=5)
txt(ax, 3.5, 14.3, "Partition key: job_id  |  Fields: status, findings, fixes, root_cause, logs",
    fs=7, color=TEXT_LT, ha="center", z=5)

arrow(ax, 6.5, 15.7, 7.8, 15.7, color=DDB_C, lw=1.8, label="put/get_item", style="<->")

# Cross-account steps
steps = [
    ("#1  sts:AssumeRole",      "Assume eks-agent-spoke-role",   "in target account",    7.8, 16.1),
    ("#2  EKS Bearer Token",    "STS pre-signed URL",            "signed with spoke creds", 13.9, 16.1),
    ("#3  Kubernetes API",      "k8s Python client",             "→ private EKS endpoint", 7.8, 14.65),
    ("#4  boto3 AWS calls",     "EKS / EC2 / ELB / IAM",        "read-only via spoke role", 13.9, 14.65),
]
for num, l1, l2, sx, sy in steps:
    rbox(ax, sx, sy, 5.8, 1.1, "#FFF3E0", "#FF8F00", lw=1.2, z=5, r=0.2)
    txt(ax, sx+2.9, sy+0.82, num, fs=7.5, fw="bold", color="#E65100", z=7)
    txt(ax, sx+2.9, sy+0.55, l1,  fs=9,   fw="bold", color=TEXT_DK,   z=7)
    txt(ax, sx+2.9, sy+0.25, l2,  fs=8,   color=TEXT_MD,              z=7)

arrow(ax, 13.7, 16.65, 13.9, 16.65, color="#FF8F00", lw=1.5)  # 1→2
arrow(ax, 13.9, 15.75, 13.7, 15.2,  color="#FF8F00", lw=1.5, rad=0.2)  # 2→3 wrap
arrow(ax, 13.6, 15.2,  13.9, 15.2,  color="#FF8F00", lw=1.5)  # 3→4

arrow(ax, 10.5, 17.25, 10.5, 17.2, color=LAMBDA_C, lw=2)

# ── 5. SPOKE ROLE DEPLOYMENT ─────────────────────────────────────────────────
section_hdr(ax, 0.4, 13.95, 20.2,
            "5  SPOKE ROLE DEPLOYMENT  (one-time, auto via terraform apply)")

svc_box(ax, 0.5, 11.3, 5.5, 2.3,
        "terraform apply",
        "deploy_spoke_roles.py",
        "Assumes OrganizationAccountAccessRole",
        fc=TF_C, fs=9, z=5)
txt(ax, 3.25, 11.1, "in each member account", fs=7.5, color=TEXT_MD, ha="center", z=5)

arrow(ax, 6.0, 12.4, 7.2, 12.4, color=TF_C, lw=1.8, label="CloudFormation deploy")

svc_box(ax, 7.2, 11.3, 5.6, 2.3,
        "spoke-role.yaml",
        "CloudFormation stack",
        "Creates eks-agent-spoke-role",
        fc=SPOKE_B, fs=9, z=5)
txt(ax, 10.0, 11.1, "in member account", fs=7.5, color=TEXT_MD, ha="center", z=5)

svc_box(ax, 14.0, 11.3, 6.5, 2.3,
        "eks-agent-spoke-role",
        "Permissions: EKS + EC2 + ELB",
        "IAM + ASG read-only",
        fc=IAM_C, fs=9, z=5)
txt(ax, 17.25, 11.1, "Trusted by central account  ·  Mapped in aws-auth / EKS access entry",
    fs=7.5, color=TEXT_MD, ha="center", z=5)

arrow(ax, 12.8, 12.45, 14.0, 12.45, color=SPOKE_B, lw=1.8)

# ── 6. TERRAFORM-MANAGED RESOURCES ──────────────────────────────────────────
section_hdr(ax, 0.4, 10.8, 20.2,
            "6  WHAT TERRAFORM MANAGES  vs  PRE-EXISTING INFRASTRUCTURE")

# Terraform creates box
rbox(ax, 0.5, 8.4, 9.5, 2.0, "#E8F5E9", GREEN_A, lw=1.8, z=4, r=0.25)
txt(ax, 5.25, 10.1, "Terraform Creates (terraform apply)", fs=9, fw="bold",
    color=GREEN_A, z=6)
items_tf = [
    "• Lambda (7 functions) + Layer",
    "• API Gateway + Routes + CORS",
    "• DynamoDB table",
    "• IAM roles (lambda-execution)",
    "• S3 bucket + CloudFront",
    "• Spoke roles in member accounts",
    "• Optional: VPC + Subnets + NAT",
]
for i, item in enumerate(items_tf):
    col = i // 4
    row = i % 4
    txt(ax, 0.8 + col*4.8, 9.75 - row*0.32, item,
        fs=8, color=TEXT_DK, ha="left", z=6)

# Pre-existing box
rbox(ax, 10.5, 8.4, 10.0, 2.0, "#FFF3E0", ORANGE_A, lw=1.8, z=4, r=0.25)
txt(ax, 15.5, 10.1, "You Provide (pre-existing)", fs=9, fw="bold",
    color=ORANGE_A, z=6)
items_pre = [
    "• VPC with private subnets",
    "• Transit Gateway (or VPC Peering)",
    "• TGW attachments to spoke VPCs",
    "• NAT Gateway / VPC Endpoints",
    "• Security Groups (HTTPS egress)",
    "• Route Tables to spoke CIDRs",
    "• OrganizationAccountAccessRole",
]
for i, item in enumerate(items_pre):
    col = i // 4
    row = i % 4
    txt(ax, 10.8 + col*5.0, 9.75 - row*0.32, item,
        fs=8, color=TEXT_DK, ha="left", z=6)

# ── 7. LEGEND ────────────────────────────────────────────────────────────────
section_hdr(ax, 0.4, 7.95, 20.2, "7  SERVICE LEGEND")

legend_entries = [
    (CF_C,     "CloudFront"),
    (S3_C,     "S3"),
    (APIGW_C,  "API Gateway"),
    (LAMBDA_C, "Lambda"),
    (DDB_C,    "DynamoDB"),
    (IAM_C,    "IAM / Spoke Role"),
    (TF_C,     "Terraform"),
    (SPOKE_B,  "CloudFormation"),
    (TGW_C,    "Transit Gateway"),
    (EKS_C,    "EKS Cluster"),
]
LGX = 0.5
LGY = 7.45
for i, (color, label) in enumerate(legend_entries):
    col = i % 5
    row = i // 5
    bx = LGX + col * 4.0
    by = LGY - row * 0.48
    rbox(ax, bx, by-0.05, 0.45, 0.35, color, color, lw=0, z=8, r=0.08)
    txt(ax, bx+0.6, by+0.12, label, fs=8.5, color=TEXT_DK, ha="left", z=9)

# ── Footer ───────────────────────────────────────────────────────────────────
rbox(ax, 0, 0, 21, 0.7, "#ECEFF1", "#90A4AE", lw=0, z=3, r=0)
txt(ax, 10.5, 0.37, "Default mode: create_networking=false  —  provide existing vpc_subnet_ids + vpc_security_group_ids in terraform.tfvars",
    fs=8, color=TEXT_MD, z=5)
txt(ax, 10.5, 0.1,  "Optional: create_networking=true creates VPC/NAT/Endpoints  |  attach_to_existing_tgw=true creates TGW attachment",
    fs=7.5, color=TEXT_LT, z=5)


# ═══════════════════════════════════════════════════════════════════════════
# RIGHT PANEL — NETWORK TOPOLOGY
# ═══════════════════════════════════════════════════════════════════════════

ax = axR

rbox(ax, 0, 26.8, 21, 1.2, "#263238", "#263238", lw=0, z=3, r=0)
txt(ax, 10.5, 27.55, "Network Topology", fs=16, fw="bold", color=WHITE, z=5)
txt(ax, 10.5, 27.1,  "VPC Layout  ·  Existing TGW / VPC Peering  ·  Spoke Account Connectivity",
    fs=9, color="#90CAF9", z=5)

# ── Internet user ───────────────────────────────────────────────────────────
section_hdr(ax, 0.4, 25.55, 20.2, "INTERNET", fc="#37474F")
rbox(ax, 1.5, 24.2, 4.0, 1.0, "#ECEFF1", TEXT_MD, lw=1.5, z=4, r=0.3)
txt(ax, 3.5, 24.87, "Browser / User", fs=9, fw="bold", z=6)
txt(ax, 3.5, 24.45, "Public Internet", fs=8, color=TEXT_MD, z=6)

svc_box(ax, 7.0, 24.2, 5.5, 1.0, "CloudFront  +  API GW",
        "Public HTTPS endpoints", fc=CF_C, fs=9.5, z=5)

arrow(ax, 5.5, 24.7, 7.0, 24.7, color=BLUE_A, lw=2, label="HTTPS 443")

# ── Central AWS account ──────────────────────────────────────────────────────
section_hdr(ax, 0.4, 23.55, 20.2,
            "CENTRAL AWS ACCOUNT  (master / management)",
            "Lambda + API GW + DynamoDB + S3 + CloudFront", fc=CLOUD_B)

# Account boundary
rbox(ax, 0.4, 9.0, 20.2, 14.2, CLOUD, CLOUD_B, lw=2.2, alpha=0.35, z=2, r=0.4)

# ── Central VPC ─────────────────────────────────────────────────────────────
rbox(ax, 0.8, 9.4, 19.4, 13.4, VPC_F, VPC_B, lw=2, alpha=0.45, z=3, r=0.35)
txt(ax, 1.4, 22.55, "Central VPC  (user-provided — existing)", fs=9, fw="bold",
    color=VPC_B, ha="left", z=6)
tag(ax, 14.0, 22.4, "create_networking=false (default)", fc="#E8F5E9", ec=VPC_B, fs=7)

# Private Subnet A
rbox(ax, 1.2, 18.8, 8.5, 3.4, SUBNET_F, SUBNET_B, lw=1.5, alpha=0.6,
     z=4, r=0.25, ls="--")
txt(ax, 5.45, 22.0, "Private Subnet — AZ-1", fs=8.5, fw="bold",
    color=SUBNET_B, z=6)

# Private Subnet B
rbox(ax, 10.9, 18.8, 8.5, 3.4, SUBNET_F, SUBNET_B, lw=1.5, alpha=0.6,
     z=4, r=0.25, ls="--")
txt(ax, 15.15, 22.0, "Private Subnet — AZ-2", fs=8.5, fw="bold",
    color=SUBNET_B, z=6)

# Lambda ENIs in subnets
svc_box(ax, 1.5, 19.2, 7.8, 1.0, "Lambda ENIs (x7 functions)",
        "diagnose · logs · fix · list_accounts · list_clusters",
        fc=LAMBDA_C, fs=8.5, z=6)
svc_box(ax, 11.2, 19.2, 7.8, 1.0, "Lambda ENIs (x7 functions)",
        "High Availability — 2nd AZ",
        fc=LAMBDA_C, fs=8.5, z=6)

# Security Group
rbox(ax, 1.2, 18.1, 18.2, 0.65, "#FFF8E1", "#FF8F00", lw=1.2, z=5, r=0.2)
txt(ax, 10.3, 18.45, "Security Group: egress HTTPS 443 → spoke VPC CIDRs  (var.spoke_vpc_cidrs  or  0.0.0.0/0)",
    fs=8, color="#E65100", z=7)

# VPC Endpoints
rbox(ax, 1.2, 14.5, 8.5, 3.3, "#E0F7FA", EP_C, lw=1.5, z=4, r=0.25)
txt(ax, 5.45, 17.55, "VPC Endpoints", fs=9, fw="bold", color=EP_C, z=6)
ep_list = ["Gateway: DynamoDB, S3  (free)",
           "Interface: STS, EKS, EC2",
           "Interface: ELB, IAM, Logs"]
for i, ep in enumerate(ep_list):
    txt(ax, 5.45, 17.05 - i*0.5, ep, fs=8, color=TEXT_DK, z=6)
tag(ax, 1.3, 14.55, "create_vpc_endpoints=true", fc="#E0F7FA", ec=EP_C, fs=7)

# NAT Gateway
rbox(ax, 10.9, 14.5, 8.5, 3.3, "#FFF3E0", NAT_C, lw=1.5, z=4, r=0.25)
txt(ax, 15.15, 17.55, "NAT Gateway", fs=9, fw="bold", color=NAT_C, z=6)
txt(ax, 15.15, 17.05, "Elastic IP attached", fs=8, color=TEXT_DK, z=6)
txt(ax, 15.15, 16.6,  "Outbound for APIs not covered", fs=8, color=TEXT_MD, z=6)
txt(ax, 15.15, 16.15, "by VPC interface endpoints", fs=8, color=TEXT_MD, z=6)

# Public Subnet (NAT lives here)
rbox(ax, 10.9, 13.8, 8.5, 0.55, "#E8F5E9", "#A5D6A7", lw=1, z=4, r=0.15, ls="--")
txt(ax, 15.15, 14.08, "Public Subnet  (NAT GW placement)", fs=7.5, color="#388E3C", z=6)

# DynamoDB (outside VPC, accessed via endpoint)
svc_box(ax, 1.5, 9.65, 5.5, 1.2, "DynamoDB",
        "eks-agent-jobs table", "Jobs, findings, fixes, status",
        fc=DDB_C, fs=9, z=6)
svc_box(ax, 8.5, 9.65, 5.5, 1.2, "S3 Bucket",
        "Frontend static assets", "Next.js out/ (CloudFront OAC)",
        fc=S3_C, fs=9, z=6)
svc_box(ax, 14.8, 9.65, 5.0, 1.2, "IAM Role",
        "lambda-execution-role", "sts:AssumeRole → spoke roles",
        fc=IAM_C, fs=9, z=6)

# Arrows: ENI → endpoints
arrow(ax, 5.45, 18.8, 5.45, 17.8, color=EP_C, lw=1.4, style="->")
arrow(ax, 15.15, 18.8, 15.15, 17.8, color=NAT_C, lw=1.4, style="->")
arrow(ax, 5.0, 14.5, 4.25, 10.85, color=DDB_C, lw=1.2, style="->", rad=0.1)
arrow(ax, 9.5, 24.2, 5.8,  9.65+1.2, color=CF_C, lw=1.4, style="->",
      label="API calls", rad=-0.15)

# ── Existing connectivity layer ──────────────────────────────────────────────
section_hdr(ax, 0.4, 8.55, 20.2,
            "EXISTING NETWORK CONNECTIVITY  (not created by Terraform)",
            "Transit Gateway  ·  VPC Peering  ·  TGW Route Tables  ·  Spoke Attachments",
            fc=TGW_C)

rbox(ax, 0.5, 7.05, 20.0, 1.15, TGW_C, TGW_C, lw=0, z=4, r=0.25)
txt(ax, 10.5, 7.8,  "Transit Gateway  (or VPC Peering)", fs=11, fw="bold", color=WHITE, z=6)
txt(ax, 10.5, 7.3,
    "Routes HTTPS 443 from central VPC → spoke account VPCs where EKS private endpoints are hosted",
    fs=8, color="#CFD8DC", z=6)

badge(ax, 0.65, 7.1, "PRE-EXISTING", fc=ORANGE_A)

# Optional attachment note
rbox(ax, 14.0, 7.55, 6.2, 0.75, "#FFF3E0", ORANGE_A, lw=1, z=5, r=0.15)
txt(ax, 17.1, 7.94, "attach_to_existing_tgw=true", fs=7.5, fw="bold", color=ORANGE_A, z=7)
txt(ax, 17.1, 7.65, "→ Terraform creates VPC attachment only", fs=7, color=TEXT_MD, z=7)

# ── Member Accounts ──────────────────────────────────────────────────────────
section_hdr(ax, 0.4, 6.6, 20.2,
            "MEMBER ACCOUNTS  (spoke — contain EKS clusters)",
            "eks-agent-spoke-role assumed by central Lambda per request", fc=MEMBER_B)

member_data = [
    ("Production",   "123456789012", 0.5,  "#E3F2FD", CLOUD_B,  "#1E88E5"),
    ("Staging",      "234567890123", 7.4,  SPOKE_F,   SPOKE_B,  "#8E24AA"),
    ("Dev / Other",  "345678901234", 14.3, "#E8F5E9",  VPC_B,    "#43A047"),
]
MA_Y  = 0.35
MA_W  = 6.5
MA_H  = 5.95

for label_str, acc_id, ma_x, mc, mb, ac in member_data:
    # Account box
    rbox(ax, ma_x, MA_Y, MA_W, MA_H, mc, mb, lw=2, z=4, r=0.35, alpha=0.65)
    txt(ax, ma_x+MA_W/2, MA_Y+MA_H-0.33, label_str, fs=11, fw="bold", color=mb, z=7)
    txt(ax, ma_x+MA_W/2, MA_Y+MA_H-0.65, f"({acc_id})", fs=8, color=TEXT_LT, z=7)

    # VPC inside account
    vx, vy, vw, vh = ma_x+0.3, MA_Y+2.55, MA_W-0.6, 2.75
    rbox(ax, vx, vy, vw, vh, VPC_F, VPC_B, lw=1.2, alpha=0.5, z=5, r=0.25, ls="--")
    txt(ax, vx+vw/2, vy+vh-0.28, "VPC  (private subnets)", fs=8, fw="bold",
        color=VPC_B, z=7)

    # EKS cluster
    svc_box(ax, vx+0.25, vy+0.25, vw-0.5, 1.5,
            "EKS Cluster  (private)",
            "endpointPrivateAccess: true",
            "endpointPublicAccess: false",
            fc=EKS_C, fs=8.5, z=7)

    # Spoke role
    svc_box(ax, ma_x+0.3, MA_Y+1.35, MA_W-0.6, 0.95,
            "eks-agent-spoke-role",
            "EKS + EC2 + ELB + IAM read",
            fc=IAM_C, fs=8, z=6)

    # aws-auth label
    rbox(ax, ma_x+0.3, MA_Y+0.5, MA_W-0.6, 0.7, "#F3E5F5", SPOKE_B,
         lw=1, z=6, r=0.15)
    txt(ax, ma_x+MA_W/2, MA_Y+0.87, "aws-auth  /  EKS Access Entry", fs=8,
        fw="bold", color=SPOKE_B, z=7)
    txt(ax, ma_x+MA_W/2, MA_Y+0.6, "maps spoke role → Kubernetes RBAC view",
        fs=7, color=TEXT_MD, z=7)

    # Arrow from TGW
    cx = ma_x + MA_W / 2
    arrow(ax, cx, 7.05, cx, MA_Y+MA_H, color=ac, lw=2, style="->",
          label="HTTPS 443")

# ── Footer ───────────────────────────────────────────────────────────────────
rbox(ax, 0, 0, 21, 0.35, "#ECEFF1", "#90A4AE", lw=0, z=3, r=0)
txt(ax, 10.5, 0.18,
    "Central Lambda assumes spoke role per request  →  gets EKS bearer token  →  "
    "connects to private EKS endpoint via TGW / VPC Peering",
    fs=8, color=TEXT_MD, z=5)


# ── Save ────────────────────────────────────────────────────────────────────
plt.savefig(OUT_PATH, format="jpg", dpi=110, bbox_inches="tight",
            facecolor=BG)
plt.close()
print(f"Saved: {OUT_PATH}")
