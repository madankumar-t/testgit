output "cloudfront_url" {
  description = "CloudFront distribution URL (set as NEXT_PUBLIC_API_URL after deploying)"
  value       = "https://${aws_cloudfront_distribution.frontend.domain_name}"
}

output "api_gateway_url" {
  description = "API Gateway endpoint URL"
  value       = aws_apigatewayv2_api.eks_agent.api_endpoint
}

output "api_gateway_stage_url" {
  description = "Full API Gateway URL including stage"
  value       = "${aws_apigatewayv2_api.eks_agent.api_endpoint}/${var.environment}"
}

output "s3_bucket_name" {
  description = "S3 bucket name for frontend assets"
  value       = aws_s3_bucket.frontend.id
}

output "s3_bucket_arn" {
  description = "S3 bucket ARN"
  value       = aws_s3_bucket.frontend.arn
}

output "dynamodb_table_name" {
  description = "DynamoDB jobs table name"
  value       = aws_dynamodb_table.eks_agent_jobs.id
}

output "dynamodb_table_arn" {
  description = "DynamoDB jobs table ARN"
  value       = aws_dynamodb_table.eks_agent_jobs.arn
}

output "lambda_execution_role_arn" {
  description = "IAM role ARN for Lambda functions"
  value       = aws_iam_role.lambda_execution.arn
}

output "worker_function_name" {
  description = "Diagnose worker Lambda function name"
  value       = aws_lambda_function.diagnose_worker.function_name
}

output "central_account_id" {
  description = "AWS account ID where the central app is deployed"
  value       = data.aws_caller_identity.current.account_id
}

output "spoke_role_name" {
  description = "Name of the IAM role deployed in each spoke account"
  value       = var.spoke_role_name
}

output "spoke_role_arns" {
  description = "Expected ARN of the spoke role in each registered account"
  value = {
    for account_id, label in var.spoke_accounts :
    "${account_id} (${label})" => "arn:aws:iam::${account_id}:role/${var.spoke_role_name}"
  }
}

output "registered_accounts" {
  description = "Accounts registered with the app (account_id → label)"
  value       = var.spoke_accounts
}

output "deploy_commands" {
  description = "Post-apply commands to deploy the frontend"
  value = <<-EOF
    # ── Backend is deployed automatically by terraform apply ──────────────
    # The null_resource builds the Lambda layer; archive_file zips the functions.
    # Spoke roles are created in member accounts by deploy_spoke_roles.py.

    # ── Frontend ──────────────────────────────────────────────────────────
    # 1. Build the Next.js static export (use the CloudFront URL as the API base):
    cd ../frontend
    NEXT_PUBLIC_API_URL=https://${aws_cloudfront_distribution.frontend.domain_name}/api/v1 npm run build

    # 2. Sync hashed assets (long TTL):
    aws s3 sync out/_next/static/ s3://${aws_s3_bucket.frontend.id}/_next/static/ \
      --cache-control "max-age=31536000,public,immutable" --delete

    # 3. Sync everything else (no cache):
    aws s3 sync out/ s3://${aws_s3_bucket.frontend.id}/ \
      --cache-control "max-age=0,no-cache,no-store,must-revalidate" \
      --exclude "_next/static/*" --delete

    # 4. Invalidate CloudFront:
    aws cloudfront create-invalidation --distribution-id ${aws_cloudfront_distribution.frontend.id} --paths "/*"
  EOF
}
