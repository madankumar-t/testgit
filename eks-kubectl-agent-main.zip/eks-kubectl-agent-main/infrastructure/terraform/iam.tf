# ---------------------------------------------------------------------------
# Lambda execution IAM role
# ---------------------------------------------------------------------------

resource "aws_iam_role" "lambda_execution" {
  name = "${local.prefix}-lambda-role"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
}

data "aws_iam_policy_document" "lambda_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

# ---------------------------------------------------------------------------
# Inline policy — all permissions needed by the Lambda functions
# ---------------------------------------------------------------------------

resource "aws_iam_role_policy" "lambda_main" {
  name   = "eks-agent-lambda-policy"
  role   = aws_iam_role.lambda_execution.id
  policy = data.aws_iam_policy_document.lambda_main.json
}

data "aws_iam_policy_document" "lambda_main" {
  # CloudWatch Logs
  statement {
    effect    = "Allow"
    actions   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
    resources = ["arn:${data.aws_partition.current.partition}:logs:${var.aws_region}:${data.aws_caller_identity.current.account_id}:log-group:/aws/lambda/${local.prefix}-*"]
  }

  # X-Ray tracing
  statement {
    effect    = "Allow"
    actions   = ["xray:PutTraceSegments", "xray:PutTelemetryRecords"]
    resources = ["*"]
  }

  # DynamoDB CRUD on the jobs table
  statement {
    effect    = "Allow"
    actions   = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:UpdateItem", "dynamodb:DeleteItem", "dynamodb:Query", "dynamodb:Scan"]
    resources = [aws_dynamodb_table.eks_agent_jobs.arn]
  }

  # Lambda — invoke worker function (async start)
  statement {
    effect    = "Allow"
    actions   = ["lambda:InvokeFunction"]
    resources = [aws_lambda_function.diagnose_worker.arn]
  }

  # EKS — read cluster info + generate auth tokens
  statement {
    effect    = "Allow"
    actions   = ["eks:DescribeCluster", "eks:ListClusters", "eks:ListNodegroups", "eks:DescribeNodegroup", "eks:ListAddons", "eks:DescribeAddon"]
    resources = ["*"]
  }

  # STS — needed to generate EKS bearer tokens
  statement {
    effect    = "Allow"
    actions   = ["sts:GetCallerIdentity"]
    resources = ["*"]
  }

  # EC2 — read networking for EKS diagnostics
  statement {
    effect    = "Allow"
    actions   = [
      "ec2:DescribeVpcs", "ec2:DescribeSubnets", "ec2:DescribeSecurityGroups",
      "ec2:DescribeInstances", "ec2:DescribeNetworkInterfaces",
      "ec2:DescribeRouteTables", "ec2:DescribeAvailabilityZones",
    ]
    resources = ["*"]
  }

  # ELBv2 — ALB/NLB diagnostics
  statement {
    effect    = "Allow"
    actions   = [
      "elasticloadbalancing:DescribeLoadBalancers",
      "elasticloadbalancing:DescribeTargetGroups",
      "elasticloadbalancing:DescribeTargetHealth",
      "elasticloadbalancing:DescribeListeners",
      "elasticloadbalancing:DescribeRules",
    ]
    resources = ["*"]
  }

  # Auto Scaling
  statement {
    effect    = "Allow"
    actions   = ["autoscaling:DescribeAutoScalingGroups", "autoscaling:DescribeScalingActivities"]
    resources = ["*"]
  }

  # IAM — IRSA/OIDC diagnostics (read-only)
  statement {
    effect    = "Allow"
    actions   = [
      "iam:ListOpenIDConnectProviders",
      "iam:GetOpenIDConnectProvider",
      "iam:ListRoles",
      "iam:GetRole",
      "iam:ListAttachedRolePolicies",
    ]
    resources = ["*"]
  }
}

# AWSLambdaVPCAccessExecutionRole includes CreateNetworkInterface/DeleteNetworkInterface
resource "aws_iam_role_policy_attachment" "lambda_basic" {
  role       = aws_iam_role.lambda_execution.name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}
