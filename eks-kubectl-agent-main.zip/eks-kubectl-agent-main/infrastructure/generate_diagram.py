"""
Generates architecture + network diagram for the EKS Kubectl Agent.
Output: architecture_diagram.jpg (same folder as this script)
"""
import math
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D

OUT_PATH = os.path.join(os.path.dirname(__file__), "architecture_diagram.jpg")

# ── Colour palette ──────────────────────────────────────────────────────────
C = dict(
    bg        = "#F0F4F8",
    title_bg  = "#1A237E",
    user      = "#37474F",
    cf        = "#E91E63",
    s3        = "#4CAF50",
    apigw     = "#9C27B0",
    lambda_   = "#FF9900",
    dynamo    = "#3F51B5",
    iam       = "#00838F",
    tgw       = "#546E7A",
    central   = "#BBDEFB",
    central_b = "#1565C0",
    vpc_c     = "#C8E6C9",
    vpc_b     = "#2E7D32",
    member    = "#FFF3E0",
    member_b  = "#BF360C",
    eks       = "#FF6F00",
    spoke     = "#6A1B9A",
    subnet    = "#DCEDC8",
    subnet_b  = "#558B2F",
    arrow     = "#455A64",
    arrow2    = "#1565C0",
    arrow3    = "#BF360C",
    white     = "#FFFFFF",
    text_dk   = "#1A1A1A",
    text_md   = "#37474F",
    text_lt   = "#78909C",
    sep       = "#90A4AE",
    nat       = "#F57C00",
    ep        = "#00695C",
)

# ── Canvas ───────────────────────────────────────────────────────────────────
FW, FH = 24, 32          # inches
fig, ax = plt.subplots(figsize=(FW, FH), dpi=100)
ax.set_xlim(0, FW); ax.set_ylim(0, FH)
ax.axis("off")
fig.patch.set_facecolor(C["bg"])
ax.set_facecolor(C["bg"])


# ── Drawing helpers ──────────────────────────────────────────────────────────
def rbox(x, y, w, h, fc, ec, lw=1.5, alpha=1.0, radius=0.25, zorder=2, ls="-"):
    p = FancyBboxPatch((x, y), w, h,
                       boxstyle=f"round,pad=0,rounding_size={radius}",
                       facecolor=fc, edgecolor=ec, linewidth=lw,
                       alpha=alpha, zorder=zorder, linestyle=ls)
    ax.add_patch(p)
    return p

def label(x, y, txt, fs=10, fw="normal", color=C["text_dk"],
          ha="center", va="center", zorder=10, alpha=1.0):
    return ax.text(x, y, txt, fontsize=fs, fontweight=fw, color=color,
                   ha=ha, va=va, zorder=zorder, alpha=alpha,
                   fontfamily="DejaVu Sans")

def svc(x, y, w, h, title, sub=None, fc=C["lambda_"], tc=C["white"],
        fs=9, zorder=5, radius=0.18):
    rbox(x, y, w, h, fc, C["white"], lw=0, zorder=zorder, radius=radius)
    cy = y + h / 2
    if sub:
        label(x + w/2, cy + 0.13, title, fs=fs, fw="bold", color=tc, zorder=zorder+1)
        label(x + w/2, cy - 0.13, sub,   fs=fs-1.5, color=tc, zorder=zorder+1, alpha=0.9)
    else:
        label(x + w/2, cy, title, fs=fs, fw="bold", color=tc, zorder=zorder+1)

def arr(x1, y1, x2, y2, color=C["arrow"], lw=1.8, style="->",
        label_txt=None, zorder=6, rad=0.0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle=style, color=color, lw=lw,
                                connectionstyle=f"arc3,rad={rad}"),
                zorder=zorder)
    if label_txt:
        mx, my = (x1+x2)/2, (y1+y2)/2
        label(mx, my, label_txt, fs=7.5, color=color, zorder=zorder+1)

def dblarr(x1, y1, x2, y2, color=C["arrow"], lw=1.8, zorder=6, rad=0.0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="<->", color=color, lw=lw,
                                connectionstyle=f"arc3,rad={rad}"),
                zorder=zorder)

def hrule(y, x0=0.3, x1=23.7, color=C["sep"], lw=0.8, ls="--"):
    ax.add_line(Line2D([x0, x1], [y, y], color=color, lw=lw,
                       linestyle=ls, zorder=1))

def section_label(x, y, txt, fs=8, color=C["text_lt"]):
    label(x, y, txt, fs=fs, color=color, ha="left", fw="bold")


# ════════════════════════════════════════════════════════════════════════════
# TITLE BANNER
# ════════════════════════════════════════════════════════════════════════════
rbox(0, 30.8, FW, 1.2, C["title_bg"], C["title_bg"], lw=0, zorder=1, radius=0)
label(FW/2, 31.55, "EKS Kubectl Agent — Architecture & Network Diagram",
      fs=17, fw="bold", color=C["white"], zorder=5)
label(FW/2, 31.1, "Multi-Account · Private EKS Clusters · Serverless Backend · Static Frontend",
      fs=10, color="#90CAF9", zorder=5)


# ════════════════════════════════════════════════════════════════════════════
# SECTION A  —  USER / INTERNET LAYER  (y 28.4 – 30.5)
# ════════════════════════════════════════════════════════════════════════════
section_label(0.4, 30.35, "① INTERNET / USER LAYER")
hrule(30.3)

# Browser
rbox(1.2, 28.5, 2.8, 1.3, "#ECEFF1", C["text_md"], lw=1.5, radius=0.3, zorder=3)
label(2.6, 29.45, "[ Browser ]", fs=9, color=C["text_md"], zorder=5)
label(2.6, 28.82, "Browser / User", fs=9.5, fw="bold", zorder=5)

# CloudFront
rbox(6.0, 28.5, 3.4, 1.3, C["cf"], C["cf"], lw=0, radius=0.3, zorder=3)
label(7.7, 29.4,  "CloudFront", fs=11, fw="bold", color=C["white"], zorder=5)
label(7.7, 29.02, "CDN + WAF + HTTPS", fs=8, color="#FCE4EC", zorder=5)

# S3 (frontend)
rbox(11.8, 29.0, 2.8, 0.85, C["s3"], C["s3"], lw=0, radius=0.25, zorder=3)
label(13.2, 29.42, "S3 Bucket", fs=9.5, fw="bold", color=C["white"], zorder=5)
label(13.2, 29.12, "Static Frontend", fs=8, color="#E8F5E9", zorder=5)

# Arrows: browser → CF
arr(4.0, 29.15, 6.0, 29.15, color=C["arrow"], lw=2, label_txt="HTTPS")
# CF → S3
arr(9.4, 29.5, 11.8, 29.4, color=C["s3"], lw=1.8, label_txt="/* (static assets)")
# CF → API GW (drawn after API GW box below)

label(0.6, 28.35, "Notes:  CloudFront acts as the single entry point — /api/* is proxied to API Gateway, /* is served from S3.",
      fs=7.5, color=C["text_lt"], ha="left", zorder=5)


# ════════════════════════════════════════════════════════════════════════════
# SECTION B  —  CENTRAL AWS ACCOUNT  (y 5.5 – 28.1)
# ════════════════════════════════════════════════════════════════════════════
hrule(28.1)
section_label(0.4, 27.85, "② CENTRAL AWS ACCOUNT  (master / management account)")

# Account boundary
rbox(0.3, 5.6, 23.4, 22.1, C["central"], C["central_b"], lw=2.5, alpha=0.45,
     radius=0.5, zorder=1)
label(2.5, 27.45, "Central Account", fs=9, fw="bold", color=C["central_b"],
      ha="left", zorder=5)

# ── API Gateway ──────────────────────────────────────────────────────────────
rbox(5.5, 26.3, 5.0, 1.2, C["apigw"], C["apigw"], lw=0, radius=0.3, zorder=4)
label(8.0, 27.05, "API Gateway HTTP API v2", fs=10.5, fw="bold", color=C["white"], zorder=6)
label(8.0, 26.62, "POST /diagnose  GET /diagnose/{id}  GET /accounts  GET /clusters  POST /logs  POST /fix/apply",
      fs=7, color="#EDE7F6", zorder=6)

# CF → API GW arrow
arr(9.4, 29.05, 9.5, 27.5, color=C["apigw"], lw=1.8, style="->",
    label_txt="/api/* routes", rad=0.15)

# ── VPC boundary ─────────────────────────────────────────────────────────────
VPC_X, VPC_Y, VPC_W, VPC_H = 0.8, 6.0, 22.4, 19.8
rbox(VPC_X, VPC_Y, VPC_W, VPC_H, C["vpc_c"], C["vpc_b"],
     lw=2, alpha=0.35, radius=0.4, zorder=2)
label(1.3, 25.55, "VPC  (central account — private subnets, 2+ AZs)", fs=8.5,
      fw="bold", color=C["vpc_b"], ha="left", zorder=5)

# ── Private Subnet (Lambda) ───────────────────────────────────────────────────
rbox(1.2, 13.5, 14.8, 11.7, C["subnet"], C["subnet_b"],
     lw=1.5, alpha=0.6, radius=0.35, zorder=3, ls="--")
label(1.6, 25.0, "Private Subnet (Lambda ENIs — 2 AZs)", fs=8,
      color=C["subnet_b"], ha="left", zorder=5)

# Lambda functions — 2 rows of 4 + 1
LW, LH, LG = 3.3, 0.85, 0.2
lambdas_row1 = [
    ("diagnose_start",   "POST /diagnose"),
    ("diagnose_worker",  "async worker"),
    ("diagnose_status",  "GET /diagnose/{id}"),
    ("get_logs",         "POST /logs"),
]
lambdas_row2 = [
    ("apply_fix",        "POST /fix/apply"),
    ("list_accounts",    "GET /accounts"),
    ("list_clusters",    "GET /clusters"),
]

ROW1_Y = 23.4
ROW2_Y = 22.2
LX_START = 1.5

for i, (name, path) in enumerate(lambdas_row1):
    lx = LX_START + i * (LW + LG)
    svc(lx, ROW1_Y, LW, LH, f"λ  {name}", path,
        fc=C["lambda_"], fs=8.5, zorder=6)

for i, (name, path) in enumerate(lambdas_row2):
    lx = LX_START + i * (LW + LG)
    svc(lx, ROW2_Y, LW, LH, f"λ  {name}", path,
        fc=C["lambda_"], fs=8.5, zorder=6)

# API GW → Lambda arrow
arr(8.0, 26.3, 8.0, 24.25, color=C["apigw"], lw=2,
    label_txt="invoke", style="->")

# Lambda call-chain: start → worker
arr(LX_START + LW/2, ROW1_Y, LX_START + (LW+LG) + LW/2, ROW1_Y + LH/2,
    color=C["lambda_"], lw=1.2, style="->",
    label_txt="InvocationType=Event", rad=-0.2)

label(1.5, 21.75, "Lambda Runtime: Python 3.12  ·  arch: arm64  ·  Layer: kubernetes>=29, boto3>=1.34",
      fs=7.5, color=C["text_lt"], ha="left", zorder=5)

# ── Cross-account flow (inside Lambda box) ───────────────────────────────────
rbox(1.2, 14.0, 14.8, 7.4, "#FFF8E1", "#FFA000", lw=1.2, alpha=0.5,
     radius=0.3, zorder=3, ls="--")
label(1.6, 21.2, "Cross-account flow (executed per diagnosis request)", fs=8,
      color="#E65100", ha="left", fw="bold", zorder=5)

steps = [
    ("1", "sts:AssumeRole",         "Assume spoke role in target account",     1.5,  20.5),
    ("2", "eks:GetToken (STS)",     "Get EKS bearer token with spoke creds",   6.2,  20.5),
    ("3", "Kubernetes API",         "k8s Python client → private endpoint",    11.0, 20.5),
    ("4", "boto3 (EC2/ELB/IAM)",    "AWS read calls in spoke account",         1.5,  18.8),
    ("5", "analyzers.py",           "Pure-function analysis on raw data",       6.2,  18.8),
    ("6", "DynamoDB.put_item",      "Write results to central jobs table",      11.0, 18.8),
]
for num, title, desc, sx, sy in steps:
    rbox(sx, sy-0.1, 4.5, 1.0, "#FFF3E0", "#FF8F00", lw=1, radius=0.2, zorder=5)
    label(sx+0.3, sy+0.42, f"Step {num}", fs=7.5, fw="bold", color="#E65100",
          ha="left", zorder=6)
    label(sx+0.3, sy+0.15, title, fs=8.5, fw="bold", color=C["text_dk"],
          ha="left", zorder=6)
    label(sx+0.3, sy-0.12, desc, fs=7.5, color=C["text_lt"], ha="left", zorder=6)

# Arrows between steps row 1
for i in range(2):
    x1 = steps[i][3] + 4.5
    x2 = steps[i+1][3]
    sy = steps[i][4]
    arr(x1, sy+0.4, x2, sy+0.4, color="#FFA000", lw=1.5, style="->")
# Wrap arrow row1→row2
arr(steps[2][3]+4.5, steps[2][4]+0.4, steps[2][3]+4.5, steps[3][4]+0.4,
    color="#FFA000", lw=1.5, style="->")
arr(steps[2][3]+4.5, steps[3][4]+0.4, steps[3][3], steps[3][4]+0.4,
    color="#FFA000", lw=1.5, style="->")
# Arrows between steps row 2
for i in range(3, 5):
    x1 = steps[i][3] + 4.5
    x2 = steps[i+1][3]
    sy = steps[i][4]
    arr(x1, sy+0.4, x2, sy+0.4, color="#FFA000", lw=1.5, style="->")

# ── DynamoDB ─────────────────────────────────────────────────────────────────
rbox(1.2, 13.5, 6.5, 2.5, C["dynamo"], C["dynamo"], lw=0, radius=0.3, zorder=4)
label(4.45, 15.15, "DynamoDB", fs=11, fw="bold", color=C["white"], zorder=6)
label(4.45, 14.75, "eks-agent-jobs table", fs=8.5, color="#C5CAE9", zorder=6)
label(4.45, 14.35, "TTL: 24 h  ·  PAY_PER_REQUEST  ·  PITR on", fs=8, color="#C5CAE9", zorder=6)
label(4.45, 13.95, "Partition key: job_id  (status, findings, fixes, logs)", fs=7.5, color="#9FA8DA", zorder=6)

# ── VPC Endpoints ────────────────────────────────────────────────────────────
rbox(9.2, 13.5, 5.8, 2.5, C["ep"], C["ep"], lw=0, radius=0.3, zorder=4)
label(12.1, 15.15, "VPC Endpoints", fs=10.5, fw="bold", color=C["white"], zorder=6)
label(12.1, 14.72, "Gateway:  DynamoDB  ·  S3", fs=8.5, color="#B2DFDB", zorder=6)
label(12.1, 14.32, "Interface:  STS  ·  EKS  ·  EC2  ·  ELB  ·  IAM", fs=8, color="#B2DFDB", zorder=6)
label(12.1, 13.95, "(avoids NAT Gateway for AWS API calls)", fs=7.5, color="#80CBC4", zorder=6)

# NAT Gateway
rbox(16.5, 13.5, 4.5, 2.5, C["nat"], C["nat"], lw=0, radius=0.3, zorder=4)
label(18.75, 15.15, "NAT Gateway", fs=10.5, fw="bold", color=C["white"], zorder=6)
label(18.75, 14.72, "For outbound traffic", fs=8.5, color="#FFF3E0", zorder=6)
label(18.75, 14.32, "not covered by VPC", fs=8.5, color="#FFF3E0", zorder=6)
label(18.75, 13.95, "endpoints", fs=8.5, color="#FFF3E0", zorder=6)

# DynamoDB ↔ Lambda arrow
arr(4.45, 16.0, 4.45, 17.2, color="#3F51B5", lw=1.5,
    label_txt="put/get_item", style="<->")

# ── IAM Roles ────────────────────────────────────────────────────────────────
rbox(1.2, 6.3, 14.0, 6.8, "#E0F7FA", C["iam"], lw=1.5, alpha=0.55,
     radius=0.35, zorder=3)
label(1.6, 12.85, "IAM  —  Central Account Roles & Permissions", fs=8.5,
      fw="bold", color=C["iam"], ha="left", zorder=5)

# Lambda execution role
rbox(1.5, 9.8, 6.5, 2.7, C["iam"], C["iam"], lw=0, radius=0.25, zorder=5)
label(4.75, 12.1,  "lambda-execution-role", fs=9.5, fw="bold", color=C["white"], zorder=6)
label(4.75, 11.7,  "Permissions granted:", fs=8, color="#B2EBF2", zorder=6)
label(4.75, 11.35, "CloudWatch Logs · X-Ray · DynamoDB CRUD", fs=8, color="#E0F7FA", zorder=6)
label(4.75, 11.0,  "EKS read · EC2/ELB/IAM read · Lambda invoke", fs=8, color="#E0F7FA", zorder=6)
label(4.75, 10.65, "sts:AssumeRole → iam::*:role/eks-agent-spoke-role", fs=8, color="#E0F7FA", zorder=6)
label(4.75, 10.3,  "AWSLambdaVPCAccessExecutionRole (managed)", fs=8, color="#B2EBF2", zorder=6)

# CloudFormation auto-deploy role
rbox(9.3, 9.8, 5.5, 2.7, "#5C6BC0", "#5C6BC0", lw=0, radius=0.25, zorder=5)
label(12.05, 12.1,  "bootstrap deploy", fs=9.5, fw="bold", color=C["white"], zorder=6)
label(12.05, 11.7,  "(Terraform local-exec)", fs=8, color="#C5CAE9", zorder=6)
label(12.05, 11.35, "Assumes OrganizationAccountAccessRole", fs=8, color="#E8EAF6", zorder=6)
label(12.05, 11.0,  "in each member account", fs=8, color="#E8EAF6", zorder=6)
label(12.05, 10.65, "Runs deploy_spoke_roles.py", fs=8, color="#C5CAE9", zorder=6)
label(12.05, 10.3,  "CloudFormation deploy (spoke-role.yaml)", fs=8, color="#C5CAE9", zorder=6)

# Arrows from lambda role
arr(4.75, 9.8, 4.75, 8.9, color=C["iam"], lw=1.5,
    label_txt="sts:AssumeRole per request", style="->")

# terraform apply box
rbox(1.5, 6.6, 4.5, 2.8, "#4527A0", "#4527A0", lw=0, radius=0.25, zorder=5)
label(3.75, 9.05, "terraform apply", fs=10, fw="bold", color=C["white"], zorder=6)
label(3.75, 8.65, "One command deploys:", fs=8, color="#D1C4E9", zorder=6)
label(3.75, 8.3,  "• All Lambda functions + layer", fs=7.5, color="#EDE7F6", zorder=6)
label(3.75, 8.0,  "• API GW, DynamoDB, IAM", fs=7.5, color="#EDE7F6", zorder=6)
label(3.75, 7.7,  "• S3 + CloudFront", fs=7.5, color="#EDE7F6", zorder=6)
label(3.75, 7.4,  "• Spoke roles in ALL member", fs=7.5, color="#EDE7F6", zorder=6)
label(3.75, 7.1,  "  accounts (auto via Python)", fs=7.5, color="#EDE7F6", zorder=6)

# tfvars box
rbox(7.2, 6.6, 5.5, 2.8, "#311B92", "#311B92", lw=0, radius=0.25, zorder=5)
label(9.95, 9.05, "terraform.tfvars  (input)", fs=10, fw="bold", color=C["white"], zorder=6)
label(9.95, 8.65, "spoke_accounts = {", fs=8.5, color="#CE93D8", zorder=6, ha="center")
label(9.95, 8.3,  '  "123456789012" = "Production"', fs=8, color="#E1BEE7", zorder=6)
label(9.95, 8.0,  '  "234567890123" = "Staging"', fs=8, color="#E1BEE7", zorder=6)
label(9.95, 7.7,  '  "345678901234" = "Dev"', fs=8, color="#E1BEE7", zorder=6)
label(9.95, 7.4,  "}", fs=8.5, color="#CE93D8", zorder=6)
label(9.95, 7.05, "bootstrap_role_name = \"OrganizationAccountAccessRole\"",
      fs=7.2, color="#BA68C8", zorder=6)
arr(7.2, 8.0, 6.0, 8.0, color="#7B1FA2", lw=1.5, style="->")


# ════════════════════════════════════════════════════════════════════════════
# SECTION C  —  TRANSIT GATEWAY / NETWORK CONNECTIVITY  (y 4.5 – 5.6)
# ════════════════════════════════════════════════════════════════════════════
hrule(5.55)
section_label(0.4, 5.35, "③ NETWORK CONNECTIVITY  —  Transit Gateway / VPC Peering")

rbox(0.8, 4.5, 22.4, 1.0, C["tgw"], C["tgw"], lw=0, radius=0.3, zorder=3)
label(FW/2, 5.2, "AWS Transit Gateway  (or VPC Peering)", fs=12, fw="bold",
      color=C["white"], zorder=5)
label(FW/2, 4.78,
      "Enables Lambda (central VPC) → EKS private endpoint (spoke VPCs)  ·  HTTPS port 443  ·  TGW attachment per VPC",
      fs=8.5, color="#CFD8DC", zorder=5)

# arrows  central VPC → TGW
arr(FW/2, 6.0, FW/2, 5.5, color=C["vpc_b"], lw=2.5, style="->")
# TGW → three member accounts  (drawn below)


# ════════════════════════════════════════════════════════════════════════════
# SECTION D  —  MEMBER ACCOUNTS  (y 0.3 – 4.4)
# ════════════════════════════════════════════════════════════════════════════
hrule(4.45)
section_label(0.4, 4.25, "④ MEMBER ACCOUNTS  (spoke accounts — contain EKS clusters)")

member_accounts = [
    ("123456789012", "Production",  0.5,  "#E3F2FD", "#1565C0"),
    ("234567890123", "Staging",     8.3,  "#F3E5F5", "#6A1B9A"),
    ("345678901234", "Dev / Other", 16.1, "#E8F5E9", "#1B5E20"),
]
MA_W, MA_H = 7.4, 4.0
MA_Y = 0.3

for acc_id, acc_label, ma_x, mc, mb in member_accounts:
    # Account box
    rbox(ma_x, MA_Y, MA_W, MA_H, mc, mb, lw=2, radius=0.4, zorder=3, alpha=0.7)
    label(ma_x + MA_W/2, MA_Y + MA_H - 0.3, acc_label, fs=11, fw="bold",
          color=mb, zorder=6)
    label(ma_x + MA_W/2, MA_Y + MA_H - 0.6, f"({acc_id})", fs=8,
          color=C["text_lt"], zorder=6)

    # VPC box inside
    vpc_x, vpc_y = ma_x + 0.3, MA_Y + 0.3
    vpc_w, vpc_h = MA_W - 0.6, 2.0
    rbox(vpc_x, vpc_y, vpc_w, vpc_h, C["vpc_c"], C["vpc_b"],
         lw=1.2, alpha=0.5, radius=0.25, zorder=4, ls="--")
    label(vpc_x + vpc_w/2, vpc_y + vpc_h - 0.28, "VPC  (private subnets)", fs=8,
          color=C["vpc_b"], fw="bold", zorder=6)

    # EKS cluster box
    eks_x = vpc_x + 0.3
    eks_y = vpc_y + 0.25
    eks_w = vpc_w - 0.6
    eks_h = 1.1
    rbox(eks_x, eks_y, eks_w, eks_h, C["eks"], C["eks"], lw=0, radius=0.2, zorder=5)
    label(eks_x + eks_w/2, eks_y + eks_h*0.65, "EKS Cluster (private endpoint)", fs=8.5,
          fw="bold", color=C["white"], zorder=6)
    label(eks_x + eks_w/2, eks_y + eks_h*0.3,
          "endpointPrivateAccess: true  ·  endpointPublicAccess: false",
          fs=7.5, color="#FFF3E0", zorder=6)

    # Spoke role box
    spoke_y = MA_Y + 2.55
    rbox(ma_x + 0.3, spoke_y, MA_W - 0.6, 0.9, C["spoke"], C["spoke"],
         lw=0, radius=0.2, zorder=5)
    label(ma_x + MA_W/2, spoke_y + 0.62, "IAM: eks-agent-spoke-role", fs=8.5,
          fw="bold", color=C["white"], zorder=6)
    label(ma_x + MA_W/2, spoke_y + 0.3,
          "Trusted by central account  ·  EKS/EC2/ELB/IAM read",
          fs=7.5, color="#E1BEE7", zorder=6)

    # Arrow: TGW → this account
    tgw_cx = ma_x + MA_W / 2
    arr(tgw_cx, 4.5, tgw_cx, MA_Y + MA_H, color=mb, lw=1.8, style="->")

    # Arrow: spoke role → EKS
    arr(ma_x + MA_W/2, spoke_y, ma_x + MA_W/2, eks_y + eks_h,
        color=C["spoke"], lw=1.5, style="->", label_txt="k8s bearer token")


# ════════════════════════════════════════════════════════════════════════════
# LEGEND (right side of central account)
# ════════════════════════════════════════════════════════════════════════════
leg_x, leg_y = 16.6, 6.4
rbox(leg_x, leg_y, 6.8, 12.5, "#ECEFF1", "#90A4AE", lw=1, radius=0.3, zorder=4)
label(leg_x + 3.4, leg_y + 12.1, "Legend", fs=11, fw="bold", color=C["text_dk"], zorder=6)

legend_items = [
    (C["lambda_"],  "Lambda Function (Python 3.12, arm64)"),
    (C["apigw"],    "API Gateway HTTP API v2"),
    (C["dynamo"],   "DynamoDB (job storage, 24h TTL)"),
    (C["iam"],      "IAM Role (Lambda execution)"),
    (C["spoke"],    "IAM Role (spoke — member account)"),
    (C["eks"],      "EKS Cluster (private endpoint)"),
    (C["vpc_b"],    "VPC Boundary"),
    (C["tgw"],      "Transit Gateway"),
    (C["cf"],       "CloudFront Distribution"),
    (C["s3"],       "S3 Bucket (static assets)"),
    (C["ep"],       "VPC Endpoints (DynamoDB, STS…)"),
    (C["nat"],      "NAT Gateway"),
]

for i, (color, desc) in enumerate(legend_items):
    iy = leg_y + 11.3 - i * 0.82
    rbox(leg_x + 0.3, iy - 0.18, 0.5, 0.4, color, color, lw=0, radius=0.1, zorder=6)
    label(leg_x + 1.1, iy + 0.0, desc, fs=8, color=C["text_dk"],
          ha="left", va="center", zorder=6)


# ════════════════════════════════════════════════════════════════════════════
# FOOTER
# ════════════════════════════════════════════════════════════════════════════
hrule(0.28, lw=1)
label(0.4,  0.15, "Deployment:  terraform apply  —  one command creates all resources + spoke roles in every member account.", fs=8, color=C["text_lt"], ha="left")
label(23.6, 0.15, "EKS Kubectl Agent  v1.0  ·  May 2026", fs=8, color=C["text_lt"], ha="right")


# ── Save ─────────────────────────────────────────────────────────────────────
plt.tight_layout(pad=0)
plt.savefig(OUT_PATH, format="jpg", dpi=110, bbox_inches="tight",
            facecolor=C["bg"])
plt.close()
print(f"Saved: {OUT_PATH}")
