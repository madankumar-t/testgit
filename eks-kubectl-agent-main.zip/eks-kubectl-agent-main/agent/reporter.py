"""
Markdown incident report generator.

Produces a structured EKS Incident Troubleshooting Report from a DiagnosisReport.
"""

from __future__ import annotations

import datetime
from collections import defaultdict
from pathlib import Path

from agent.models import DiagnosisReport, FixRecommendation, Severity

# Section ordering for findings grouping
_COMPONENT_ORDER = [
    "Nodes",
    "Pods",
    "Deployments",
    "Services",
    "Ingress / ALB",
    "AWS Load Balancer Controller",
    "Networking",
    "DNS",
    "Storage",
    "IAM / IRSA",
    "Logs and Events",
    "Autoscaling",
    "Security / RBAC",
]

_SEVERITY_EMOJI = {
    Severity.CRITICAL: "🔴",
    Severity.HIGH: "🟠",
    Severity.MEDIUM: "🟡",
    Severity.LOW: "🟢",
    Severity.INFO: "⚪",
}


def _severity_label(severity: Severity) -> str:
    return f"{_SEVERITY_EMOJI.get(severity, '')} **{severity.value}**"


def _escape_pipe(text: str) -> str:
    """Escape pipe characters so they don't break Markdown tables."""
    return text.replace("|", "\\|")


def generate_report(report: DiagnosisReport, fixes: list[FixRecommendation]) -> str:
    """
    Build a full Markdown incident report string.

    Args:
        report: Populated DiagnosisReport from diagnostics + analyzers.
        fixes:  FixRecommendation list from fixes.generate_fixes().

    Returns:
        Markdown string.
    """
    now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    ctx = report.cluster_context

    lines: list[str] = []

    # -----------------------------------------------------------------------
    # Header
    # -----------------------------------------------------------------------
    lines += [
        "# EKS Incident Troubleshooting Report",
        "",
        f"> **Generated:** {now}",
        "",
    ]

    # -----------------------------------------------------------------------
    # 1. Incident Summary
    # -----------------------------------------------------------------------
    lines += ["## 1. Incident Summary", ""]

    critical_count = sum(1 for f in report.findings if f.severity == Severity.CRITICAL)
    high_count = sum(1 for f in report.findings if f.severity == Severity.HIGH)
    medium_count = sum(1 for f in report.findings if f.severity == Severity.MEDIUM)
    total_count = len(report.findings)

    affected_ns = sorted({f.namespace for f in report.findings if f.namespace not in ("aws", "cluster", "unknown")})
    affected_components = sorted({f.component for f in report.findings})

    lines += [
        f"Automated diagnosis completed for EKS cluster **`{ctx.cluster_name}`** "
        f"in region **`{ctx.region}`**.",
        "",
        f"- Total findings: **{total_count}**",
        f"- Critical: **{critical_count}** | High: **{high_count}** | Medium: **{medium_count}**",
        f"- Affected namespaces: {', '.join(f'`{ns}`' for ns in affected_ns) or 'none detected'}",
        f"- Affected components: {', '.join(affected_components) or 'none detected'}",
        "",
    ]

    # -----------------------------------------------------------------------
    # 2. Cluster Context
    # -----------------------------------------------------------------------
    lines += [
        "## 2. Cluster Context",
        "",
        f"| Field | Value |",
        f"|---|---|",
        f"| Cluster Name | `{ctx.cluster_name}` |",
        f"| AWS Account | `{ctx.aws_account}` |",
        f"| AWS Region | `{ctx.region}` |",
        f"| IAM Identity | `{ctx.aws_user}` |",
        f"| Kubernetes Version | `{ctx.kubernetes_version}` |",
        f"| Node Count | `{ctx.node_count}` |",
        f"| kubectl Context | `{ctx.kubectl_context}` |",
        f"| API Server | `{ctx.api_server}` |",
        f"| Namespaces Found | {len(ctx.namespaces)} |",
        f"| Time of Investigation | {now} |",
        "",
    ]

    # -----------------------------------------------------------------------
    # 3. Commands Executed
    # -----------------------------------------------------------------------
    lines += [
        "## 3. Commands Executed",
        "",
        "| Step | Command | Purpose | Result |",
        "|---|---|---|---|",
    ]
    for ec in report.executed_commands:
        status = "✅" if ec.success else "❌"
        lines.append(
            f"| {ec.step} "
            f"| `{_escape_pipe(ec.command)}` "
            f"| {_escape_pipe(ec.purpose)} "
            f"| {status} {_escape_pipe(ec.result_summary[:80])} |"
        )
    lines.append("")

    # -----------------------------------------------------------------------
    # 4. Findings
    # -----------------------------------------------------------------------
    lines += ["## 4. Findings", ""]

    if not report.findings:
        lines += ["No issues detected during automated analysis.", ""]
    else:
        grouped: dict[str, list] = defaultdict(list)
        for finding in report.findings:
            grouped[finding.component].append(finding)

        # Emit in defined order, then any remaining components
        ordered_keys = _COMPONENT_ORDER + [
            k for k in grouped if k not in _COMPONENT_ORDER
        ]

        for component in ordered_keys:
            if component not in grouped:
                continue
            lines += [f"### {component}", ""]
            for f in sorted(grouped[component], key=lambda x: list(Severity).index(x.severity)):
                lines += [
                    f"#### {_severity_label(f.severity)} — `{f.resource}` (namespace: `{f.namespace}`)",
                    "",
                    f"**Evidence:**",
                    "```",
                    f.evidence,
                    "```",
                    "",
                    f"**Impact:** {f.impact}",
                    "",
                    f"**Recommended Fix:** {f.recommended_fix}",
                    "",
                ]
                if f.fix_command:
                    lines += [
                        f"**Fix Command:**",
                        f"```bash",
                        f.fix_command,
                        "```",
                        "",
                    ]
                if f.fix_id:
                    lines.append(f"*Fix ID: `{f.fix_id}`*")
                    lines.append("")
                lines.append("---")
                lines.append("")

    # -----------------------------------------------------------------------
    # 5. Root Cause
    # -----------------------------------------------------------------------
    lines += [
        "## 5. Root Cause",
        "",
        report.root_cause,
        "",
    ]

    # -----------------------------------------------------------------------
    # 6. Recommended Fixes
    # -----------------------------------------------------------------------
    lines += ["## 6. Recommended Fixes", ""]

    if not fixes:
        lines += ["No automated fix recommendations generated.", ""]
    else:
        for fix in fixes:
            cmd_str = " ".join(fix.command)
            rollback_str = " ".join(fix.rollback_command) if fix.rollback_command else "N/A"
            lines += [
                f"### `{fix.fix_id}` — {fix.description}",
                "",
                f"| Field | Details |",
                f"|---|---|",
                f"| Fix ID | `{fix.fix_id}` |",
                f"| Risk | **{fix.risk.value}** |",
                f"| Namespace | `{fix.namespace or 'N/A'}` |",
                f"| Resource | `{fix.resource or 'N/A'}` |",
                f"| Expected Result | {fix.expected_result} |",
                f"| Confirmation Required | {'Yes ⚠️' if fix.requires_confirmation else 'No'} |",
                "",
                "**Command:**",
                "```bash",
                cmd_str,
                "```",
                "",
                "**Rollback:**",
                "```bash",
                rollback_str,
                "```",
                f"*{fix.rollback_description}*",
                "",
            ]

    # -----------------------------------------------------------------------
    # 7. Confirmation Required
    # -----------------------------------------------------------------------
    confirm_fixes = [f for f in fixes if f.requires_confirmation]
    lines += ["## 7. Confirmation Required", ""]

    if not confirm_fixes:
        lines += ["No confirmation-required fixes generated.", ""]
    else:
        lines += [
            "> ⚠️ The following fixes require explicit user approval before execution.",
            "> Run: `python main.py fix --fix-id <FIX_ID>`",
            "",
        ]
        for fix in confirm_fixes:
            cmd_str = " ".join(fix.command)
            lines += [
                f"- **`{fix.fix_id}`** [{fix.risk.value} risk] — {fix.description}",
                f"  ```bash",
                f"  {cmd_str}",
                f"  ```",
                "",
            ]

    # -----------------------------------------------------------------------
    # 8. Post-Fix Validation Plan
    # -----------------------------------------------------------------------
    lines += [
        "## 8. Post-Fix Validation Plan",
        "",
        "After applying any fix, validate using the following commands:",
        "",
        "```bash",
        "# 1. Check all pod statuses",
        "kubectl get pods -A",
        "",
        "# 2. Review recent events",
        "kubectl get events -A --sort-by=.lastTimestamp",
        "",
        "# 3. Verify deployment rollout",
        "kubectl rollout status deployment/<deployment-name> -n <namespace>",
        "",
        "# 4. Check ingress resources",
        "kubectl get ingress -A",
        "",
        "# 5. Check ALB target health",
        "aws elbv2 describe-target-health --target-group-arn <target-group-arn>",
        "",
        "# 6. Tail affected workload logs",
        "kubectl logs deployment/<deployment-name> -n <namespace> --tail=100",
        "",
        "# 7. Verify node health",
        "kubectl get nodes",
        "```",
        "",
    ]

    # -----------------------------------------------------------------------
    # 9. Escalation Notes
    # -----------------------------------------------------------------------
    lines += ["## 9. Escalation Notes", ""]

    default_escalation = [
        "Escalate to AWS Support or the platform team if:",
        "",
        "- IAM permissions are missing and cannot be corrected",
        "- AWS service quotas are reached (EC2, EIP, ENI, ALB limits)",
        "- ALB target health remains unhealthy after fix",
        "- Node group capacity is exhausted and scaling is not resolving",
        "- Application code itself is failing (database, external API dependency)",
        "- EKS add-on upgrades are failing",
        "- Persistent DNS failures despite CoreDNS restart",
        "- Subnet IP exhaustion requires VPC CIDR expansion",
    ]

    if report.escalation_notes:
        for note in report.escalation_notes:
            lines.append(f"- {note}")
        lines.append("")

    lines += default_escalation
    lines.append("")

    return "\n".join(lines)


def save_report(report_text: str, output_path: str | Path = "eks-incident-report.md") -> Path:
    """Write the Markdown report to disk and return the path."""
    path = Path(output_path)
    path.write_text(report_text, encoding="utf-8")
    return path
