"""
Analyzers — parse raw command output and produce structured Finding objects.

Each analyzer inspects one or more CommandResult values and appends
Finding items to the provided list.  Analyzers are pure functions:
they never run commands, they only read already-collected results.
"""

from __future__ import annotations

import json
import re
from typing import Optional

from agent.models import CommandResult, DiagnosisReport, Finding, Severity

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

_FIX_COUNTER = 0


def _next_fix_id() -> str:
    global _FIX_COUNTER
    _FIX_COUNTER += 1
    return f"FIX-{_FIX_COUNTER:03d}"


def _get(report: DiagnosisReport, command_fragment: str) -> Optional[CommandResult]:
    """Return the first CommandResult whose command string contains the fragment."""
    for cmd, result in report.raw_results.items():
        if command_fragment in cmd:
            return result
    return None


def _get_all(report: DiagnosisReport, command_fragment: str) -> list[CommandResult]:
    """Return all CommandResults whose command contains the fragment."""
    return [r for cmd, r in report.raw_results.items() if command_fragment in cmd]


# ---------------------------------------------------------------------------
# Pod issue patterns
# ---------------------------------------------------------------------------

_POD_ISSUE_PATTERNS: list[tuple[str, Severity, str, str]] = [
    (
        r"CrashLoopBackOff",
        Severity.CRITICAL,
        "Container is crash-looping. The application is repeatedly crashing and restarting.",
        "Check pod logs and previous logs. Verify env vars, ConfigMaps, Secrets, and probe configs.",
    ),
    (
        r"ImagePullBackOff|ErrImagePull",
        Severity.HIGH,
        "Kubernetes cannot pull the container image.",
        "Verify image name, tag, ECR permissions, imagePullSecrets, and NAT/internet access.",
    ),
    (
        r"CreateContainerConfigError",
        Severity.HIGH,
        "Container configuration error — missing ConfigMap or Secret.",
        "Check that all referenced ConfigMaps and Secrets exist in the namespace.",
    ),
    (
        r"CreateContainerError",
        Severity.HIGH,
        "Container could not be created.",
        "Inspect pod events with kubectl describe pod. Check securityContext and volume mounts.",
    ),
    (
        r"OOMKilled",
        Severity.HIGH,
        "Container was killed due to out-of-memory.",
        "Increase memory limits or reduce memory usage. Review application memory configuration.",
    ),
    (
        r"\bEvicted\b",
        Severity.MEDIUM,
        "Pod was evicted, likely due to node resource pressure.",
        "Check node disk/memory pressure. Review eviction thresholds.",
    ),
    (
        r"\bPending\b",
        Severity.MEDIUM,
        "Pod is stuck in Pending state.",
        "Check node capacity, taints/tolerations, affinity rules, PVCs, and autoscaler.",
    ),
    (
        r"Error\b",
        Severity.MEDIUM,
        "Pod is in Error state.",
        "Inspect logs and events for the failing pod.",
    ),
]


def analyze_pods(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "kubectl get pods -A")
    if result is None or not result.stdout:
        return findings

    for line in result.stdout.splitlines():
        if not line or line.startswith("NAMESPACE"):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        namespace, pod_name, *rest = parts
        status_field = parts[3] if len(parts) > 3 else ""

        for pattern, severity, impact, fix in _POD_ISSUE_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                fix_cmd = None
                rollback_cmd = None
                if "CrashLoopBackOff" in line or "Error" in status_field:
                    fix_cmd = f"kubectl logs {pod_name} -n {namespace} --previous --tail=200"
                elif "ImagePullBackOff" in line or "ErrImagePull" in line:
                    fix_cmd = f"kubectl describe pod {pod_name} -n {namespace}"
                elif "OOMKilled" in line:
                    fix_cmd = (
                        f"kubectl patch deployment <deployment> -n {namespace} "
                        "--type=json -p '[{\"op\":\"replace\",\"path\":\"/spec/template/spec/containers/0/resources/limits/memory\",\"value\":\"512Mi\"}]'"
                    )
                    rollback_cmd = "# Revert to previous resource limits via helm upgrade or kubectl patch"

                findings.append(
                    Finding(
                        component="Pods",
                        namespace=namespace,
                        resource=pod_name,
                        severity=severity,
                        evidence=line.strip(),
                        impact=impact,
                        recommended_fix=fix,
                        fix_command=fix_cmd,
                        rollback_command=rollback_cmd,
                        fix_id=_next_fix_id(),
                    )
                )
                break  # Only first match per pod line

    return findings


# ---------------------------------------------------------------------------
# Node issues
# ---------------------------------------------------------------------------

_NODE_CONDITION_PATTERNS = [
    ("NotReady", Severity.CRITICAL, "Node is NotReady — pods cannot be scheduled."),
    ("MemoryPressure", Severity.HIGH, "Node is under memory pressure."),
    ("DiskPressure", Severity.HIGH, "Node is under disk pressure."),
    ("PIDPressure", Severity.MEDIUM, "Node is under PID pressure."),
    ("NetworkUnavailable", Severity.CRITICAL, "Node network is unavailable."),
]


def analyze_nodes(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "kubectl get nodes")
    if result is None or not result.stdout:
        return findings

    for line in result.stdout.splitlines():
        if not line or line.startswith("NAME"):
            continue
        for condition, severity, impact in _NODE_CONDITION_PATTERNS:
            if condition in line:
                node_name = line.split()[0]
                findings.append(
                    Finding(
                        component="Nodes",
                        namespace="cluster",
                        resource=node_name,
                        severity=severity,
                        evidence=line.strip(),
                        impact=impact,
                        recommended_fix=(
                            f"Investigate node {node_name}: kubectl describe node {node_name}"
                        ),
                        fix_command=f"kubectl describe node {node_name}",
                        fix_id=_next_fix_id(),
                    )
                )
    return findings


# ---------------------------------------------------------------------------
# Service endpoint issues
# ---------------------------------------------------------------------------

def analyze_services(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "kubectl get endpoints -A")
    if result is None or not result.stdout:
        return findings

    for line in result.stdout.splitlines():
        if not line or line.startswith("NAMESPACE"):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        namespace, svc_name, endpoints_field = parts[0], parts[1], parts[2]
        if endpoints_field == "<none>" and svc_name not in ("kubernetes",):
            findings.append(
                Finding(
                    component="Services",
                    namespace=namespace,
                    resource=svc_name,
                    severity=Severity.HIGH,
                    evidence=line.strip(),
                    impact=(
                        f"Service '{svc_name}' in namespace '{namespace}' has no endpoints. "
                        "Traffic will not be routed to any pod."
                    ),
                    recommended_fix=(
                        "Verify that pod labels match the service selector. "
                        "Check pod readiness. Run: "
                        f"kubectl describe svc {svc_name} -n {namespace}"
                    ),
                    fix_command=f"kubectl describe svc {svc_name} -n {namespace}",
                    fix_id=_next_fix_id(),
                )
            )
    return findings


# ---------------------------------------------------------------------------
# PVC issues
# ---------------------------------------------------------------------------

def analyze_storage(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "kubectl get pvc -A")
    if result is None or not result.stdout:
        return findings

    for line in result.stdout.splitlines():
        if not line or line.startswith("NAMESPACE"):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        namespace, pvc_name = parts[0], parts[1]
        status = parts[2] if len(parts) > 2 else ""
        if status == "Pending":
            findings.append(
                Finding(
                    component="Storage",
                    namespace=namespace,
                    resource=pvc_name,
                    severity=Severity.HIGH,
                    evidence=line.strip(),
                    impact=(
                        f"PVC '{pvc_name}' in namespace '{namespace}' is Pending. "
                        "Pods depending on this PVC cannot start."
                    ),
                    recommended_fix=(
                        "Check StorageClass, EBS CSI driver health, IAM permissions, "
                        "and volume availability zone. "
                        f"Run: kubectl describe pvc {pvc_name} -n {namespace}"
                    ),
                    fix_command=f"kubectl describe pvc {pvc_name} -n {namespace}",
                    fix_id=_next_fix_id(),
                )
            )
    return findings


# ---------------------------------------------------------------------------
# ALB / target group health
# ---------------------------------------------------------------------------

def analyze_alb(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "describe-target-groups")
    if result is None or not result.success:
        return findings

    # Parse target group ARNs to check later
    tg_arns: list[str] = []
    try:
        data = json.loads(result.stdout)
        for tg in data.get("TargetGroups", []):
            tg_arns.append(tg.get("TargetGroupArn", ""))
    except (json.JSONDecodeError, KeyError):
        pass

    # Check for any target-health results we have
    for cmd, res in report.raw_results.items():
        if "describe-target-health" in cmd and res.success:
            try:
                health_data = json.loads(res.stdout)
                for desc in health_data.get("TargetHealthDescriptions", []):
                    state = desc.get("TargetHealth", {}).get("State", "")
                    reason = desc.get("TargetHealth", {}).get("Reason", "")
                    target_id = desc.get("Target", {}).get("Id", "unknown")
                    if state not in ("healthy", "initial"):
                        findings.append(
                            Finding(
                                component="Ingress / ALB",
                                namespace="aws",
                                resource=target_id,
                                severity=Severity.HIGH,
                                evidence=f"State={state}, Reason={reason}",
                                impact="ALB target is unhealthy. Traffic is not being routed to this target.",
                                recommended_fix=(
                                    "Check pod readiness, health check path, security groups, "
                                    "and ALB controller logs."
                                ),
                                fix_id=_next_fix_id(),
                            )
                        )
            except (json.JSONDecodeError, KeyError):
                pass

    return findings


# ---------------------------------------------------------------------------
# ALB controller log analysis
# ---------------------------------------------------------------------------

_ALB_CTRL_ERROR_PATTERNS: list[tuple[str, Severity, str]] = [
    (
        r"AccessDenied|UnauthorizedAccess|is not authorized",
        Severity.CRITICAL,
        "ALB controller is denied AWS API access. Check IRSA role and IAM policy.",
    ),
    (
        r"failed to reconcile",
        Severity.HIGH,
        "ALB controller reconciliation failure. Ingress or TargetGroupBinding may not be synced.",
    ),
    (
        r"InvalidSubnet|subnet.*not found",
        Severity.HIGH,
        "ALB controller cannot find subnets. Verify subnet tags for ALB.",
    ),
    (
        r"certificate.*not found|ACM",
        Severity.HIGH,
        "ACM certificate issue. Verify certificate ARN annotation on Ingress.",
    ),
    (
        r"error.*ingress|ingress.*error",
        Severity.MEDIUM,
        "Generic ingress error in ALB controller.",
    ),
]


def analyze_alb_controller_logs(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "deployment/aws-load-balancer-controller")
    if result is None or not result.stdout:
        return findings

    for pattern, severity, impact in _ALB_CTRL_ERROR_PATTERNS:
        matches = re.findall(rf"(.{{0,120}}{pattern}.{{0,120}})", result.stdout, re.IGNORECASE)
        if matches:
            evidence_sample = matches[0].strip()
            findings.append(
                Finding(
                    component="AWS Load Balancer Controller",
                    namespace="kube-system",
                    resource="aws-load-balancer-controller",
                    severity=severity,
                    evidence=evidence_sample,
                    impact=impact,
                    recommended_fix=(
                        "Review ALB controller logs in full. "
                        "Verify IRSA annotation, IAM role trust policy, and attached policies."
                    ),
                    fix_id=_next_fix_id(),
                )
            )
    return findings


# ---------------------------------------------------------------------------
# CoreDNS issues
# ---------------------------------------------------------------------------

def analyze_coredns(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "k8s-app=kube-dns")
    if result is None or not result.stdout:
        return findings

    error_patterns = [
        (r"SERVFAIL|NXDOMAIN", Severity.HIGH, "CoreDNS is returning DNS errors."),
        (r"timeout|i/o timeout", Severity.HIGH, "CoreDNS upstream DNS timeouts detected."),
        (r"plugin/errors", Severity.MEDIUM, "CoreDNS error plugin triggered."),
    ]
    for pattern, severity, impact in error_patterns:
        if re.search(pattern, result.stdout, re.IGNORECASE):
            findings.append(
                Finding(
                    component="DNS",
                    namespace="kube-system",
                    resource="coredns",
                    severity=severity,
                    evidence=re.search(rf".{{0,200}}{pattern}.{{0,200}}", result.stdout, re.IGNORECASE).group(0).strip(),  # type: ignore[union-attr]
                    impact=impact,
                    recommended_fix="Restart CoreDNS pods and review upstream DNS configuration.",
                    fix_command="kubectl rollout restart deployment/coredns -n kube-system",
                    rollback_command="kubectl rollout undo deployment/coredns -n kube-system",
                    fix_id=_next_fix_id(),
                )
            )
    return findings


# ---------------------------------------------------------------------------
# VPC CNI / IP exhaustion
# ---------------------------------------------------------------------------

def analyze_vpc_cni(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "k8s-app=aws-node")
    if result is None or not result.stdout:
        return findings

    ip_patterns = [
        (
            r"InsufficientFreeAddressesInSubnet|no free address",
            Severity.CRITICAL,
            "Subnet IP address exhaustion. No free IPs available for new pods.",
        ),
        (
            r"Failed to get.*IP|failed to assign",
            Severity.HIGH,
            "VPC CNI failed to assign a pod IP address.",
        ),
        (
            r"ipamd.*error|IPAMD.*error",
            Severity.HIGH,
            "IPAMD (IP Address Management Daemon) error in aws-node.",
        ),
    ]
    for pattern, severity, impact in ip_patterns:
        if re.search(pattern, result.stdout, re.IGNORECASE):
            findings.append(
                Finding(
                    component="Networking",
                    namespace="kube-system",
                    resource="aws-node",
                    severity=severity,
                    evidence=re.search(rf".{{0,200}}{pattern}.{{0,200}}", result.stdout, re.IGNORECASE).group(0).strip(),  # type: ignore[union-attr]
                    impact=impact,
                    recommended_fix=(
                        "Check subnet available IPs. Consider enabling VPC CNI prefix delegation "
                        "or adding new subnets to the nodegroup."
                    ),
                    fix_id=_next_fix_id(),
                )
            )
    return findings


# ---------------------------------------------------------------------------
# IRSA / STS errors
# ---------------------------------------------------------------------------

def analyze_irsa(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    # Scan all pod logs for IRSA errors
    for cmd, result in report.raw_results.items():
        if "kubectl logs" not in cmd or not result.stdout:
            continue
        irsa_patterns = [
            (
                r"AssumeRoleWithWebIdentity|WebIdentityErr",
                Severity.HIGH,
                "IRSA AssumeRoleWithWebIdentity failure in pod logs.",
            ),
            (
                r"AccessDenied",
                Severity.HIGH,
                "AWS AccessDenied error in pod logs. Check IAM role and IRSA setup.",
            ),
            (
                r"ExpiredToken|token.*expired",
                Severity.HIGH,
                "AWS token expiration detected. Check IRSA token rotation or node IAM role.",
            ),
        ]
        for pattern, severity, impact in irsa_patterns:
            if re.search(pattern, result.stdout, re.IGNORECASE):
                findings.append(
                    Finding(
                        component="IAM / IRSA",
                        namespace="unknown",
                        resource=cmd,
                        severity=severity,
                        evidence=re.search(rf".{{0,200}}{pattern}.{{0,200}}", result.stdout, re.IGNORECASE).group(0).strip(),  # type: ignore[union-attr]
                        impact=impact,
                        recommended_fix=(
                            "Verify ServiceAccount has eks.amazonaws.com/role-arn annotation. "
                            "Check IAM role trust policy and OIDC provider configuration."
                        ),
                        fix_id=_next_fix_id(),
                    )
                )
    return findings


# ---------------------------------------------------------------------------
# Events analysis
# ---------------------------------------------------------------------------

_EVENT_WARN_PATTERNS: list[tuple[str, Severity, str]] = [
    (r"FailedScheduling", Severity.HIGH, "Pod scheduling failure detected in events."),
    (r"FailedMount|MountVolume", Severity.HIGH, "Volume mount failure in events."),
    (r"BackOff", Severity.HIGH, "Back-off restarting failed container."),
    (r"FailedCreate", Severity.HIGH, "ReplicaSet failed to create pods."),
    (r"Unhealthy", Severity.MEDIUM, "Readiness or liveness probe failure."),
    (r"OOMKilling", Severity.HIGH, "OOM kill event detected on node."),
    (r"NodeNotReady", Severity.CRITICAL, "Node is not ready — event recorded."),
    (r"FreeDiskSpaceFailed|DiskPressure", Severity.HIGH, "Disk pressure detected."),
]


def analyze_events(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "get events -A")
    if result is None or not result.stdout:
        return findings

    seen: set[str] = set()
    for line in result.stdout.splitlines():
        for pattern, severity, impact in _EVENT_WARN_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                # Deduplicate by pattern+first 60 chars of line
                key = pattern + line[:60]
                if key not in seen:
                    seen.add(key)
                    parts = line.split()
                    ns = parts[0] if len(parts) > 0 else "unknown"
                    findings.append(
                        Finding(
                            component="Logs and Events",
                            namespace=ns,
                            resource="event",
                            severity=severity,
                            evidence=line.strip()[:300],
                            impact=impact,
                            recommended_fix=(
                                "Investigate specific resource mentioned in the event. "
                                "Run kubectl describe on the affected resource."
                            ),
                            fix_id=_next_fix_id(),
                        )
                    )
    return findings


# ---------------------------------------------------------------------------
# Deployment health
# ---------------------------------------------------------------------------

def analyze_deployments(report: DiagnosisReport) -> list[Finding]:
    findings: list[Finding] = []
    result = _get(report, "kubectl get deploy -A")
    if result is None or not result.stdout:
        return findings

    for line in result.stdout.splitlines():
        if not line or line.startswith("NAMESPACE"):
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        namespace, name = parts[0], parts[1]
        try:
            ready_str = parts[2]   # e.g. "2/3"
            desired_str = parts[3] # DESIRED
            available_str = parts[4] if len(parts) > 4 else parts[3]
            if "/" in ready_str:
                ready, total = ready_str.split("/")
                if int(ready) < int(total):
                    findings.append(
                        Finding(
                            component="Deployments",
                            namespace=namespace,
                            resource=name,
                            severity=Severity.HIGH,
                            evidence=line.strip(),
                            impact=(
                                f"Deployment '{name}' in '{namespace}' has {ready}/{total} ready replicas."
                            ),
                            recommended_fix=(
                                f"Investigate pods for deployment {name}: "
                                f"kubectl get pods -n {namespace} -l app={name}"
                            ),
                            fix_command=(
                                f"kubectl rollout restart deployment/{name} -n {namespace}"
                            ),
                            rollback_command=(
                                f"kubectl rollout undo deployment/{name} -n {namespace}"
                            ),
                            fix_id=_next_fix_id(),
                        )
                    )
        except (ValueError, IndexError):
            continue

    return findings


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_all_analyzers(report: DiagnosisReport) -> list[Finding]:
    """
    Run every analyzer against the DiagnosisReport and return combined findings.
    The report's findings list is also updated in-place.
    """
    all_findings: list[Finding] = []

    analyzers = [
        analyze_nodes,
        analyze_pods,
        analyze_deployments,
        analyze_services,
        analyze_alb,
        analyze_alb_controller_logs,
        analyze_coredns,
        analyze_vpc_cni,
        analyze_irsa,
        analyze_storage,
        analyze_events,
    ]

    for analyzer in analyzers:
        try:
            results = analyzer(report)
            all_findings.extend(results)
        except Exception as exc:  # noqa: BLE001
            import logging
            logging.getLogger(__name__).error("Analyzer %s failed: %s", analyzer.__name__, exc)

    report.findings.extend(all_findings)

    # Derive root cause from highest-severity findings
    if report.findings:
        critical = [f for f in report.findings if f.severity == Severity.CRITICAL]
        high = [f for f in report.findings if f.severity == Severity.HIGH]
        top = critical or high
        if top:
            top_finding = top[0]
            report.root_cause = (
                f"Most likely root cause: [{top_finding.severity.value}] "
                f"{top_finding.component} — {top_finding.resource} — {top_finding.impact}"
            )
        else:
            report.root_cause = (
                "Root cause is not fully confirmed. "
                "No critical or high-severity issues detected in collected data. "
                "Review medium/low findings and examine application-specific logs."
            )
    else:
        report.root_cause = (
            "No issues detected in automated analysis. "
            "The cluster appears healthy based on the data collected. "
            "For intermittent issues, review raw command outputs and CloudWatch metrics."
        )

    return all_findings
