"""
Safe command execution wrapper.
Never uses shell=True.
Captures stdout/stderr, handles timeouts, and logs all executions.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import time
from typing import Optional

from agent.models import CommandResult

logger = logging.getLogger(__name__)


class ToolNotFoundError(Exception):
    """Raised when a required CLI tool is not installed or not on PATH."""


class CommandExecutor:
    """
    Executes external commands safely.

    - Never uses shell=True
    - Always passes commands as list[str]
    - Captures stdout and stderr separately
    - Enforces per-command timeouts
    - Validates that the binary exists before execution
    """

    REQUIRED_TOOLS: dict[str, str] = {
        "kubectl": "https://kubernetes.io/docs/tasks/tools/",
        "aws": "https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html",
        "helm": "https://helm.sh/docs/intro/install/",
    }

    def __init__(self, dry_run: bool = False) -> None:
        self.dry_run = dry_run
        self._tool_cache: dict[str, bool] = {}

    def check_tool(self, tool: str) -> bool:
        """Return True if the tool binary is available on PATH."""
        if tool not in self._tool_cache:
            self._tool_cache[tool] = shutil.which(tool) is not None
        return self._tool_cache[tool]

    def assert_tool(self, tool: str) -> None:
        """Raise ToolNotFoundError if the tool is not available."""
        if not self.check_tool(tool):
            install_url = self.REQUIRED_TOOLS.get(tool, "")
            hint = f" Install from: {install_url}" if install_url else ""
            raise ToolNotFoundError(
                f"'{tool}' is not installed or not found on PATH.{hint}"
            )

    def run(
        self,
        command: list[str],
        timeout: int = 120,
        env: Optional[dict[str, str]] = None,
    ) -> CommandResult:
        """
        Execute a command safely without shell=True.

        Args:
            command:  Command as a list of strings, e.g. ["kubectl", "get", "pods", "-A"]
            timeout:  Maximum seconds to wait before raising subprocess.TimeoutExpired.
            env:      Optional environment variable overrides.

        Returns:
            CommandResult with stdout, stderr, and returncode.
        """
        if not command:
            raise ValueError("command must be a non-empty list of strings")

        binary = command[0]
        cmd_str = " ".join(command)

        # Validate binary existence for known tools
        if binary in self.REQUIRED_TOOLS:
            self.assert_tool(binary)

        if self.dry_run:
            logger.info("[DRY-RUN] Would execute: %s", cmd_str)
            return CommandResult(
                command=cmd_str,
                stdout="[dry-run: command not executed]",
                stderr="",
                returncode=0,
            )

        logger.info("Executing: %s", cmd_str)
        start = time.monotonic()

        try:
            proc = subprocess.run(  # noqa: S603 – shell=False is explicit
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                shell=False,  # explicit – never shell=True
                env=env,
            )
            elapsed = time.monotonic() - start
            stdout = proc.stdout.decode("utf-8", errors="replace").strip()
            stderr = proc.stderr.decode("utf-8", errors="replace").strip()

            logger.debug(
                "Command finished in %.1fs rc=%d: %s", elapsed, proc.returncode, cmd_str
            )
            if proc.returncode != 0:
                logger.warning("Non-zero exit %d for: %s", proc.returncode, cmd_str)
                if stderr:
                    logger.debug("stderr: %s", stderr[:500])

            return CommandResult(
                command=cmd_str,
                stdout=stdout,
                stderr=stderr,
                returncode=proc.returncode,
            )

        except subprocess.TimeoutExpired:
            logger.error("Timeout (%ds) expired for: %s", timeout, cmd_str)
            return CommandResult(
                command=cmd_str,
                stdout="",
                stderr=f"Command timed out after {timeout} seconds.",
                returncode=-1,
            )
        except FileNotFoundError:
            logger.error("Binary not found: %s", binary)
            return CommandResult(
                command=cmd_str,
                stdout="",
                stderr=f"'{binary}' binary not found. Is it installed and on PATH?",
                returncode=-2,
            )
        except OSError as exc:
            logger.error("OS error running %s: %s", cmd_str, exc)
            return CommandResult(
                command=cmd_str,
                stdout="",
                stderr=str(exc),
                returncode=-3,
            )
