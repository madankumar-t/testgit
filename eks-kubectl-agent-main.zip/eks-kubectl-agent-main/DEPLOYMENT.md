# EKS Kubectl Agent — Deployment Guide

> **Deployment model:** Everything is deployed via a **single `terraform apply`** from the
> central/management AWS account. Exceptions where Terraform cannot act autonomously are
> called out explicitly in each step with the manual commands required.

---

## Table of Contents

1. [Deployment Architecture](#1-deployment-architecture)
2. [Networking Architecture](#2-networking-architecture)
3. [Multi-Account · Multi-Region · Multi-Cluster Model](#3-multi-account--multi-region--multi-cluster-model)
4. [Prerequisites](#4-prerequisites)
5. [Step 1 — Prepare terraform.tfvars](#5-step-1--prepare-terraformtfvars)
6. [Step 2 — Verify Bootstrap Access to Member Accounts](#6-step-2--verify-bootstrap-access-to-member-accounts)
7. [Step 3 — terraform apply (full stack)](#7-step-3--terraform-apply-full-stack)
8. [Step 4 — EKS Cluster Access (Exception)](#8-step-4--eks-cluster-access-exception)
9. [Step 5 — Deploy Frontend via Terraform](#9-step-5--deploy-frontend-via-terraform)
10. [Step 6 — Verify End-to-End](#10-step-6--verify-end-to-end)
11. [Step 7 — CLI Agent (Optional, Local)](#11-step-7--cli-agent-optional-local)
12. [Terraform Automation Summary](#12-terraform-automation-summary)
13. [Day-2 Operations](#13-day-2-operations)
14. [Variable Reference](#14-variable-reference)
15. [Troubleshooting](#15-troubleshooting)

---

## 1. Deployment Architecture

```
┌──────────────────────────────────────────────────────────────────────────────────────┐
│                        CENTRAL AWS ACCOUNT  (management / hub)                       │
│                                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │  All resources deployed by a single  terraform apply                            │ │
│  │                                                                                  │ │
│  │  ┌──────────────────────────┐     ┌──────────────────────────────────────────┐  │ │
│  │  │  CloudFront Distribution │     │  API Gateway HTTP API  (HTTPS)           │  │ │
│  │  │  ├─ /*    → S3 frontend  │────▶│  ├─ GET  /accounts                      │  │ │
│  │  │  └─ /api/* → API Gateway │     │  ├─ GET  /clusters                      │  │ │
│  │  └──────────────────────────┘     │  ├─ POST /diagnose/start                │  │ │
│  │              │                    │  ├─ GET  /diagnose/status/{id}           │  │ │
│  │  ┌───────────▼──────────────┐     │  ├─ GET  /logs/{id}                     │  │ │
│  │  │  S3 Bucket (private)     │     │  └─ POST /fixes/apply                   │  │ │
│  │  │  Next.js static export   │     └────────────────┬─────────────────────────┘  │ │
│  │  │  OAC — no public access  │                      │ invokes                     │ │
│  │  └──────────────────────────┘     ┌────────────────▼─────────────────────────┐  │ │
│  │                                   │  Lambda Functions (arm64, Python 3.12)   │  │ │
│  │  ┌──────────────────────────┐     │  VPC-attached — private subnets          │  │ │
│  │  │  DynamoDB                │◀────│  ├─ list_accounts   (sync)               │  │ │
│  │  │  eks-agent-jobs          │     │  ├─ list_clusters   (sync, all regions)  │  │ │
│  │  │  PAY_PER_REQUEST         │────▶│  ├─ diagnose_start  (sync → async)       │  │ │
│  │  │  PITR + TTL 24 h + SSE   │     │  ├─ diagnose_worker (async, ≤15 min)    │  │ │
│  │  └──────────────────────────┘     │  ├─ diagnose_status (sync)               │  │ │
│  │                                   │  ├─ get_logs        (sync)               │  │ │
│  │  ┌──────────────────────────┐     │  └─ apply_fix       (sync)               │  │ │
│  │  │  Lambda Layer            │     └────────────────┬─────────────────────────┘  │ │
│  │  │  boto3 + kubernetes SDK  │                      │ sts:AssumeRole              │ │
│  │  │  + shared/ modules       │                      │ per spoke account           │ │
│  │  └──────────────────────────┘                      ▼                             │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────────────────────┘
                                           │
              ┌────────────────────────────┼─────────────────────────────┐
              │                            │                             │
              ▼                            ▼                             ▼
┌──────────────────────┐    ┌──────────────────────┐    ┌──────────────────────┐
│  SPOKE ACCOUNT A     │    │  SPOKE ACCOUNT B     │    │  SPOKE ACCOUNT N     │
│  Production          │    │  Staging             │    │  Dev                 │
│                      │    │                      │    │                      │
│  eks-agent-          │    │  eks-agent-          │    │  eks-agent-          │
│  spoke-role          │    │  spoke-role          │    │  spoke-role          │
│  (CloudFormation,    │    │  (CloudFormation,    │    │  (CloudFormation,    │
│   via Terraform)     │    │   via Terraform)     │    │   via Terraform)     │
│         │            │    │         │            │    │         │            │
│  ┌──────▼──────┐     │    │  ┌──────▼──────┐    │    │  ┌──────▼──────┐    │
│  │ EKS Cluster │     │    │  │ EKS Cluster │    │    │  │ EKS Cluster │    │
│  │ us-east-1   │     │    │  │ us-east-1   │    │    │  │ eu-west-1   │    │
│  ├─────────────┤     │    │  ├─────────────┤    │    │  ├─────────────┤    │
│  │ EKS Cluster │     │    │  │ EKS Cluster │    │    │  │ EKS Cluster │    │
│  │ us-west-2   │     │    │  │ us-west-2   │    │    │  │ ap-southeast│    │
│  ├─────────────┤     │    │  └─────────────┘    │    │  └─────────────┘    │
│  │ EKS Cluster │     │    │                      │    │                      │
│  │ eu-west-1   │     │    │                      │    │                      │
│  └─────────────┘     │    │                      │    │                      │
└──────────────────────┘    └──────────────────────┘    └──────────────────────┘
```

### Component Responsibility

| Component | Technology | Deployed By | Location |
|-----------|-----------|-------------|----------|
| **Frontend UI** | Next.js 14 static export | Terraform (`null_resource` npm build + S3 upload) | S3 + CloudFront |
| **API layer** | API Gateway HTTP API | Terraform | Central account |
| **Lambda functions** (7) | Python 3.12, arm64 | Terraform (`archive_file` auto-zip) | Central account VPC |
| **Lambda layer** | boto3 + kubernetes SDK + shared modules | Terraform (`null_resource` pip build) | Central account |
| **Job store** | DynamoDB PAY_PER_REQUEST | Terraform | Central account |
| **Spoke IAM roles** | CloudFormation stacks | Terraform (`null_resource` → `deploy_spoke_roles.py`) | Every member account |
| **Networking** | VPC / Subnets / NAT GW / TGW attachment | Terraform (optional — bring-your-own supported) | Central account |
| **EKS cluster access** | EKS Access Entries or aws-auth ConfigMap | **Manual — see Step 4 (Exception)** | Each spoke cluster |
| **CLI Agent** | Python 3.12 + Typer | `pip install` (local workstation) | Local / bastion |

---

## 2. Networking Architecture

```
  ┌────────────────────────────────────────────────────────────────────────────────┐
  │  CENTRAL AWS ACCOUNT VPC  (10.100.0.0/16 — or existing VPC)                   │
  │                                                                                 │
  │  ┌───────────────────────────────┐   ┌────────────────────────────────────┐    │
  │  │  Private Subnet AZ-1          │   │  Private Subnet AZ-2               │    │
  │  │  10.100.10.0/24               │   │  10.100.11.0/24                    │    │
  │  │                               │   │                                    │    │
  │  │  Lambda ENI                   │   │  Lambda ENI                        │    │
  │  │  Security Group:              │   │  Security Group:                   │    │
  │  │  egress 443 → spoke CIDRs     │   │  egress 443 → spoke CIDRs          │    │
  │  └─────────────┬─────────────────┘   └───────────────┬────────────────────┘    │
  │                │                                     │                          │
  │  ┌─────────────▼─────────────────────────────────────▼────────────────────┐    │
  │  │  Route Table (private subnets)                                          │    │
  │  │  0.0.0.0/0          → NAT Gateway    (public AWS API calls)             │    │
  │  │  10.0.0.0/8         → TGW            (spoke EKS private endpoints)     │    │
  │  │  dynamodb endpoint  → VPC GW EP      (free — no NAT cost)               │    │
  │  │  s3 endpoint        → VPC GW EP      (free — no NAT cost)               │    │
  │  └────────────────────────────────────────────────────────────────────────┘    │
  │                                          │ default route                        │
  │  ┌───────────────────────────────┐       │                                     │
  │  │  Public Subnet AZ-1           │◀──────┘                                     │
  │  │  NAT Gateway ── EIP           │                                             │
  │  │  Internet Gateway             │──────────────────────────────────────────▶  │
  │  └───────────────────────────────┘  Internet (STS / EKS mgmt / CloudWatch)     │
  │                                                                                 │
  │  ┌────────────────────────────────────────────────────────────────────────┐     │
  │  │  VPC Interface Endpoints (optional — create_vpc_endpoints = true)      │     │
  │  │  com.amazonaws.*.sts    com.amazonaws.*.eks    com.amazonaws.*.ec2      │     │
  │  │  com.amazonaws.*.elasticloadbalancing          com.amazonaws.*.logs     │     │
  │  └────────────────────────────────────────────────────────────────────────┘     │
  └──────────────────────────────────────┬─────────────────────────────────────────┘
                                         │
                              ┌──────────▼──────────┐
                              │  Transit Gateway     │
                              │  (shared / existing) │
                              └──────────┬───────────┘
              ┌──────────────────────────┼─────────────────────────┐
              │                          │                         │
  ┌───────────▼────────────┐  ┌──────────▼──────────┐  ┌──────────▼──────────┐
  │  SPOKE VPC A           │  │  SPOKE VPC B         │  │  SPOKE VPC N        │
  │  10.0.0.0/16           │  │  10.1.0.0/16         │  │  10.N.0.0/16        │
  │  Account: Production   │  │  Account: Staging    │  │  Account: Dev       │
  │                        │  │                      │  │                     │
  │  ┌──────────────────┐  │  │  ┌────────────────┐  │  │  ┌───────────────┐  │
  │  │ EKS Cluster      │  │  │  │ EKS Cluster    │  │  │  │ EKS Cluster   │  │
  │  │ Private API EP   │  │  │  │ Private API EP │  │  │  │ Private API EP│  │
  │  │ :443             │  │  │  │ :443           │  │  │  │ :443          │  │
  │  └──────────────────┘  │  │  └────────────────┘  │  │  └───────────────┘  │
  │  ┌──────────────────┐  │  │                      │  │  ┌───────────────┐  │
  │  │ EKS Cluster 2    │  │  │                      │  │  │ EKS Cluster 2 │  │
  │  │ Private API EP   │  │  │                      │  │  │ Private API EP│  │
  │  └──────────────────┘  │  │                      │  │  └───────────────┘  │
  └────────────────────────┘  └──────────────────────┘  └─────────────────────┘
```

### Networking Modes

| Mode | When to Use | Key Terraform Variable |
|------|------------|----------------------|
| **Bring-your-own VPC** (default) | Existing VPC with private subnets, NAT GW, and TGW/peering connectivity to spoke accounts | `create_networking = false` |
| **Terraform-created VPC** | Fresh account or isolated test environment | `create_networking = true` |
| **Attach to existing TGW** | Central VPC not yet attached to the shared TGW | `attach_to_existing_tgw = true` |

### Port & Protocol Matrix

| Traffic Flow | Source | Destination | Port |
|-------------|--------|-------------|------|
| User → Frontend | Browser | CloudFront URL | 443 HTTPS |
| User → API | Browser | CloudFront `/api/*` | 443 HTTPS |
| CloudFront → API Gateway | CloudFront edge | API Gateway endpoint | 443 HTTPS |
| Lambda → EKS private API | Lambda ENI (central VPC) | EKS private endpoint (spoke VPC via TGW) | 443 HTTPS |
| Lambda → AWS APIs | Lambda ENI | STS / EKS / EC2 / ELB / IAM | 443 HTTPS |
| Lambda → DynamoDB | Lambda ENI | DynamoDB VPC Gateway Endpoint | 443 HTTPS |

---

## 3. Multi-Account · Multi-Region · Multi-Cluster Model

### Configuration (single place to manage everything)

```hcl
# terraform.tfvars

spoke_accounts = {
  "111122223333" = "Production"
  "444455556666" = "Staging"
  "777788889999" = "Dev"
  "000011112222" = "Sandbox"
}

eks_regions = "us-east-1,us-east-2,us-west-2,eu-west-1,eu-central-1,ap-southeast-1"
```

### How the Fan-Out Works at Runtime

```
Browser / API call
       │
       ▼
API Gateway → Lambda (list_clusters)
       │
       │  For EACH account in spoke_accounts:
       │    sts:AssumeRole → eks-agent-spoke-role in that account
       │      │
       │      │  For EACH region in eks_regions:
       │      │    eks:ListClusters + eks:DescribeCluster
       │      │      → returns all clusters found
       │
       ▼
  UI shows: Account A / us-east-1 / [cluster-1, cluster-2]
            Account A / eu-west-1 / [cluster-3]
            Account B / us-east-1 / [cluster-4]
            ...
```

### Multi-Account Mechanism

Terraform's `null_resource.deploy_spoke_roles` runs `deploy_spoke_roles.py` which:
1. Iterates every key in `spoke_accounts`
2. Assumes `OrganizationAccountAccessRole` in each account
3. Deploys / updates a CloudFormation stack from `infrastructure/member-account/spoke-role.yaml`
4. The stack creates `arn:aws:iam::{account_id}:role/eks-agent-spoke-role`
5. That role trusts the **central Lambda execution role ARN** via `sts:AssumeRole`
6. Triggers automatically when `spoke_accounts` or the CloudFormation template changes

### Multi-Region Mechanism

`eks_regions` is a single Lambda environment variable (`EKS_REGIONS`). There is **no
separate Lambda deployment per region** — the single Lambda deployment handles all
regions at runtime by iterating the list. Adding or removing a region requires only
a `terraform apply` to update the environment variable.

### Multi-Cluster Mechanism

Within each `account_id × region` pair, `list_clusters` calls `eks:ListClusters` and
returns all clusters found. A diagnosis job targets one specific
`account_id + region + cluster_name` triple, stored in DynamoDB. There is no limit
to the number of clusters per account or region.

---

## 4. Prerequisites

| Tool | Min Version | Install |
|------|-------------|---------|
| Terraform | 1.6+ | [developer.hashicorp.com/terraform/downloads](https://developer.hashicorp.com/terraform/downloads) |
| Python | 3.12+ | [python.org](https://python.org) — needed for Lambda layer build + spoke role deployment |
| Node.js | 18+ | [nodejs.org](https://nodejs.org) — needed for frontend build |
| AWS CLI v2 | 2.15+ | [AWS docs](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html) |
| kubectl | 1.29+ | [kubernetes.io/docs/tasks/tools](https://kubernetes.io/docs/tasks/tools/) — CLI agent only |
| helm | 3.x | Optional — CLI agent health checks skip gracefully if missing |

**Install the spoke-role deployment dependency:**

```bash
pip install boto3
```

**Deployer IAM permissions (central / management account):**

```
# Serverless compute
lambda:*  apigateway:*  dynamodb:*  logs:*  xray:*

# Storage / CDN
s3:*  cloudfront:*

# IAM
iam:CreateRole  iam:AttachRolePolicy  iam:PutRolePolicy  iam:GetRole
iam:PassRole  iam:CreateInstanceProfile  iam:DeleteRole  iam:DetachRolePolicy

# EKS / networking reads
eks:*  ec2:Describe*  ec2:CreateVpc  ec2:CreateSubnet  ec2:CreateNatGateway
elasticloadbalancing:Describe*  autoscaling:Describe*

# Identity
sts:GetCallerIdentity  sts:AssumeRole

# CloudFormation (deploys spoke stacks into member accounts)
cloudformation:CreateStack  cloudformation:UpdateStack  cloudformation:DescribeStacks
cloudformation:DescribeStackEvents  cloudformation:DeleteStack  cloudformation:GetTemplate
```

The deployer must also be able to **assume `OrganizationAccountAccessRole`** in every
account listed in `spoke_accounts` (see Step 2).

---

## 5. Step 1 — Prepare terraform.tfvars

```bash
git clone <repo-url>
cd eks-kubectl-agent

cd infrastructure/terraform
cp terraform.tfvars.example terraform.tfvars
```

Edit `terraform.tfvars` with your values:

```hcl
# ── Central account ─────────────────────────────────────────────────────────
aws_region  = "us-east-1"
environment = "prod"               # dev | staging | prod

# ── NETWORKING — choose MODE A or MODE B ─────────────────────────────────────

# MODE A — Bring-your-own VPC (default, recommended for production)
# Subnets must have outbound HTTPS to spoke VPCs via TGW or VPC peering.
create_networking      = false
vpc_subnet_ids         = ["subnet-aaa11111", "subnet-bbb22222"]  # private, 2+ AZs
vpc_security_group_ids = ["sg-ccc33333"]                         # HTTPS 443 egress to spoke CIDRs

# Attach central VPC to an existing Transit Gateway (skip if attachment exists).
attach_to_existing_tgw = false
# existing_tgw_id       = "tgw-0abc123456789"
# existing_vpc_id       = "vpc-0def123456789"  # required when create_networking = false

# MODE B — Let Terraform create new VPC (dev / sandbox / fresh account)
# Uncomment below and remove MODE A vars above.
# create_networking      = true
# vpc_cidr               = "10.100.0.0/16"
# availability_zones     = []          # empty → auto-pick first 2 AZs
# create_vpc_endpoints   = true        # gateway + interface endpoints for AWS APIs
# spoke_vpc_cidrs        = ["10.0.0.0/8"]   # restrict Lambda SG egress
# attach_to_existing_tgw = true
# existing_tgw_id        = "tgw-0abc123456789"

# ── Multi-account ────────────────────────────────────────────────────────────
# Every account that holds EKS clusters to manage.
# Key = 12-digit account ID  |  Value = label shown in the UI
spoke_accounts = {
  "111122223333" = "Production"
  "444455556666" = "Staging"
  "777788889999" = "Dev"
  "000011112222" = "Sandbox"
}

bootstrap_role_name = "OrganizationAccountAccessRole"
deploy_spoke_roles  = true
spoke_role_name     = "eks-agent-spoke-role"

# ── Multi-region ─────────────────────────────────────────────────────────────
# All clusters in all listed regions are accessible via a single Lambda deployment.
eks_regions = "us-east-1,us-east-2,us-west-2,eu-west-1,eu-central-1,ap-southeast-1"

# ── API / frontend ───────────────────────────────────────────────────────────
cors_origin = "*"   # tighten to CloudFront URL after first apply (Step 5)

# ── Optional tags ────────────────────────────────────────────────────────────
tags = {
  Team       = "platform"
  CostCenter = "infra"
}
```

---

## 6. Step 2 — Verify Bootstrap Access to Member Accounts

Terraform calls `deploy_spoke_roles.py` which assumes `OrganizationAccountAccessRole`
in each member account. Verify access before running `terraform apply`:

```bash
# Repeat for each account in spoke_accounts
aws sts assume-role \
  --role-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/OrganizationAccountAccessRole \
  --role-session-name preflight-test \
  --query "AssumedRoleUser.Arn" --output text
```

**Expected output:**
```
arn:aws:sts::<MEMBER_ACCOUNT_ID>:assumed-role/OrganizationAccountAccessRole/preflight-test
```

> **If this fails:**
> - The deployer must be authenticated in the **management/master account** of AWS Organizations.
> - Member accounts must have been provisioned via AWS Organizations. Independently-created
>   accounts do not get `OrganizationAccountAccessRole` automatically.
> - Fix: In each member account, manually create `OrganizationAccountAccessRole` with trust
>   policy `arn:aws:iam::<CENTRAL_ACCOUNT_ID>:root` and `AdministratorAccess` attached.

---

## 7. Step 3 — terraform apply (Full Stack)

```bash
cd infrastructure/terraform

terraform init

# Review the plan — no changes are made yet
terraform plan

# Deploy everything in one shot
terraform apply
```

**What `terraform apply` deploys — in dependency order:**

| Order | Resource | How Terraform Automates It |
|-------|----------|---------------------------|
| 1 | **Lambda layer** | `null_resource` runs `build_layer.py` → pip install arm64 manylinux packages + copies `shared/` modules |
| 2 | **Spoke IAM roles** (all member accounts) | `null_resource` runs `deploy_spoke_roles.py` → CloudFormation stack per account |
| 3 | **Networking** (if `create_networking = true`) | VPC, private subnets, NAT GW, IGW, VPC endpoints, TGW attachment |
| 4 | **DynamoDB table** | `aws_dynamodb_table` — PAY_PER_REQUEST, PITR, TTL, SSE enabled |
| 5 | **IAM roles & policies** | `aws_iam_role` + inline `aws_iam_role_policy` — least-privilege |
| 6 | **Lambda functions** (7) | `archive_file` zips each handler directory; `aws_lambda_function` deploys |
| 7 | **API Gateway** | `aws_apigatewayv2_api` + routes + Lambda integrations + throttling |
| 8 | **S3 bucket** | Private, versioned, SSE-S3, OAC policy, public-access block |
| 9 | **CloudFront distribution** | OAC → S3 (frontend) + custom origin → API Gateway (`/api/*` forwarded) |

**Automatic re-deploy triggers:**

| Change | What re-deploys |
|--------|----------------|
| Any `backend/functions/**/handler.py` | Only the changed Lambda function |
| `backend/requirements.txt` or `backend/shared/*.py` | Lambda layer + all functions |
| `spoke_accounts` or `spoke-role.yaml` | CloudFormation spoke stacks in affected accounts |

**Save the Terraform outputs — used in later steps:**

```bash
terraform output cloudfront_url              # https://dXXXXXXXXXXX.cloudfront.net
terraform output cloudfront_distribution_id  # EXXXXXXXXXX
terraform output s3_bucket_name              # eks-kubectl-agent-prod-frontend-111122223333
terraform output api_gateway_stage_url       # https://abc123.execute-api.us-east-1.amazonaws.com/prod
terraform output spoke_role_arns             # ARNs per account
terraform output registered_accounts         # account_id → label map
```

---

## 8. Step 4 — EKS Cluster Access (Exception)

> **Why this is an exception to Terraform automation:**
> Granting the spoke role access to each EKS cluster requires running commands
> **in the context of each spoke account** (EKS Access Entries or `aws-auth` ConfigMap
> edits). Terraform would require a separate `provider "aws"` block per account per
> region, which is not practical for a dynamic, N-account × M-region setup.
>
> This step must be done **once per cluster**. An automated bulk script is provided below.

### Option A — EKS Access Entries (recommended, EKS 1.29+)

Switch to the spoke account first, then for each cluster:

```bash
SPOKE_ACCOUNT_ID="111122223333"
CLUSTER_NAME="my-prod-cluster"
REGION="us-east-1"
SPOKE_ROLE="eks-agent-spoke-role"

# Authenticate into spoke account
eval $(aws sts assume-role \
  --role-arn arn:aws:iam::${SPOKE_ACCOUNT_ID}:role/OrganizationAccountAccessRole \
  --role-session-name eks-access-setup \
  --query "Credentials.[AccessKeyId,SecretAccessKey,SessionToken]" \
  --output text | awk '{print "export AWS_ACCESS_KEY_ID="$1" AWS_SECRET_ACCESS_KEY="$2" AWS_SESSION_TOKEN="$3}')

aws eks create-access-entry \
  --cluster-name $CLUSTER_NAME \
  --principal-arn arn:aws:iam::${SPOKE_ACCOUNT_ID}:role/${SPOKE_ROLE} \
  --type STANDARD \
  --region $REGION

aws eks associate-access-policy \
  --cluster-name $CLUSTER_NAME \
  --principal-arn arn:aws:iam::${SPOKE_ACCOUNT_ID}:role/${SPOKE_ROLE} \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy \
  --access-scope type=cluster \
  --region $REGION

unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
```

### Option B — aws-auth ConfigMap (EKS < 1.29)

```bash
aws eks update-kubeconfig --name $CLUSTER_NAME --region $REGION
kubectl edit configmap aws-auth -n kube-system
```

Add under `mapRoles`:

```yaml
- rolearn: arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role
  username: eks-agent
  groups:
    - eks-agent-readonly
```

Apply a ClusterRoleBinding:

```bash
kubectl apply -f - <<EOF
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: eks-agent-readonly
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: view
subjects:
  - kind: Group
    name: eks-agent-readonly
    apiGroup: rbac.authorization.k8s.io
EOF
```

### Bulk Automation Script (all accounts × all regions)

```bash
#!/usr/bin/env bash
# Run from the management account.
# Requires: jq, aws CLI v2

SPOKE_ACCOUNTS=("111122223333" "444455556666" "777788889999" "000011112222")
REGIONS=("us-east-1" "us-east-2" "us-west-2" "eu-west-1" "eu-central-1" "ap-southeast-1")
SPOKE_ROLE="eks-agent-spoke-role"
BOOTSTRAP_ROLE="OrganizationAccountAccessRole"

for ACCOUNT in "${SPOKE_ACCOUNTS[@]}"; do
  echo "=== Account: $ACCOUNT ==="
  CREDS=$(aws sts assume-role \
    --role-arn arn:aws:iam::${ACCOUNT}:role/${BOOTSTRAP_ROLE} \
    --role-session-name eks-access-bulk \
    --query "Credentials" --output json)

  export AWS_ACCESS_KEY_ID=$(echo $CREDS | jq -r .AccessKeyId)
  export AWS_SECRET_ACCESS_KEY=$(echo $CREDS | jq -r .SecretAccessKey)
  export AWS_SESSION_TOKEN=$(echo $CREDS | jq -r .SessionToken)

  for REGION in "${REGIONS[@]}"; do
    CLUSTERS=$(aws eks list-clusters --region $REGION \
      --query "clusters[]" --output text 2>/dev/null || true)
    for CLUSTER in $CLUSTERS; do
      echo "  + $ACCOUNT / $REGION / $CLUSTER"
      aws eks create-access-entry \
        --cluster-name $CLUSTER \
        --principal-arn arn:aws:iam::${ACCOUNT}:role/${SPOKE_ROLE} \
        --type STANDARD --region $REGION 2>/dev/null || true
      aws eks associate-access-policy \
        --cluster-name $CLUSTER \
        --principal-arn arn:aws:iam::${ACCOUNT}:role/${SPOKE_ROLE} \
        --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy \
        --access-scope type=cluster --region $REGION 2>/dev/null || true
    done
  done

  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
done
echo "Done."
```

---

## 9. Step 5 — Deploy Frontend via Terraform

The frontend build and S3 upload are automated by the same `null_resource` + `local-exec`
pattern used for the Lambda layer — no manual steps needed.

After `terraform apply` in Step 3, the CloudFront URL is known. Re-apply once to:
1. Bake the correct `NEXT_PUBLIC_API_URL` into the frontend bundle
2. Lock CORS to the specific CloudFront domain

```bash
cd infrastructure/terraform

CF_URL=$(terraform output -raw cloudfront_url)

terraform apply -var="cors_origin=${CF_URL}"
```

This triggers the frontend `null_resource` to:
1. Run `npm install && npm run build` with `NEXT_PUBLIC_API_URL=${CF_URL}/api/v1`
2. Run two-pass `aws s3 sync` (hashed assets: 1-year cache; HTML/manifests: no-cache)
3. Run `aws cloudfront create-invalidation --paths "/*"`

**Manual fallback** (if the Terraform frontend null_resource is not yet wired):

```bash
cd eks-kubectl-agent/frontend
npm install

# Linux / macOS
CF_URL=$(cd ../infrastructure/terraform && terraform output -raw cloudfront_url)
NEXT_PUBLIC_API_URL=${CF_URL}/api/v1 npm run build

# Windows PowerShell
$CF_URL = (terraform -chdir=..\infrastructure\terraform output -raw cloudfront_url)
$env:NEXT_PUBLIC_API_URL="$CF_URL/api/v1"; npm run build

# Upload — pass 1: hashed static assets (immutable 1-year cache)
BUCKET=$(cd ../infrastructure/terraform && terraform output -raw s3_bucket_name)
aws s3 sync out/_next/static/ s3://$BUCKET/_next/static/ \
  --cache-control "max-age=31536000,public,immutable" --delete

# Upload — pass 2: HTML + manifests (no-cache, instant re-deploy)
aws s3 sync out/ s3://$BUCKET/ \
  --cache-control "max-age=0,no-cache,no-store,must-revalidate" \
  --exclude "_next/static/*" --delete

# Invalidate CloudFront
CF_ID=$(cd ../infrastructure/terraform && terraform output -raw cloudfront_distribution_id)
aws cloudfront create-invalidation --distribution-id $CF_ID --paths "/*"
```

```powershell
# Windows PowerShell equivalents
$BUCKET = (terraform -chdir=..\infrastructure\terraform output -raw s3_bucket_name)
$CF_ID  = (terraform -chdir=..\infrastructure\terraform output -raw cloudfront_distribution_id)

aws s3 sync out\_next\static\ "s3://$BUCKET/_next/static/" `
  --cache-control "max-age=31536000,public,immutable" --delete
aws s3 sync out\ "s3://$BUCKET/" `
  --cache-control "max-age=0,no-cache,no-store,must-revalidate" `
  --exclude "_next/static/*" --delete
aws cloudfront create-invalidation --distribution-id $CF_ID --paths "/*"
```

---

## 10. Step 6 — Verify End-to-End

```bash
CF_URL=$(cd infrastructure/terraform && terraform output -raw cloudfront_url)
API="${CF_URL}/api/v1"
```

Open `$CF_URL` in a browser and verify:

| Check | Expected |
|-------|---------|
| Dashboard loads | Page renders; zero diagnoses (expected on first deploy) |
| New Diagnosis → Account dropdown | Lists all accounts from `spoke_accounts` |
| Select account + region → Cluster dropdown | Populates with clusters from that account/region |
| Run a diagnosis | Status: `pending → running → complete` |
| Results page | Findings with severity badges and fix recommendations |

**API smoke tests:**

```bash
# List registered accounts
curl -sf "$API/accounts" | python -m json.tool

# List clusters — multi-account, multi-region
curl -sf "$API/clusters?account_id=111122223333&region=us-east-1" | python -m json.tool
curl -sf "$API/clusters?account_id=444455556666&region=eu-west-1" | python -m json.tool

# Start a diagnosis
curl -sf -X POST "$API/diagnose/start" \
  -H "Content-Type: application/json" \
  -d '{"account_id":"111122223333","region":"us-east-1","cluster_name":"my-cluster"}' \
  | python -m json.tool

# Poll status (replace JOB_ID with value from above)
curl -sf "$API/diagnose/status/<JOB_ID>" | python -m json.tool
```

---

## 11. Step 7 — CLI Agent (Optional, Local)

The Python CLI connects **directly** to a cluster's private API endpoint from your
workstation. It does not go through the Lambda/API Gateway stack. Requires VPN,
AWS Client VPN, Direct Connect, or a bastion host in the spoke VPC.

### 11.1 Install

```bash
cd eks-kubectl-agent
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 11.2 Authenticate

```bash
# Update kubeconfig using the spoke role for the target account
aws eks update-kubeconfig \
  --name <CLUSTER_NAME> \
  --region <REGION> \
  --role-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role

# Verify
kubectl config current-context
kubectl get nodes
```

### 11.3 Configure (`config.yaml`)

```yaml
default_region:    "us-east-1"
default_namespace: "all"
log_tail_lines:    300
dry_run:           false
log_level:         "INFO"
```

### 11.4 Run

```bash
# Full diagnosis on current kubeconfig context
python main.py diagnose

# Explicit cluster + region
python main.py diagnose --cluster my-prod-cluster --region us-east-1

# Scope to one namespace
python main.py diagnose --namespace kube-system

# List fix recommendations from the last diagnosis
python main.py fix --list

# Apply a fix — always prompts for explicit confirmation before executing
python main.py fix FIX-001

# Generate a Markdown incident report
python main.py report
# Output: eks-incident-report.md
```

---

## 12. Terraform Automation Summary

| Task | Automated? | Terraform Mechanism | Exception / Notes |
|------|-----------|--------------------|--------------------|
| Lambda layer (pip install, arm64) | ✅ Yes | `null_resource` + `build_layer.py` | Re-runs on `requirements.txt` or `shared/*.py` change |
| Lambda function packaging | ✅ Yes | `archive_file` data sources | Re-zips on any handler file change |
| Lambda deployment (all 7 functions) | ✅ Yes | `aws_lambda_function` | Source hash triggers update |
| API Gateway (routes + integrations) | ✅ Yes | `aws_apigatewayv2_*` resources | All routes and Lambda integrations |
| DynamoDB table | ✅ Yes | `aws_dynamodb_table` | PITR, TTL, SSE enabled |
| IAM roles and policies | ✅ Yes | `aws_iam_role` + `aws_iam_role_policy` | Least-privilege inline policy |
| S3 bucket (hosting) | ✅ Yes | `aws_s3_bucket` + OAC policy | Private, versioned, encrypted |
| CloudFront distribution | ✅ Yes | `aws_cloudfront_distribution` | OAC→S3 + API GW proxy on `/api/*` |
| Spoke IAM roles (all member accounts) | ✅ Yes | `null_resource` + `deploy_spoke_roles.py` | CloudFormation per spoke account |
| Networking (VPC, NAT, endpoints, TGW) | ✅ Yes (optional) | `networking.tf` resources | Only when `create_networking = true` |
| Frontend build (npm) | ✅ Yes (via null_resource) | `null_resource` + `local-exec` | Requires Node.js 18+ on Terraform host |
| Frontend S3 upload + CF invalidation | ✅ Yes (via null_resource) | `null_resource` + `local-exec` | Requires AWS CLI on Terraform host |
| **EKS cluster access entries** | ⚠️ Exception | Bulk script in Step 4 | Requires spoke-account context; dynamic N-account provider not practical |
| **CLI agent kubeconfig** | ⚠️ Exception | `aws eks update-kubeconfig` (Step 7) | Runs on engineer's local machine |
| **TGW routes in spoke VPCs** | ⚠️ Exception | Managed by Network team / separate TF root | Spoke VPCs are out of scope for this module |

---

## 13. Day-2 Operations

### Add a new member account

```hcl
# terraform.tfvars — add to spoke_accounts
spoke_accounts = {
  "111122223333" = "Production"
  ...
  "999988887777" = "New-Account"   # ← add here
}
```

```bash
terraform apply   # spoke role created in new account automatically
# Then: grant EKS cluster access in the new account (Step 4)
```

### Add a new region

```hcl
eks_regions = "us-east-1,...,ap-northeast-1"   # ← append new region
```

```bash
terraform apply   # Lambda env var updated; no function redeploy
```

### Update Lambda code

```bash
# Edit backend/functions/<function>/handler.py or backend/shared/*.py
cd infrastructure/terraform && terraform apply
# archive_file + source_code_hash triggers update of only changed functions
```

### Update the frontend

```bash
# Edit frontend/src/**
cd infrastructure/terraform
terraform apply   # null_resource detects frontend src change, rebuilds and re-uploads
# OR force it:
terraform apply -replace="null_resource.build_frontend"
```

### Update spoke role permissions

```bash
# Edit infrastructure/member-account/spoke-role.yaml
cd infrastructure/terraform && terraform apply
# null_resource.deploy_spoke_roles triggers on template_hash change → updates CloudFormation in ALL accounts
```

### Remove a member account

```hcl
# Remove account from spoke_accounts in terraform.tfvars
```

```bash
terraform apply   # CloudFormation stack deleted from that account
# Manually remove EKS access entries in that account if needed
```

### Tear down everything

```bash
cd infrastructure/terraform
terraform destroy
```

> **Warning:** Destroys the DynamoDB table (all job history), S3 bucket contents,
> CloudFront distribution, Lambda functions, and spoke IAM roles in all member accounts.
> EKS access entries / aws-auth bindings must be removed manually.

---

## 14. Variable Reference

### Terraform (`infrastructure/terraform/terraform.tfvars`)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `aws_region` | no | `us-east-1` | Central account AWS region |
| `environment` | no | `prod` | `dev` / `staging` / `prod` — resource name suffix |
| `project` | no | `eks-kubectl-agent` | Resource name prefix |
| `spoke_accounts` | no | `{}` | **Multi-account:** account ID → display label |
| `deploy_spoke_roles` | no | `true` | Auto-deploy spoke CloudFormation stacks |
| `bootstrap_role_name` | no | `OrganizationAccountAccessRole` | Role assumed in each member account |
| `spoke_role_name` | no | `eks-agent-spoke-role` | IAM role name created in each member account |
| `eks_regions` | no | 10 regions | **Multi-region:** comma-separated regions scanned per account |
| `create_networking` | no | `false` | `true` → Terraform creates VPC, subnets, NAT GW |
| `vpc_subnet_ids` | yes* | — | Private subnet IDs for Lambda ENIs (*when `create_networking = false`) |
| `vpc_security_group_ids` | yes* | — | SG IDs for Lambda ENIs (*when `create_networking = false`) |
| `vpc_cidr` | no | `10.100.0.0/16` | VPC CIDR (only when `create_networking = true`) |
| `availability_zones` | no | `[]` | AZs for private subnets; empty = auto-pick first 2 |
| `create_vpc_endpoints` | no | `true` | VPC gateway + interface endpoints for AWS APIs |
| `spoke_vpc_cidrs` | no | `[]` | Lambda SG egress CIDRs; empty = `0.0.0.0/0` |
| `attach_to_existing_tgw` | no | `false` | Attach central VPC to an existing TGW |
| `existing_tgw_id` | conditional | `""` | Required when `attach_to_existing_tgw = true` |
| `existing_vpc_id` | conditional | `""` | Required when `attach_to_existing_tgw = true` and `create_networking = false` |
| `cors_origin` | no | `*` | CORS allowed origin — set to CloudFront URL after first deploy |
| `dynamodb_table_name` | no | `eks-agent-jobs` | DynamoDB table name |
| `job_ttl_hours` | no | `24` | Hours before job records expire (TTL) |
| `api_throttle_rate` | no | `20` | API Gateway requests/second |
| `api_throttle_burst` | no | `50` | API Gateway burst limit |
| `cloudfront_price_class` | no | `PriceClass_100` | `100`=US/EU, `200`=+Asia, `All`=worldwide |
| `frontend_build_path` | no | `../frontend/out` | Path to Next.js static export output directory |
| `tags` | no | `{}` | Additional tags applied to all resources |

### Frontend environment

| Variable | Required | Description |
|----------|----------|-------------|
| `NEXT_PUBLIC_API_URL` | **yes** | Full API base URL — `https://<CF_URL>/api/v1` |

### CLI agent (`config.yaml`)

| Key | Default | Description |
|-----|---------|-------------|
| `default_region` | `us-east-1` | AWS region (overridden by `--region` flag) |
| `default_namespace` | `all` | Kubernetes namespace scope |
| `command_timeout` | `60` | Per-command timeout (seconds) |
| `log_tail_lines` | `300` | Max lines to tail from pod logs |
| `dry_run` | `false` | Print commands without executing |
| `log_level` | `WARNING` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |

---

## 15. Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| `AccessDenied` in spoke role deployment | Deployer cannot assume `OrganizationAccountAccessRole` | Confirm deployer is in management account; confirm member account was provisioned via Organizations |
| Spoke CloudFormation `AccessDenied` | `OrganizationAccountAccessRole` lacks CloudFormation/IAM permissions | Attach `AdministratorAccess` to that role in the member account |
| Account dropdown empty in UI | `spoke_accounts` empty or Lambda env var not set | Add accounts to `terraform.tfvars` and re-apply |
| Cluster dropdown empty | Lambda cannot assume spoke role or spoke role not created | Check CloudWatch logs for `list_clusters` Lambda; verify spoke role ARN exists in member account |
| Lambda `dial tcp: i/o timeout` | No network path from Lambda VPC to spoke EKS private endpoint | Add TGW attachment + route `<spoke_cidr> → TGW` in central VPC route table; verify spoke VPC has return route |
| Lambda `AccessDenied` on `sts:AssumeRole` | Lambda execution role missing `sts:AssumeRole` on spoke role | Re-run `terraform apply`; confirm `spoke_role_name` matches what CloudFormation created |
| Lambda `not authorized` (Kubernetes) | Spoke role not in `aws-auth` or EKS Access Entry | Complete Step 4 for that cluster |
| Lambda `ModuleNotFoundError: shared` | Lambda layer not built or not attached | Run `terraform apply`; inspect `null_resource.build_layer` output |
| Layer `exec format error` | Layer built for wrong CPU architecture | Ensure `pip >= 22`; `build_layer.py` must use `--platform manylinux2014_aarch64` |
| Diagnosis stuck in `pending` | `diagnose_worker` Lambda not invoked | Check `diagnose_start` CloudWatch logs; verify `lambda:InvokeFunction` IAM permission |
| Frontend blank page / 404 | Wrong `NEXT_PUBLIC_API_URL` baked into bundle | Rebuild with the correct CloudFront URL; re-upload and invalidate CF |
| API returns `403 CORS` | `cors_origin` mismatch with request `Origin` header | `terraform apply -var="cors_origin=https://<exact-cf-url>"` |
| CLI agent `Cannot connect to API server` | No network path to private EKS endpoint from workstation | Run from a bastion / VPN host inside or peered with the spoke VPC |
| CLI agent `kubectl: command not found` | kubectl not on PATH | Install kubectl 1.29+ |
| TGW attachment created but clusters still unreachable | Spoke VPC route table missing return route | Add `<central_vpc_cidr> → TGW` in spoke VPC route tables |
| `terraform plan` — duplicate output error | Stale duplicate output blocks in `outputs.tf` | Remove duplicate `output` blocks from `infrastructure/terraform/outputs.tf` |
