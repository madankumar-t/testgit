#!/usr/bin/env python3
"""
Deploy the EKS Agent spoke role CloudFormation stack to every member account.

Called automatically by Terraform via a null_resource; reads a JSON config file
written by Terraform's local_file resource so no shell quoting is needed.

Config file schema (JSON):
{
  "central_account_id": "111122223333",
  "spoke_role_name":    "eks-agent-spoke-role",
  "bootstrap_role_name":"OrganizationAccountAccessRole",
  "region":             "us-east-1",
  "stack_name":         "eks-kubectl-agent-prod-spoke-role",
  "template_path":      "/absolute/path/to/spoke-role.yaml",
  "accounts":           { "123456789012": "Production", "234567890123": "Staging" }
}

Assumptions:
  • The caller's current IAM identity can assume
      arn:aws:iam::{member_account_id}:role/{bootstrap_role_name}
    in every member account (default role: OrganizationAccountAccessRole, which
    AWS creates automatically in accounts provisioned via Organizations).
  • boto3 is available (pip install boto3).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _assume_role(account_id: str, role_name: str) -> boto3.Session:
    sts = boto3.client("sts")
    resp = sts.assume_role(
        RoleArn=f"arn:aws:iam::{account_id}:role/{role_name}",
        RoleSessionName=f"eks-agent-setup-{account_id}",
        DurationSeconds=900,
    )
    creds = resp["Credentials"]
    return boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
    )


def _deploy_stack(
    session: boto3.Session,
    region: str,
    stack_name: str,
    template_body: str,
    central_account_id: str,
    spoke_role_name: str,
) -> None:
    cf = session.client("cloudformation", region_name=region)
    params = [
        {"ParameterKey": "CentralAccountId", "ParameterValue": central_account_id},
        {"ParameterKey": "RoleName",          "ParameterValue": spoke_role_name},
        {"ParameterKey": "ExternalId",        "ParameterValue": ""},
    ]

    # Determine whether the stack already exists
    stack_exists = False
    try:
        stacks = cf.describe_stacks(StackName=stack_name)["Stacks"]
        stack_exists = bool(stacks)
        current_status = stacks[0].get("StackStatus", "")
        # If the stack is in a ROLLBACK_COMPLETE state we must delete it first
        if current_status == "ROLLBACK_COMPLETE":
            print(f"    Stack is in ROLLBACK_COMPLETE — deleting and recreating...")
            cf.delete_stack(StackName=stack_name)
            cf.get_waiter("stack_delete_complete").wait(
                StackName=stack_name,
                WaiterConfig={"Delay": 10, "MaxAttempts": 60},
            )
            stack_exists = False
    except ClientError as exc:
        if "does not exist" not in str(exc):
            raise

    if stack_exists:
        try:
            cf.update_stack(
                StackName=stack_name,
                TemplateBody=template_body,
                Parameters=params,
                Capabilities=["CAPABILITY_NAMED_IAM"],
            )
            print(f"    Updating stack — waiting for completion...")
            cf.get_waiter("stack_update_complete").wait(
                StackName=stack_name,
                WaiterConfig={"Delay": 10, "MaxAttempts": 90},
            )
        except ClientError as exc:
            if "No updates are to be performed" in str(exc):
                print(f"    Stack already up to date — no changes.")
                return
            raise
    else:
        cf.create_stack(
            StackName=stack_name,
            TemplateBody=template_body,
            Parameters=params,
            Capabilities=["CAPABILITY_NAMED_IAM"],
            OnFailure="ROLLBACK",
        )
        print(f"    Creating stack — waiting for completion...")
        cf.get_waiter("stack_create_complete").wait(
            StackName=stack_name,
            WaiterConfig={"Delay": 10, "MaxAttempts": 90},
        )

    # Print the created role ARN
    try:
        outputs = cf.describe_stacks(StackName=stack_name)["Stacks"][0].get("Outputs", [])
        for o in outputs:
            if o["OutputKey"] == "SpokeRoleArn":
                print(f"    Role ARN: {o['OutputValue']}")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Deploy EKS agent spoke roles to member accounts")
    parser.add_argument("--config", required=True, help="Path to JSON config file written by Terraform")
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"ERROR: Config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)

    config: dict = json.loads(config_path.read_text())

    central_account_id = config["central_account_id"]
    spoke_role_name    = config["spoke_role_name"]
    bootstrap_role     = config["bootstrap_role_name"]
    region             = config["region"]
    stack_name         = config["stack_name"]
    template_path      = Path(config["template_path"])
    accounts: dict[str, str] = config["accounts"]

    if not accounts:
        print("No spoke accounts configured — nothing to deploy.")
        return

    template_body = template_path.read_text()

    print(f"\nDeploying spoke role '{spoke_role_name}' to {len(accounts)} account(s)")
    print(f"  Central account  : {central_account_id}")
    print(f"  Bootstrap role   : {bootstrap_role}")
    print(f"  Region           : {region}")
    print(f"  Stack name       : {stack_name}")

    errors: list[tuple[str, str]] = []

    for account_id, label in sorted(accounts.items()):
        print(f"\n  [{account_id}] {label}")
        try:
            session = _assume_role(account_id, bootstrap_role)
            _deploy_stack(
                session=session,
                region=region,
                stack_name=stack_name,
                template_body=template_body,
                central_account_id=central_account_id,
                spoke_role_name=spoke_role_name,
            )
            print(f"    OK")
        except Exception as exc:  # noqa: BLE001
            print(f"    FAILED: {exc}")
            errors.append((account_id, str(exc)))

    print()
    if errors:
        print(f"FAILED ({len(errors)} / {len(accounts)} accounts):")
        for acc_id, err in errors:
            print(f"  {acc_id}: {err}")
        sys.exit(1)
    else:
        print(f"All {len(accounts)} spoke role(s) deployed successfully.")


if __name__ == "__main__":
    main()
