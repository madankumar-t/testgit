"""
Shared data models for the EKS Agent backend.
Serializable to/from DynamoDB JSON.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional


class Severity(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    INFO = "Info"


class FixRisk(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    FAILED = "failed"


@dataclass
class ClusterContext:
    cluster_name: str
    region: str
    aws_account: str = "unknown"
    aws_user: str = "unknown"
    kubernetes_version: str = "unknown"
    node_count: int = 0
    namespaces: list[str] = field(default_factory=list)
    kubectl_context: str = "unknown"
    api_server: str = "unknown"


@dataclass
class ExecutedCommand:
    step: int
    command: str
    purpose: str
    result_summary: str
    success: bool


@dataclass
class Finding:
    component: str
    namespace: str
    resource: str
    severity: str          # Severity enum value
    evidence: str
    impact: str
    recommended_fix: str
    fix_command: Optional[str] = None
    rollback_command: Optional[str] = None
    fix_id: Optional[str] = None


@dataclass
class FixRecommendation:
    fix_id: str
    description: str
    command: list[str]
    risk: str              # FixRisk enum value
    expected_result: str
    rollback_command: Optional[list[str]]
    rollback_description: str
    requires_confirmation: bool = True
    namespace: Optional[str] = None
    resource: Optional[str] = None


@dataclass
class DiagnosisJob:
    job_id: str
    cluster_name: str
    region: str
    namespace: str
    status: str            # JobStatus enum value
    started_at: str
    account_id: str = ""   # target AWS account (spoke)
    role_arn: str = ""     # IAM role assumed to reach the target account
    completed_at: Optional[str] = None
    ttl: Optional[int] = None
    cluster_context: Optional[dict[str, Any]] = None
    executed_commands: list[dict[str, Any]] = field(default_factory=list)
    findings: list[dict[str, Any]] = field(default_factory=list)
    fixes: list[dict[str, Any]] = field(default_factory=list)
    root_cause: str = ""
    error_message: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DiagnosisJob":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
