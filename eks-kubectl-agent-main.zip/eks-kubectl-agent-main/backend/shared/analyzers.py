"""
Analyzers: process structured diagnostic data → Finding dicts.
Works on plain dicts (no subprocess/kubectl dependency).
"""
from __future__ import annotations

import re
from typing import Any

_FIX_COUNTER = 0


def _fix_id() -> str:
    global _FIX_COUNTER
    _FIX_COUNTER += 1
    return f"FIX-{_FIX_COUNTER:03d}"


def _finding(
    component: str,
    namespace: str,
    resource: str,
    severity: str,
    evidence: str,
    impact: str,
    recommended_fix: str,
    fix_command: str | None = None,
    rollback_command: str | None = None,
) -> dict[str, Any]:
    return {
        "component": component,
        "namespace": namespace,
        "resource": resource,
        "severity": severity,
        "evidence": evidence,
        "impact": impact,
        "recommended_fix": recommended_fix,
        "fix_command": fix_command,
        "rollback_command": rollback_command,
        "fix_id": _fix_id(),
    }


# ---------------------------------------------------------------------------
# Node analyzer
# ---------------------------------------------------------------------------

def analyze_nodes(nodes: list[dict]) -> list[dict]:
    findings = []
    for node in nodes:
        name = node["name"]
        conds = node.get("status", {})

        if conds.get("Ready") != "True":
            findings.append(_finding(
                "Nodes", "cluster", name, "Critical",
                f"Node {name}: Ready={conds.get('Ready', 'Unknown')}",
                "Node is NotReady — pods cannot be scheduled on this node.",
                f"Investigate node: kubectl describe node {name}",
                fix_command=f"kubectl cordon {name}",
                rollback_command=f"kubectl uncordon {name}",
            ))
        if conds.get("MemoryPressure") == "True":
            findings.append(_finding(
                "Nodes", "cluster", name, "High",
                f"Node {name}: MemoryPressure=True",
                "Node is under memory pressure. Pods may be evicted.",
                "Investigate high memory consumers: kubectl top pods -A --sort-by=memory",
            ))
        if conds.get("DiskPressure") == "True":
            findings.append(_finding(
                "Nodes", "cluster", name, "High",
                f"Node {name}: DiskPressure=True",
                "Node disk is nearly full. Container images and logs consuming disk.",
                "Free disk space or add capacity. Check for large images or logs.",
            ))
        if conds.get("NetworkUnavailable") == "True":
            findings.append(_finding(
                "Nodes", "cluster", name, "Critical",
                f"Node {name}: NetworkUnavailable=True",
                "Node network is unavailable. VPC CNI may have failed.",
                "Check aws-node DaemonSet and VPC CNI logs.",
            ))
    return findings


# ---------------------------------------------------------------------------
# Pod analyzer
# ---------------------------------------------------------------------------

_POD_ISSUE_MAP = {
    "CrashLoopBackOff": ("Critical", "Container is crash-looping repeatedly.",
                         "Check pod logs and previous logs. Verify env vars, ConfigMaps, probes."),
    "ImagePullBackOff": ("High", "Kubernetes cannot pull the container image.",
                         "Verify image name/tag, ECR permissions, and imagePullSecrets."),
    "ErrImagePull": ("High", "Image pull error.",
                     "Verify image name/tag, ECR permissions, and node internet/NAT access."),
    "CreateContainerConfigError": ("High", "Missing ConfigMap or Secret referenced by container.",
                                   "Ensure all referenced ConfigMaps and Secrets exist in the namespace."),
    "OOMKilled": ("High", "Container killed due to out-of-memory.",
                  "Increase memory limits. Review application memory profile."),
    "Evicted": ("Medium", "Pod was evicted due to node resource pressure.",
                "Check node memory/disk pressure. Review eviction thresholds."),
}


def analyze_pods(pods: list[dict]) -> list[dict]:
    findings = []
    for pod in pods:
        ns = pod["namespace"]
        name = pod["name"]
        phase = pod.get("phase", "Unknown")

        if phase == "Pending":
            findings.append(_finding(
                "Pods", ns, name, "Medium",
                f"Pod {ns}/{name} is Pending",
                "Pod cannot be scheduled. Check node capacity, taints, PVCs, resource requests.",
                f"kubectl describe pod {name} -n {ns}",
                fix_command=f"kubectl describe pod {name} -n {ns}",
            ))

        for cs in pod.get("containers", []):
            state = cs.get("state", "")
            detail = cs.get("state_detail", {})
            reason = detail.get("reason", "")
            restart_count = cs.get("restart_count", 0)

            for issue, (severity, impact, fix) in _POD_ISSUE_MAP.items():
                if issue in reason or (issue == "OOMKilled" and detail.get("reason") == "OOMKilled"):
                    findings.append(_finding(
                        "Pods", ns, name, severity,
                        f"Container {cs['name']}: state={state}, reason={reason}, restarts={restart_count}",
                        impact, fix,
                        fix_command=f"kubectl logs {name} -n {ns} -c {cs['name']} --previous --tail=200",
                    ))

            if restart_count > 5 and state != "running":
                findings.append(_finding(
                    "Pods", ns, name, "High",
                    f"Container {cs['name']} has {restart_count} restarts",
                    "High restart count indicates a recurring application crash or config issue.",
                    f"Check logs: kubectl logs {name} -n {ns} --previous",
                    fix_command=f"kubectl logs {name} -n {ns} --previous --tail=200",
                ))

    return findings


# ---------------------------------------------------------------------------
# Deployment analyzer
# ---------------------------------------------------------------------------

def analyze_deployments(deployments: list[dict]) -> list[dict]:
    findings = []
    for d in deployments:
        ns, name = d["namespace"], d["name"]
        desired = d.get("desired", 0)
        ready = d.get("ready", 0)
        if desired > 0 and ready < desired:
            findings.append(_finding(
                "Deployments", ns, name, "High",
                f"Deployment {ns}/{name}: {ready}/{desired} replicas ready",
                f"Deployment has {desired - ready} unavailable replicas. Traffic may be degraded.",
                f"Check pod status: kubectl get pods -n {ns} -l app={name}",
                fix_command=f"kubectl rollout restart deployment/{name} -n {ns}",
                rollback_command=f"kubectl rollout undo deployment/{name} -n {ns}",
            ))
    return findings


# ---------------------------------------------------------------------------
# DaemonSet analyzer
# ---------------------------------------------------------------------------

def analyze_daemonsets(daemonsets: list[dict]) -> list[dict]:
    findings = []
    for ds in daemonsets:
        ns, name = ds["namespace"], ds["name"]
        desired = ds.get("desired", 0)
        ready = ds.get("ready", 0)
        if desired > 0 and ready < desired:
            findings.append(_finding(
                "Deployments", ns, name, "Medium",
                f"DaemonSet {ns}/{name}: {ready}/{desired} pods ready",
                f"DaemonSet has {desired - ready} unavailable pods.",
                f"kubectl describe ds {name} -n {ns}",
            ))
    return findings


# ---------------------------------------------------------------------------
# Service / Endpoint analyzer
# ---------------------------------------------------------------------------

def analyze_endpoints(endpoints: list[dict]) -> list[dict]:
    findings = []
    skip = {"kubernetes"}
    for ep in endpoints:
        if ep["name"] in skip:
            continue
        if not ep.get("has_endpoints"):
            findings.append(_finding(
                "Services", ep["namespace"], ep["name"], "High",
                f"Service {ep['namespace']}/{ep['name']} has no ready endpoints.",
                "No pods are backing this service. Traffic will result in connection refused.",
                "Verify pod labels match service selector. Check pod readiness.",
                fix_command=f"kubectl describe svc {ep['name']} -n {ep['namespace']}",
            ))
    return findings


# ---------------------------------------------------------------------------
# ALB / Target Group analyzer
# ---------------------------------------------------------------------------

def analyze_target_groups(target_groups: list[dict]) -> list[dict]:
    findings = []
    for tg in target_groups:
        unhealthy = [
            t for t in tg.get("target_health", [])
            if t.get("state") not in ("healthy", "initial", "draining")
        ]
        if unhealthy:
            findings.append(_finding(
                "Ingress / ALB", "aws", tg["name"], "High",
                f"Target group {tg['name']}: {len(unhealthy)}/{tg['total_count']} targets unhealthy. "
                f"States: {[t['state'] for t in unhealthy]}",
                "ALB is routing to unhealthy targets. Requests will fail.",
                "Check health check path, security group rules, and pod readiness probes.",
            ))
    return findings


# ---------------------------------------------------------------------------
# Subnet IP exhaustion
# ---------------------------------------------------------------------------

def analyze_subnets(subnets: list[dict]) -> list[dict]:
    findings = []
    for s in subnets:
        available = s.get("available_ips", 999)
        if isinstance(available, int) and available < 10:
            findings.append(_finding(
                "Networking", "aws", s["subnet_id"], "Critical",
                f"Subnet {s['subnet_id']} ({s['az']}) has only {available} available IPs",
                "Subnet IP exhaustion. New pods cannot receive IP addresses.",
                "Enable VPC CNI prefix delegation or add new subnets to the nodegroup.",
            ))
        elif isinstance(available, int) and available < 30:
            findings.append(_finding(
                "Networking", "aws", s["subnet_id"], "High",
                f"Subnet {s['subnet_id']} ({s['az']}) has only {available} available IPs",
                "Subnet IPs running low. Risk of pod scheduling failures.",
                "Plan to expand subnet or enable prefix delegation.",
            ))
    return findings


# ---------------------------------------------------------------------------
# EKS add-on analyzer
# ---------------------------------------------------------------------------

def analyze_addons(addons: list[dict]) -> list[dict]:
    findings = []
    for addon in addons:
        if addon.get("status") not in ("ACTIVE", "CREATING"):
            findings.append(_finding(
                "Networking", "kube-system", addon["name"], "High",
                f"EKS add-on {addon['name']} status: {addon.get('status')}",
                f"Add-on {addon['name']} is not in ACTIVE state.",
                f"Check add-on health and update if needed.",
            ))
    return findings


# ---------------------------------------------------------------------------
# PVC analyzer
# ---------------------------------------------------------------------------

def analyze_pvcs(pvcs: list[dict]) -> list[dict]:
    findings = []
    for pvc in pvcs:
        if pvc.get("status") == "Pending":
            findings.append(_finding(
                "Storage", pvc["namespace"], pvc["name"], "High",
                f"PVC {pvc['namespace']}/{pvc['name']} is Pending",
                "PVC cannot be provisioned. Pods depending on this PVC cannot start.",
                f"kubectl describe pvc {pvc['name']} -n {pvc['namespace']}",
                fix_command=f"kubectl describe pvc {pvc['name']} -n {pvc['namespace']}",
            ))
        elif pvc.get("status") == "Lost":
            findings.append(_finding(
                "Storage", pvc["namespace"], pvc["name"], "Critical",
                f"PVC {pvc['namespace']}/{pvc['name']} is Lost",
                "PVC backing volume is lost. Data may be unrecoverable.",
                "Check underlying EBS volume. May require restore from snapshot.",
            ))
    return findings


# ---------------------------------------------------------------------------
# Event analyzer
# ---------------------------------------------------------------------------

_EVENT_SEVERITY_MAP = {
    "FailedScheduling": "High",
    "FailedMount": "High",
    "BackOff": "High",
    "FailedCreate": "High",
    "OOMKilling": "High",
    "Unhealthy": "Medium",
    "NodeNotReady": "Critical",
    "EvictionThresholdMet": "High",
}


def analyze_events(events: list[dict]) -> list[dict]:
    findings = []
    seen: set[str] = set()
    for event in events:
        reason = event.get("reason", "")
        severity = _EVENT_SEVERITY_MAP.get(reason, "Medium")
        key = f"{reason}-{event.get('object_name', '')}"
        if key in seen:
            continue
        seen.add(key)
        findings.append(_finding(
            "Logs and Events",
            event.get("namespace", "unknown"),
            event.get("object_name", "unknown"),
            severity,
            f"[{reason}] {event.get('message', '')[:300]} (count={event.get('count', 1)})",
            f"Kubernetes Warning event: {reason}",
            f"Investigate: kubectl describe {event.get('object_kind', 'pod')} "
            f"{event.get('object_name', '')} -n {event.get('namespace', '')}",
        ))
    return findings


# ---------------------------------------------------------------------------
# Nodegroup analyzer
# ---------------------------------------------------------------------------

def analyze_nodegroups(nodegroups: list[dict]) -> list[dict]:
    findings = []
    for ng in nodegroups:
        if ng.get("status") not in ("ACTIVE",):
            findings.append(_finding(
                "Autoscaling", "cluster", ng["name"], "High",
                f"Nodegroup {ng['name']} status: {ng.get('status')}",
                "Nodegroup is not in ACTIVE state. Nodes may not be joining the cluster.",
                "Check nodegroup in AWS Console or run: aws eks describe-nodegroup",
            ))
        sc = ng.get("scaling_config", {})
        desired = sc.get("desiredSize", 0)
        max_size = sc.get("maxSize", 0)
        if max_size > 0 and desired >= max_size:
            findings.append(_finding(
                "Autoscaling", "cluster", ng["name"], "Medium",
                f"Nodegroup {ng['name']}: desired={desired} == max={max_size}",
                "Nodegroup is at maximum capacity. Cluster Autoscaler cannot scale out further.",
                f"Increase nodegroup maxSize for: {ng['name']}",
            ))
    return findings


# ---------------------------------------------------------------------------
# Root cause derivation
# ---------------------------------------------------------------------------

_SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}


def derive_root_cause(findings: list[dict]) -> str:
    if not findings:
        return (
            "No issues detected in automated analysis. "
            "The cluster appears healthy based on collected data. "
            "For intermittent issues, review CloudWatch metrics and application logs."
        )
    sorted_findings = sorted(
        findings, key=lambda f: _SEVERITY_ORDER.get(f.get("severity", "Info"), 99)
    )
    top = sorted_findings[0]
    return (
        f"Most likely root cause: [{top['severity']}] "
        f"{top['component']} — {top['resource']} (ns: {top['namespace']}) — "
        f"{top['impact']}"
    )


# ---------------------------------------------------------------------------
# Generate fix recommendations from findings
# ---------------------------------------------------------------------------

def generate_fixes(findings: list[dict]) -> list[dict[str, Any]]:
    """Derive FixRecommendation dicts from findings that have a fix_command."""
    fixes = []
    seen: set[str] = set()
    for f in findings:
        fix_cmd = f.get("fix_command")
        if not fix_cmd:
            continue
        key = fix_cmd
        if key in seen:
            continue
        seen.add(key)
        rollback = f.get("rollback_command")
        severity = f.get("severity", "Low")
        risk = "High" if severity == "Critical" else ("Medium" if severity == "High" else "Low")
        fixes.append({
            "fix_id": f["fix_id"] + "-EXEC",
            "description": f["recommended_fix"],
            "command": fix_cmd.split(),
            "risk": risk,
            "expected_result": f"Issue resolved: {f['impact']}",
            "rollback_command": rollback.split() if rollback else None,
            "rollback_description": rollback or "No rollback available.",
            "requires_confirmation": True,
            "namespace": f.get("namespace"),
            "resource": f.get("resource"),
        })
    return fixes


# ---------------------------------------------------------------------------
# Main entry: run all analyzers
# ---------------------------------------------------------------------------

def run_all_analyzers(data: dict[str, Any]) -> tuple[list[dict], list[dict], str]:
    """
    Run all analyzers on collected diagnostic data.

    Returns:
        (findings, fixes, root_cause)
    """
    global _FIX_COUNTER
    _FIX_COUNTER = 0  # Reset counter per run

    all_findings: list[dict] = []

    all_findings.extend(analyze_nodes(data.get("nodes", [])))
    all_findings.extend(analyze_pods(data.get("pods", [])))
    all_findings.extend(analyze_deployments(data.get("deployments", [])))
    all_findings.extend(analyze_daemonsets(data.get("daemonsets", [])))
    all_findings.extend(analyze_endpoints(data.get("endpoints", [])))
    all_findings.extend(analyze_target_groups(data.get("target_groups", [])))
    all_findings.extend(analyze_subnets(data.get("subnets", [])))
    all_findings.extend(analyze_addons(data.get("addons", [])))
    all_findings.extend(analyze_pvcs(data.get("pvcs", [])))
    all_findings.extend(analyze_events(data.get("events", [])))
    all_findings.extend(analyze_nodegroups(data.get("nodegroups", [])))

    fixes = generate_fixes(all_findings)
    root_cause = derive_root_cause(all_findings)

    return all_findings, fixes, root_cause
