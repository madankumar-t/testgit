"""
Kubernetes Python client factory for EKS.

Generates a kubeconfig-equivalent client configuration dynamically
using boto3 — no kubectl binary or kubeconfig file required.

Supports cross-account access: pass role_arn to assume a spoke role
in a target account before connecting to the private cluster endpoint.
"""
from __future__ import annotations

import base64
import logging
import os
import tempfile
from typing import Any

import boto3
from botocore.signers import RequestSigner

logger = logging.getLogger(__name__)


def assume_role(role_arn: str, session_name: str = "eks-agent-session") -> boto3.Session:
    """
    Assume a cross-account IAM role and return a boto3 Session scoped to
    the temporary credentials.  Used to reach EKS clusters in spoke accounts.
    """
    sts = boto3.client("sts")
    creds = sts.assume_role(
        RoleArn=role_arn,
        RoleSessionName=session_name,
        DurationSeconds=3600,
    )["Credentials"]
    return boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
    )


def _get_eks_bearer_token(
    cluster_name: str,
    region: str,
    session: boto3.Session | None = None,
) -> str:
    """
    Generate a bearer token equivalent to `aws eks get-token`.

    Uses a pre-signed STS GetCallerIdentity URL with the x-k8s-aws-id header
    to produce a k8s-aws-v1.* token accepted by the EKS authentication webhook.

    When a cross-account session is supplied the token is signed with the
    assumed-role identity, which must be mapped in the target cluster's
    aws-auth ConfigMap (or EKS access entries).
    """
    TOKEN_EXPIRY_SECONDS = 60
    session = session or boto3.session.Session()
    sts_client = session.client("sts", region_name=region)
    service_id = sts_client.meta.service_model.service_id

    signer = RequestSigner(
        service_id,
        region,
        "sts",
        "v4",
        session.get_credentials(),
        session.events,
    )

    presigned_params = {
        "method": "GET",
        "url": f"https://sts.{region}.amazonaws.com/?Action=GetCallerIdentity&Version=2011-06-15",
        "body": {},
        "headers": {"x-k8s-aws-id": cluster_name},
        "context": {},
    }

    signed_url = signer.generate_presigned_url(
        presigned_params,
        region_name=region,
        expires_in=TOKEN_EXPIRY_SECONDS,
        operation_name="",
    )

    b64_url = base64.urlsafe_b64encode(signed_url.encode("utf-8")).decode("utf-8")
    return "k8s-aws-v1." + b64_url.rstrip("=")


def get_k8s_api_client(
    cluster_name: str,
    region: str,
    role_arn: str | None = None,
):
    """
    Build and return a kubernetes.client.ApiClient configured for the given EKS cluster.

    When role_arn is supplied the function first assumes that IAM role (cross-account)
    and uses the resulting session for both the EKS describe call and the bearer-token
    pre-signed URL.  The cluster endpoint must be reachable from the Lambda VPC
    (private endpoint with VPC peering / Transit Gateway as needed).

    Imports kubernetes lazily so the module can be imported even in environments
    where the kubernetes package is not installed (e.g., local CLI mode).
    """
    try:
        from kubernetes import client as k8s_client
    except ImportError as exc:
        raise ImportError(
            "The 'kubernetes' package is required for Lambda mode. "
            "Install it with: pip install kubernetes"
        ) from exc

    session = assume_role(role_arn) if role_arn else boto3.session.Session()

    eks = session.client("eks", region_name=region)
    cluster_info = eks.describe_cluster(name=cluster_name)["cluster"]

    endpoint: str = cluster_info["endpoint"]
    ca_data: str = cluster_info["certificateAuthority"]["data"]
    token: str = _get_eks_bearer_token(cluster_name, region, session=session)

    # Write CA cert to a temp file (kubernetes client needs a file path)
    ca_cert = base64.b64decode(ca_data)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".crt")
    tmp.write(ca_cert)
    tmp.flush()
    tmp.close()

    configuration = k8s_client.Configuration()
    configuration.host = endpoint
    configuration.verify_ssl = True
    configuration.ssl_ca_cert = tmp.name
    configuration.api_key = {"authorization": f"Bearer {token}"}

    return k8s_client.ApiClient(configuration)


def get_core_v1(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.CoreV1Api(get_k8s_api_client(cluster_name, region, role_arn))


def get_apps_v1(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.AppsV1Api(get_k8s_api_client(cluster_name, region, role_arn))


def get_networking_v1(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.NetworkingV1Api(get_k8s_api_client(cluster_name, region, role_arn))


def get_autoscaling_v2(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.AutoscalingV2Api(get_k8s_api_client(cluster_name, region, role_arn))


def get_batch_v1(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.BatchV1Api(get_k8s_api_client(cluster_name, region, role_arn))


def get_storage_v1(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.StorageV1Api(get_k8s_api_client(cluster_name, region, role_arn))


def get_policy_v1(cluster_name: str, region: str, role_arn: str | None = None):
    from kubernetes import client as k8s_client
    return k8s_client.PolicyV1Api(get_k8s_api_client(cluster_name, region, role_arn))
