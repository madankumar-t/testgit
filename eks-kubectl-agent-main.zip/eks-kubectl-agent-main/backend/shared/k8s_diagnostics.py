"""
Kubernetes-native diagnostic checks using the kubernetes Python client.
Returns structured data dicts ready for analysis.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def _safe(fn, default=None):
    """Execute fn(), return default on any exception."""
    try:
        return fn()
    except Exception as exc:
        logger.warning("k8s check failed: %s", exc)
        return default


# ---------------------------------------------------------------------------
# Cluster context
# ---------------------------------------------------------------------------

def get_cluster_context(core_v1, cluster_name: str) -> dict[str, Any]:
    ns_list = _safe(
        lambda: [ns.metadata.name for ns in core_v1.list_namespace().items], []
    )
    nodes = _safe(lambda: core_v1.list_node().items, [])
    return {
        "cluster_name": cluster_name,
        "node_count": len(nodes),
        "namespaces": ns_list,
    }


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------

def get_nodes(core_v1) -> list[dict[str, Any]]:
    nodes = _safe(lambda: core_v1.list_node().items, [])
    result = []
    for node in nodes:
        conditions = {}
        for cond in (node.status.conditions or []):
            conditions[cond.type] = cond.status
        allocatable = node.status.allocatable or {}
        result.append({
            "name": node.metadata.name,
            "status": conditions,
            "ready": conditions.get("Ready", "Unknown"),
            "labels": node.metadata.labels or {},
            "taints": [
                {"key": t.key, "effect": t.effect, "value": t.value}
                for t in (node.spec.taints or [])
            ],
            "allocatable_cpu": allocatable.get("cpu", "unknown"),
            "allocatable_memory": allocatable.get("memory", "unknown"),
            "kernel_version": (node.status.node_info.kernel_version if node.status.node_info else "unknown"),
            "os_image": (node.status.node_info.os_image if node.status.node_info else "unknown"),
            "container_runtime": (node.status.node_info.container_runtime_version if node.status.node_info else "unknown"),
            "kubelet_version": (node.status.node_info.kubelet_version if node.status.node_info else "unknown"),
        })
    return result


# ---------------------------------------------------------------------------
# Pods
# ---------------------------------------------------------------------------

def get_pods(core_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        pods = _safe(lambda: core_v1.list_namespaced_pod(namespace).items, [])
    else:
        pods = _safe(lambda: core_v1.list_pod_for_all_namespaces().items, [])

    result = []
    for pod in pods:
        containers = []
        for cs in (pod.status.container_statuses or []):
            state_name = "unknown"
            state_detail = {}
            if cs.state:
                if cs.state.running:
                    state_name = "running"
                elif cs.state.waiting:
                    state_name = "waiting"
                    state_detail = {
                        "reason": cs.state.waiting.reason,
                        "message": cs.state.waiting.message,
                    }
                elif cs.state.terminated:
                    state_name = "terminated"
                    state_detail = {
                        "reason": cs.state.terminated.reason,
                        "exit_code": cs.state.terminated.exit_code,
                    }
            containers.append({
                "name": cs.name,
                "ready": cs.ready,
                "restart_count": cs.restart_count,
                "state": state_name,
                "state_detail": state_detail,
                "image": cs.image,
            })

        result.append({
            "namespace": pod.metadata.namespace,
            "name": pod.metadata.name,
            "phase": pod.status.phase or "Unknown",
            "node_name": pod.spec.node_name,
            "pod_ip": pod.status.pod_ip,
            "containers": containers,
            "conditions": {
                c.type: c.status
                for c in (pod.status.conditions or [])
            },
        })
    return result


# ---------------------------------------------------------------------------
# Deployments
# ---------------------------------------------------------------------------

def get_deployments(apps_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        deploys = _safe(lambda: apps_v1.list_namespaced_deployment(namespace).items, [])
    else:
        deploys = _safe(lambda: apps_v1.list_deployment_for_all_namespaces().items, [])

    result = []
    for d in deploys:
        result.append({
            "namespace": d.metadata.namespace,
            "name": d.metadata.name,
            "desired": d.spec.replicas or 0,
            "ready": d.status.ready_replicas or 0,
            "available": d.status.available_replicas or 0,
            "updated": d.status.updated_replicas or 0,
            "conditions": [
                {"type": c.type, "status": c.status, "reason": c.reason, "message": c.message}
                for c in (d.status.conditions or [])
            ],
        })
    return result


# ---------------------------------------------------------------------------
# DaemonSets
# ---------------------------------------------------------------------------

def get_daemonsets(apps_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        dss = _safe(lambda: apps_v1.list_namespaced_daemon_set(namespace).items, [])
    else:
        dss = _safe(lambda: apps_v1.list_daemon_set_for_all_namespaces().items, [])

    return [
        {
            "namespace": ds.metadata.namespace,
            "name": ds.metadata.name,
            "desired": ds.status.desired_number_scheduled or 0,
            "ready": ds.status.number_ready or 0,
            "available": ds.status.number_available or 0,
            "unavailable": ds.status.number_unavailable or 0,
        }
        for ds in dss
    ]


# ---------------------------------------------------------------------------
# StatefulSets
# ---------------------------------------------------------------------------

def get_statefulsets(apps_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        stss = _safe(lambda: apps_v1.list_namespaced_stateful_set(namespace).items, [])
    else:
        stss = _safe(lambda: apps_v1.list_stateful_set_for_all_namespaces().items, [])

    return [
        {
            "namespace": sts.metadata.namespace,
            "name": sts.metadata.name,
            "desired": sts.spec.replicas or 0,
            "ready": sts.status.ready_replicas or 0,
            "current": sts.status.current_replicas or 0,
        }
        for sts in stss
    ]


# ---------------------------------------------------------------------------
# Services + Endpoints
# ---------------------------------------------------------------------------

def get_services(core_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        svcs = _safe(lambda: core_v1.list_namespaced_service(namespace).items, [])
    else:
        svcs = _safe(lambda: core_v1.list_service_for_all_namespaces().items, [])

    return [
        {
            "namespace": svc.metadata.namespace,
            "name": svc.metadata.name,
            "type": svc.spec.type,
            "cluster_ip": svc.spec.cluster_ip,
            "external_ip": (svc.status.load_balancer.ingress[0].hostname
                            if svc.status.load_balancer and svc.status.load_balancer.ingress
                            else None),
            "ports": [
                {"port": p.port, "target_port": str(p.target_port), "protocol": p.protocol}
                for p in (svc.spec.ports or [])
            ],
            "selector": svc.spec.selector or {},
        }
        for svc in svcs
    ]


def get_endpoints(core_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        eps = _safe(lambda: core_v1.list_namespaced_endpoints(namespace).items, [])
    else:
        eps = _safe(lambda: core_v1.list_endpoints_for_all_namespaces().items, [])

    result = []
    for ep in eps:
        addresses = []
        for subset in (ep.subsets or []):
            for addr in (subset.addresses or []):
                addresses.append(addr.ip)
        result.append({
            "namespace": ep.metadata.namespace,
            "name": ep.metadata.name,
            "ready_addresses": addresses,
            "has_endpoints": bool(addresses),
        })
    return result


# ---------------------------------------------------------------------------
# Ingress
# ---------------------------------------------------------------------------

def get_ingresses(networking_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        ings = _safe(lambda: networking_v1.list_namespaced_ingress(namespace).items, [])
    else:
        ings = _safe(lambda: networking_v1.list_ingress_for_all_namespaces().items, [])

    result = []
    for ing in ings:
        lb_hostnames = []
        if ing.status.load_balancer and ing.status.load_balancer.ingress:
            lb_hostnames = [
                i.hostname or i.ip or ""
                for i in ing.status.load_balancer.ingress
            ]
        result.append({
            "namespace": ing.metadata.namespace,
            "name": ing.metadata.name,
            "class": (ing.spec.ingress_class_name or
                      (ing.metadata.annotations or {}).get("kubernetes.io/ingress.class", "")),
            "annotations": ing.metadata.annotations or {},
            "lb_hostnames": lb_hostnames,
            "rules": [
                {
                    "host": r.host,
                    "paths": [
                        {"path": p.path, "backend_service": p.backend.service.name
                         if p.backend and p.backend.service else None}
                        for p in (r.http.paths if r.http else [])
                    ],
                }
                for r in (ing.spec.rules or [])
            ],
        })
    return result


# ---------------------------------------------------------------------------
# PVCs
# ---------------------------------------------------------------------------

def get_pvcs(core_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        pvcs = _safe(lambda: core_v1.list_namespaced_persistent_volume_claim(namespace).items, [])
    else:
        pvcs = _safe(lambda: core_v1.list_persistent_volume_claim_for_all_namespaces().items, [])

    return [
        {
            "namespace": pvc.metadata.namespace,
            "name": pvc.metadata.name,
            "status": pvc.status.phase or "Unknown",
            "storage_class": pvc.spec.storage_class_name,
            "capacity": (pvc.status.capacity or {}).get("storage", "unknown"),
            "access_modes": pvc.spec.access_modes or [],
            "volume_name": pvc.spec.volume_name,
        }
        for pvc in pvcs
    ]


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

def get_events(core_v1, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        events = _safe(lambda: core_v1.list_namespaced_event(namespace).items, [])
    else:
        events = _safe(lambda: core_v1.list_event_for_all_namespaces().items, [])

    warning_events = [
        e for e in events if e.type == "Warning"
    ]
    # Sort by last timestamp desc, take top 100
    warning_events.sort(
        key=lambda e: (e.last_timestamp or e.event_time or ""),
        reverse=True,
    )

    return [
        {
            "namespace": e.metadata.namespace,
            "name": e.metadata.name,
            "type": e.type,
            "reason": e.reason,
            "message": e.message,
            "object_kind": e.involved_object.kind if e.involved_object else None,
            "object_name": e.involved_object.name if e.involved_object else None,
            "count": e.count or 1,
            "first_time": str(e.first_timestamp) if e.first_timestamp else None,
            "last_time": str(e.last_timestamp) if e.last_timestamp else None,
        }
        for e in warning_events[:100]
    ]


# ---------------------------------------------------------------------------
# HPA
# ---------------------------------------------------------------------------

def get_hpas(autoscaling_v2, namespace: str = "") -> list[dict[str, Any]]:
    if namespace and namespace != "all":
        hpas = _safe(lambda: autoscaling_v2.list_namespaced_horizontal_pod_autoscaler(namespace).items, [])
    else:
        hpas = _safe(lambda: autoscaling_v2.list_horizontal_pod_autoscaler_for_all_namespaces().items, [])

    return [
        {
            "namespace": hpa.metadata.namespace,
            "name": hpa.metadata.name,
            "min_replicas": hpa.spec.min_replicas,
            "max_replicas": hpa.spec.max_replicas,
            "current_replicas": hpa.status.current_replicas or 0,
            "desired_replicas": hpa.status.desired_replicas or 0,
        }
        for hpa in hpas
    ]


# ---------------------------------------------------------------------------
# Pod Logs
# ---------------------------------------------------------------------------

def get_pod_logs(
    core_v1,
    namespace: str,
    pod_name: str,
    container: str | None = None,
    tail_lines: int = 200,
    previous: bool = False,
) -> str:
    kwargs: dict = {
        "tail_lines": tail_lines,
        "timestamps": True,
        "_preload_content": True,
    }
    if container:
        kwargs["container"] = container
    if previous:
        kwargs["previous"] = True

    try:
        return core_v1.read_namespaced_pod_log(
            name=pod_name, namespace=namespace, **kwargs
        )
    except Exception as exc:
        return f"Error fetching logs: {exc}"
