"""
POST /api/v1/diagnose

Validates request, creates a DynamoDB job record with status=pending,
asynchronously invokes the diagnose_worker Lambda, and returns the job_id.
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone

import boto3

from shared.models import JobStatus
from shared.storage import put_job

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

WORKER_FUNCTION = os.environ.get("WORKER_FUNCTION_NAME", "eks-agent-diagnose-worker")
# Name of the IAM role deployed in every spoke account.
# Callers may override with an explicit role_arn in the request body.
SPOKE_ROLE_NAME = os.environ.get("SPOKE_ROLE_NAME", "eks-agent-spoke-role")

_lambda_client = None


def _get_lambda():
    global _lambda_client
    if _lambda_client is None:
        _lambda_client = boto3.client("lambda", region_name=os.environ.get("AWS_REGION", "us-east-1"))
    return _lambda_client


def _cors_headers() -> dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Content-Type": "application/json",
    }


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body),
    }


def handler(event: dict, context) -> dict:
    # Handle CORS preflight
    if event.get("httpMethod") == "OPTIONS":
        return _response(200, {})

    try:
        body = json.loads(event.get("body") or "{}")
    except (json.JSONDecodeError, TypeError):
        return _response(400, {"error": "Invalid JSON body"})

    cluster_name = body.get("cluster_name", "").strip()
    region = body.get("region", "").strip()
    namespace = body.get("namespace", "all").strip()
    account_id = body.get("account_id", "").strip()
    role_arn = body.get("role_arn", "").strip()

    if not cluster_name:
        return _response(400, {"error": "cluster_name is required"})
    if not region:
        return _response(400, {"error": "region is required"})
    if not account_id and not role_arn:
        return _response(400, {"error": "account_id or role_arn is required (multi-account mode)"})

    # Basic input validation — no shell injection possible (used in API calls only)
    if not all(c.isalnum() or c in "-_." for c in cluster_name):
        return _response(400, {"error": "cluster_name contains invalid characters"})
    if account_id and not account_id.isdigit():
        return _response(400, {"error": "account_id must be a 12-digit AWS account number"})

    # Construct role ARN from account_id if not explicitly supplied
    if not role_arn and account_id:
        role_arn = f"arn:aws:iam::{account_id}:role/{SPOKE_ROLE_NAME}"

    job_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    job = {
        "job_id": job_id,
        "cluster_name": cluster_name,
        "region": region,
        "namespace": namespace,
        "account_id": account_id,
        "role_arn": role_arn,
        "status": JobStatus.PENDING.value,
        "started_at": now,
        "completed_at": None,
        "cluster_context": None,
        "executed_commands": [],
        "findings": [],
        "fixes": [],
        "root_cause": "",
        "error_message": None,
    }

    put_job(job)
    logger.info("Created job %s for cluster %s", job_id, cluster_name)

    # Invoke worker Lambda asynchronously (InvocationType=Event)
    worker_payload = {
        "job_id": job_id,
        "cluster_name": cluster_name,
        "region": region,
        "namespace": namespace,
        "role_arn": role_arn,
    }
    try:
        _get_lambda().invoke(
            FunctionName=WORKER_FUNCTION,
            InvocationType="Event",
            Payload=json.dumps(worker_payload),
        )
    except Exception as exc:
        logger.error("Failed to invoke worker for job %s: %s", job_id, exc)
        # Don't fail — client can poll status; worker can be retried
        from shared.storage import update_job_status
        update_job_status(job_id, JobStatus.FAILED.value, error_message=str(exc))
        return _response(500, {"error": f"Failed to start worker: {exc}"})

    return _response(202, {
        "job_id": job_id,
        "status": JobStatus.PENDING.value,
        "message": "Diagnosis started. Poll GET /api/v1/diagnose/{job_id} for status.",
    })
