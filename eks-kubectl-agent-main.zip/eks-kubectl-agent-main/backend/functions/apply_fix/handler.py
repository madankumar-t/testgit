"""
POST /api/v1/fix/apply

Applies a fix recommendation after explicit user confirmation.
The request body MUST include confirmed=true — the frontend enforces
the approval dialog but this Lambda double-checks it server-side.

Body: { job_id, fix_id, confirmed: true }
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone

from shared.k8s_client import get_k8s_api_client
from shared.storage import get_job

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Subset of commands that are explicitly whitelisted for Lambda execution.
# All others are rejected even if confirmed=true.
_ALLOWED_VERBS = {
    "kubectl": {
        "rollout",   # rollout restart / undo
        "scale",
        "cordon",
        "uncordon",
        "annotate",
        "label",
    }
}

_SAFE_READ_VERBS = {"get", "describe", "logs", "top", "auth", "config", "cluster-info"}


def _cors_headers() -> dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Content-Type": "application/json",
    }


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body, default=str),
    }


def _validate_command(command: list[str]) -> tuple[bool, str]:
    """Validate the fix command against the allowlist. Returns (is_valid, reason)."""
    if not command:
        return False, "Empty command"
    if "--force" in command:
        return False, "--force flag is not permitted via API"

    binary = command[0]
    if binary == "kubectl" and len(command) >= 2:
        verb = command[1]
        if verb in _SAFE_READ_VERBS:
            return True, "read-only"
        if verb in _ALLOWED_VERBS.get("kubectl", set()):
            return True, "allowed mutating"
        return False, f"kubectl verb '{verb}' is not in the server-side allowlist"

    return False, f"Binary '{binary}' is not permitted via API"


def _execute_fix_via_k8s_sdk(
    command: list[str],
    cluster_name: str,
    region: str,
    role_arn: str | None = None,
) -> tuple[bool, str]:
    """
    Execute a whitelisted kubectl-equivalent operation using the kubernetes SDK.
    Maps kubectl commands to SDK calls — no shell execution.
    """
    from kubernetes import client as k8s_client

    api_client = get_k8s_api_client(cluster_name, region, role_arn)
    apps = k8s_client.AppsV1Api(api_client)
    core = k8s_client.CoreV1Api(api_client)

    verb = command[1] if len(command) > 1 else ""

    try:
        if verb == "rollout" and len(command) >= 3:
            sub = command[2]
            if sub == "restart" and len(command) >= 4:
                resource = command[3]
                namespace = command[command.index("-n") + 1] if "-n" in command else "default"
                kind, name = (resource.split("/", 1) + [""])[:2]
                if kind == "deployment":
                    # Patch restartedAt annotation to trigger rollout
                    now = datetime.now(timezone.utc).isoformat()
                    patch = {
                        "spec": {
                            "template": {
                                "metadata": {
                                    "annotations": {
                                        "kubectl.kubernetes.io/restartedAt": now
                                    }
                                }
                            }
                        }
                    }
                    apps.patch_namespaced_deployment(name, namespace, patch)
                    return True, f"Rollout restart triggered for deployment/{name} in {namespace}"
            elif sub == "undo" and len(command) >= 4:
                return False, "Rollout undo requires direct API access not yet implemented. Use kubectl locally."

        elif verb == "cordon" and len(command) >= 3:
            node_name = command[2]
            patch = {"spec": {"unschedulable": True}}
            core.patch_node(node_name, patch)
            return True, f"Node {node_name} cordoned successfully"

        elif verb == "uncordon" and len(command) >= 3:
            node_name = command[2]
            patch = {"spec": {"unschedulable": False}}
            core.patch_node(node_name, patch)
            return True, f"Node {node_name} uncordoned successfully"

        elif verb == "scale" and len(command) >= 4:
            return False, "Scale via API not yet implemented. Use kubectl locally."

        return False, f"Operation '{verb}' not yet implemented in Lambda mode."

    except Exception as exc:
        return False, str(exc)


def handler(event: dict, context) -> dict:
    if event.get("httpMethod") == "OPTIONS":
        return _response(200, {})

    try:
        body = json.loads(event.get("body") or "{}")
    except (json.JSONDecodeError, TypeError):
        return _response(400, {"error": "Invalid JSON body"})

    job_id = body.get("job_id", "").strip()
    fix_id = body.get("fix_id", "").strip()
    confirmed = body.get("confirmed", False)

    if not job_id or not fix_id:
        return _response(400, {"error": "job_id and fix_id are required"})

    # Server-side confirmation check — must be explicitly true
    if confirmed is not True:
        return _response(403, {
            "error": "Fix not confirmed. Set confirmed=true in the request body to approve execution."
        })

    # Load job to get fixes
    job = get_job(job_id)
    if job is None:
        return _response(404, {"error": f"Job '{job_id}' not found"})

    fixes = job.get("fixes", [])
    fix = next((f for f in fixes if f.get("fix_id") == fix_id), None)
    if fix is None:
        return _response(404, {"error": f"Fix '{fix_id}' not found in job '{job_id}'"})

    command = fix.get("command", [])
    cluster_name = job["cluster_name"]
    region = job["region"]
    role_arn = job.get("role_arn") or None

    # Validate command against server-side allowlist
    is_valid, reason = _validate_command(command)
    if not is_valid:
        logger.warning("Rejected fix command %s: %s", command, reason)
        return _response(403, {"error": f"Command rejected: {reason}"})

    logger.info("Executing fix %s for job %s: %s", fix_id, job_id, command)

    success, output = _execute_fix_via_k8s_sdk(command, cluster_name, region, role_arn)

    if success:
        return _response(200, {
            "fix_id": fix_id,
            "job_id": job_id,
            "success": True,
            "output": output,
            "applied_at": datetime.now(timezone.utc).isoformat(),
            "validation_commands": [
                "kubectl get pods -A",
                "kubectl get events -A --sort-by=.lastTimestamp",
            ],
        })
    else:
        return _response(500, {
            "fix_id": fix_id,
            "job_id": job_id,
            "success": False,
            "error": output,
        })
