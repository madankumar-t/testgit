# GitHub Actions Now, Spacelift Later

This repository is now set up so GitHub Actions and Spacelift can use the same Terraform code and the same variable names.

## What Was Added

- GitHub Actions workflow: .github/workflows/terraform-deploy.yml
- Shared deployment guidance: this file

## Core Compatibility Rule

Use the same TF_VAR_* keys in both systems.

That means:
- In GitHub: set these as Repository Variables and Secrets.
- In Spacelift: set the exact same names as stack environment variables.

No Terraform code changes are needed when moving from GitHub Actions to Spacelift.

## Required GitHub Setup

### 1) GitHub OIDC deploy role

Create an IAM role in AWS that trusts GitHub OIDC and has permissions to deploy this stack.
Save its ARN in this GitHub Secret:

- AWS_DEPLOY_ROLE_ARN

### 2) GitHub repository Variables (non-secret)

Set these in GitHub repository Variables:

- TF_VAR_aws_region
- TF_VAR_environment
- TF_VAR_eks_regions
- TF_VAR_deploy_spoke_roles
- TF_VAR_bootstrap_role_name
- TF_VAR_spoke_role_name
- TF_VAR_cors_origin

Example values:
- TF_VAR_aws_region = us-east-1
- TF_VAR_environment = prod
- TF_VAR_eks_regions = us-east-1,us-east-2,us-west-2,eu-west-1
- TF_VAR_deploy_spoke_roles = true
- TF_VAR_bootstrap_role_name = OrganizationAccountAccessRole
- TF_VAR_spoke_role_name = eks-agent-spoke-role
- TF_VAR_cors_origin = *

### 3) GitHub repository Secrets (sensitive or large JSON)

Set these in GitHub repository Secrets:

- TF_VAR_spoke_accounts
- TF_VAR_vpc_subnet_ids
- TF_VAR_vpc_security_group_ids
- TF_VAR_existing_tgw_id
- TF_VAR_existing_vpc_id
- TF_VAR_tags

JSON examples:

TF_VAR_spoke_accounts
{"111122223333":"Production","444455556666":"Staging"}

TF_VAR_vpc_subnet_ids
["subnet-aaa11111","subnet-bbb22222"]

TF_VAR_vpc_security_group_ids
["sg-ccc33333"]

TF_VAR_tags
{"Team":"platform","ManagedBy":"terraform"}

## Workflow Behavior

- Pull request: runs fmt, init, validate, plan
- Push to main: runs plan then apply
- Manual run: choose plan or apply from workflow_dispatch

## Spacelift Migration (Future)

You already have stack config in .spacelift/config.yml.
When moving to Spacelift:

1. Keep project_root as infrastructure/terraform.
2. Keep Terraform version aligned with GitHub workflow.
3. Define the same TF_VAR_* names in Spacelift stack environment.
4. Configure Spacelift AWS integration role (OIDC or static integration).

Because variable names and Terraform root are unchanged, migration is operational only.

## Notes

- This project uses local-exec hooks during Terraform runs for:
  - Python script for spoke role deployment
  - Frontend build and upload
- The GitHub workflow installs Python, boto3, and Node.js so those hooks work.
- Ensure your deploy role has permissions for Lambda, API Gateway, DynamoDB, S3, CloudFront, IAM, EC2 networking, STS AssumeRole, and CloudFormation in member accounts.
