'use client'
import { useState } from 'react'
import { AlertTriangle, CheckCircle, ChevronDown, ChevronRight, Copy, Check, Shield } from 'lucide-react'
import { cn, riskColor } from '@/lib/utils'
import type { FixRecommendation } from '@/lib/types'

interface Props {
  fix: FixRecommendation
  jobId: string
  onApply: (fixId: string) => void
  applying?: boolean
}

export function FixCard({ fix, jobId, onApply, applying }: Props) {
  const [open, setOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  function copy(text: string) {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="rounded-lg border border-slate-700/60 bg-slate-800/40 overflow-hidden">
      {/* Header */}
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-slate-700/30 transition-colors"
      >
        {open ? <ChevronDown size={14} className="text-slate-500 shrink-0" /> : <ChevronRight size={14} className="text-slate-500 shrink-0" />}

        <span className={cn('text-xs font-semibold uppercase', riskColor(fix.risk))}>
          {fix.risk} Risk
        </span>
        <span className="text-sm text-slate-200 truncate">{fix.description}</span>
        <span className="text-xs text-slate-500 font-mono ml-auto shrink-0">{fix.fix_id}</span>
      </button>

      {/* Expanded */}
      {open && (
        <div className="px-4 pb-4 space-y-3 border-t border-slate-700/40 pt-3">
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Command to Execute</p>
            <div className="relative group">
              <pre className="log-output text-xs bg-slate-900/60 rounded p-3 text-yellow-200 border border-yellow-500/20 overflow-x-auto pr-10">
                {fix.command.join(' ')}
              </pre>
              <button
                onClick={() => copy(fix.command.join(' '))}
                className="absolute top-2 right-2 p-1.5 rounded text-slate-500 hover:text-slate-300 hover:bg-slate-700/50 opacity-0 group-hover:opacity-100 transition-all"
              >
                {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Expected Result</p>
              <p className="text-xs text-slate-300">{fix.expected_result}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Rollback</p>
              {fix.rollback_command ? (
                <code className="text-xs text-orange-300">{fix.rollback_command.join(' ')}</code>
              ) : (
                <p className="text-xs text-slate-500">N/A</p>
              )}
            </div>
          </div>

          {fix.rollback_description && (
            <p className="text-xs text-slate-500 italic">{fix.rollback_description}</p>
          )}

          {/* Confirmation warning + Apply button */}
          <div className="flex items-start gap-3 bg-red-500/5 border border-red-500/20 rounded-lg p-3">
            <AlertTriangle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-xs text-red-300 font-medium">Confirmation Required</p>
              <p className="text-xs text-slate-400 mt-1">
                This will modify your EKS cluster. Ensure you understand the impact and have a rollback plan.
              </p>
            </div>
            <button
              onClick={() => onApply(fix.fix_id)}
              disabled={applying}
              className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-red-500/15 text-red-300 border border-red-500/30 hover:bg-red-500/25 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Shield size={12} />
              {applying ? 'Applying…' : 'Approve & Apply'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
