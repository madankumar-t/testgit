'use client'
import { AlertTriangle, X, Shield, Terminal } from 'lucide-react'
import type { FixRecommendation } from '@/lib/types'
import { riskColor } from '@/lib/utils'

interface Props {
  fix: FixRecommendation
  onConfirm: () => void
  onCancel: () => void
  applying: boolean
}

export function FixApprovalModal({ fix, onConfirm, onCancel, applying }: Props) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onCancel} />

      {/* Modal */}
      <div className="relative w-full max-w-lg bg-slate-800 border border-slate-600 rounded-xl shadow-2xl">
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-700">
          <div className="w-8 h-8 rounded-lg bg-red-500/15 border border-red-500/30 flex items-center justify-center">
            <AlertTriangle size={14} className="text-red-400" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-100">Confirm Fix Application</p>
            <p className="text-xs text-slate-500">This action will modify your EKS cluster</p>
          </div>
          <button onClick={onCancel} className="ml-auto text-slate-500 hover:text-slate-300 p-1 rounded">
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="px-5 py-4 space-y-4">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-bold uppercase ${riskColor(fix.risk)}`}>{fix.risk} RISK</span>
            <span className="text-xs text-slate-500 font-mono">{fix.fix_id}</span>
          </div>

          <p className="text-sm text-slate-300">{fix.description}</p>

          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">
              <Terminal size={10} /> Command
            </p>
            <pre className="log-output text-xs bg-slate-900/80 border border-yellow-500/20 rounded-lg p-3 text-yellow-200 overflow-x-auto">
              {fix.command.join(' ')}
            </pre>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <p className="text-slate-500 uppercase tracking-wide mb-1">Expected Result</p>
              <p className="text-slate-300">{fix.expected_result}</p>
            </div>
            <div>
              <p className="text-slate-500 uppercase tracking-wide mb-1">Rollback</p>
              {fix.rollback_command ? (
                <code className="text-orange-300">{fix.rollback_command.join(' ')}</code>
              ) : (
                <p className="text-slate-500">No rollback available</p>
              )}
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-3">
            <p className="text-xs text-slate-400">
              By clicking <strong className="text-slate-200">Approve & Execute</strong>, you confirm
              you understand the impact and approve this change to your EKS cluster.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-slate-700">
          <button
            onClick={onCancel}
            disabled={applying}
            className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 border border-slate-700 hover:border-slate-500 rounded-lg transition-all disabled:opacity-50"
          >
            Cancel — Do Not Apply
          </button>
          <button
            onClick={onConfirm}
            disabled={applying}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Shield size={14} />
            {applying ? 'Applying…' : 'Approve & Execute'}
          </button>
        </div>
      </div>
    </div>
  )
}
