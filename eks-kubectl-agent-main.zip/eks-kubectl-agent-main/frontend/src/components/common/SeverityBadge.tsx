import { cn, severityBg, severityColor, severityDot } from '@/lib/utils'
import type { Severity } from '@/lib/types'

interface Props {
  severity: Severity
  className?: string
  dot?: boolean
}

export function SeverityBadge({ severity, className, dot = true }: Props) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium',
        severityBg(severity),
        severityColor(severity),
        className
      )}
    >
      {dot && <span className={cn('w-1.5 h-1.5 rounded-full', severityDot(severity))} />}
      {severity}
    </span>
  )
}
