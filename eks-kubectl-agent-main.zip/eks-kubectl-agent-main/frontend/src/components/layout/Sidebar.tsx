'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Activity,
  Search,
  FileText,
  Terminal,
  Wrench,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV_ITEMS = [
  { href: '/', icon: Activity, label: 'Dashboard' },
  { href: '/diagnose', icon: Search, label: 'New Diagnosis' },
  { href: '/logs', icon: Terminal, label: 'Log Viewer' },
]

const SECTION_LABEL = 'text-xs font-semibold text-slate-500 uppercase tracking-widest px-3 mb-2'

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed inset-y-0 left-0 w-64 bg-slate-800/80 border-r border-slate-700/50 backdrop-blur-sm flex flex-col z-50">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-500/40 flex items-center justify-center">
            <ShieldCheck size={16} className="text-blue-400" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-100">EKS Agent</p>
            <p className="text-xs text-slate-500">Troubleshooting</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
        <p className={SECTION_LABEL}>Navigation</p>
        {NAV_ITEMS.map(({ href, icon: Icon, label }) => {
          const active = pathname === href || (href !== '/' && pathname.startsWith(href))
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150 group',
                active
                  ? 'bg-blue-500/15 text-blue-300 border border-blue-500/25'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              )}
            >
              <Icon size={16} className={active ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300'} />
              <span>{label}</span>
              {active && <ChevronRight size={12} className="ml-auto text-blue-400/60" />}
            </Link>
          )
        })}

        <div className="pt-4">
          <p className={SECTION_LABEL}>Resources</p>
          <a
            href="https://docs.aws.amazon.com/eks/latest/userguide/what-is-eks.html"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-slate-400 hover:text-slate-200 hover:bg-slate-700/50 transition-all"
          >
            <FileText size={16} className="text-slate-500" />
            EKS Docs
          </a>
        </div>
      </nav>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-slate-700/50">
        <p className="text-xs text-slate-600">Read-only by default.</p>
        <p className="text-xs text-slate-600 mt-0.5">Fixes require confirmation.</p>
      </div>
    </aside>
  )
}
