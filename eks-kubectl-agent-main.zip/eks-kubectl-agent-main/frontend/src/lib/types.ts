// Shared TypeScript types mirroring the backend models

export type Severity = 'Critical' | 'High' | 'Medium' | 'Low' | 'Info'
export type FixRisk = 'High' | 'Medium' | 'Low'
export type JobStatus = 'pending' | 'running' | 'complete' | 'failed'

export interface ClusterContext {
  cluster_name: string
  region: string
  aws_account: string
  aws_user: string
  kubernetes_version: string
  node_count: number
  namespaces: string[]
  kubectl_context: string
  api_server: string
}

export interface ExecutedCommand {
  step: number
  command: string
  purpose: string
  result_summary: string
  success: boolean
}

export interface Finding {
  component: string
  namespace: string
  resource: string
  severity: Severity
  evidence: string
  impact: string
  recommended_fix: string
  fix_command?: string
  rollback_command?: string
  fix_id?: string
}

export interface FixRecommendation {
  fix_id: string
  description: string
  command: string[]
  risk: FixRisk
  expected_result: string
  rollback_command?: string[]
  rollback_description: string
  requires_confirmation: boolean
  namespace?: string
  resource?: string
}

export interface DiagnosisSummary {
  total: number
  by_severity: Record<Severity, number>
  affected_components: string[]
  affected_namespaces: string[]
}

export interface DiagnosisJob {
  job_id: string
  status: JobStatus
  cluster_name: string
  account_id: string
  region: string
  namespace: string
  started_at: string
  completed_at?: string
  cluster_context?: ClusterContext
  executed_commands: ExecutedCommand[]
  findings: Finding[]
  fixes: FixRecommendation[]
  root_cause: string
  error_message?: string
  summary: DiagnosisSummary
}

export interface StartDiagnoseRequest {
  cluster_name: string
  account_id: string
  region: string
  namespace: string
  role_arn?: string   // optional override; otherwise constructed from account_id
}

export interface StartDiagnoseResponse {
  job_id: string
  status: JobStatus
  message: string
}

export interface LogRequest {
  cluster_name: string
  account_id?: string
  role_arn?: string
  region: string
  namespace: string
  pod_name: string
  container?: string
  tail_lines?: number
  previous?: boolean
}

export interface LogResponse {
  cluster_name: string
  namespace: string
  pod_name: string
  container?: string
  tail_lines: number
  previous: boolean
  logs: string
}

export interface PodInfo {
  namespace: string
  name: string
  phase: string
  node_name?: string
  pod_ip?: string
  containers: ContainerStatus[]
  conditions: Record<string, string>
}

export interface ContainerStatus {
  name: string
  ready: boolean
  restart_count: number
  state: string
  state_detail: Record<string, unknown>
  image: string
}

export interface ApplyFixRequest {
  job_id: string
  fix_id: string
  confirmed: true
}

export interface ApplyFixResponse {
  fix_id: string
  job_id: string
  success: boolean
  output?: string
  error?: string
  applied_at?: string
  validation_commands?: string[]
}

// UI-only types
export interface RecentDiagnosis {
  job_id: string
  cluster_name: string
  region: string
  status: JobStatus
  started_at: string
  summary?: DiagnosisSummary
}

// Multi-account / multi-cluster discovery
export interface AccountInfo {
  account_id: string
  label: string           // label from SPOKE_ACCOUNT_IDS, falls back to account_id
}

export interface ClusterInfo {
  name: string
  region: string
  status: string          // ACTIVE | CREATING | UPDATING | DELETING | FAILED | UNKNOWN
  version: string
  endpoint: string
  arn: string
  tags: Record<string, string>
}

export const SEVERITY_ORDER: Record<Severity, number> = {
  Critical: 0,
  High: 1,
  Medium: 2,
  Low: 3,
  Info: 4,
}

export const AWS_REGIONS = [
  'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
  'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1', 'eu-north-1',
  'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1', 'ap-northeast-2',
  'ap-south-1', 'ca-central-1', 'sa-east-1', 'af-south-1', 'me-south-1',
]
