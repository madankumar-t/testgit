'use client'
import { useState, useRef, useCallback } from 'react'
import { Terminal, RefreshCw, ChevronDown, AlertCircle, Download, Trash2 } from 'lucide-react'
import { LoadingSpinner } from '@/components/common/LoadingSpinner'
import { getPodLogs, listPods } from '@/lib/api'
import { AWS_REGIONS } from '@/lib/types'
import type { PodInfo } from '@/lib/types'

export default function LogViewerPage() {
  const [form, setForm] = useState({
    cluster_name: '',
    region: 'us-east-1',
    namespace: 'default',
    pod_name: '',
    container: '',
    tail_lines: 200,
    previous: false,
  })
  const [pods, setPods] = useState<PodInfo[]>([])
  const [loadingPods, setLoadingPods] = useState(false)
  const [logs, setLogs] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const logRef = useRef<HTMLPreElement>(null)

  const fetchPods = useCallback(async () => {
    if (!form.cluster_name || !form.region || !form.namespace) return
    setLoadingPods(true)
    try {
      const data = await listPods(form.cluster_name, form.region, form.namespace)
      setPods(data)
    } catch (err: unknown) {
      setPods([])
    } finally {
      setLoadingPods(false)
    }
  }, [form.cluster_name, form.region, form.namespace])

  const fetchLogs = useCallback(async () => {
    if (!form.cluster_name || !form.region || !form.namespace || !form.pod_name) {
      setError('Cluster name, region, namespace, and pod name are required.')
      return
    }
    setError(null)
    setLoading(true)
    setLogs(null)
    try {
      const res = await getPodLogs({
        cluster_name: form.cluster_name,
        region: form.region,
        namespace: form.namespace,
        pod_name: form.pod_name,
        container: form.container || undefined,
        tail_lines: form.tail_lines,
        previous: form.previous,
      })
      setLogs(res.logs)
      setTimeout(() => logRef.current?.scrollTo({ top: 99999, behavior: 'smooth' }), 100)
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error
        ?? (err instanceof Error ? err.message : 'Failed to fetch logs.')
      setError(msg)
    } finally {
      setLoading(false)
    }
  }, [form])

  function downloadLogs() {
    if (!logs) return
    const blob = new Blob([logs], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${form.pod_name}-logs.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  const selectedPod = pods.find((p) => p.name === form.pod_name)
  const containers = selectedPod?.containers.map((c) => c.name) ?? []

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-3">
          <Terminal size={22} className="text-blue-400" />
          Log Viewer
        </h1>
        <p className="text-slate-400 mt-1 text-sm">
          Fetch pod logs directly from EKS. Select a cluster, namespace, and pod.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left: form */}
        <div className="col-span-1 space-y-4">
          <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 space-y-4">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Target</p>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">Cluster Name</label>
              <input
                type="text"
                value={form.cluster_name}
                onChange={(e) => setForm({ ...form, cluster_name: e.target.value })}
                placeholder="my-eks-cluster"
                className="w-full px-3 py-2 bg-slate-900/60 border border-slate-700 rounded-lg text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">Region</label>
              <div className="relative">
                <select
                  value={form.region}
                  onChange={(e) => setForm({ ...form, region: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900/60 border border-slate-700 rounded-lg text-sm text-slate-200 appearance-none focus:outline-none focus:border-blue-500/50"
                >
                  {AWS_REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
                <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">Namespace</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={form.namespace}
                  onChange={(e) => setForm({ ...form, namespace: e.target.value, pod_name: '' })}
                  placeholder="default"
                  className="flex-1 px-3 py-2 bg-slate-900/60 border border-slate-700 rounded-lg text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                />
                <button
                  onClick={fetchPods}
                  disabled={loadingPods || !form.cluster_name}
                  className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-lg text-xs transition-all disabled:opacity-40"
                >
                  {loadingPods ? <LoadingSpinner size="sm" /> : 'List'}
                </button>
              </div>
            </div>

            {/* Pod selector */}
            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">Pod</label>
              {pods.length > 0 ? (
                <div className="relative">
                  <select
                    value={form.pod_name}
                    onChange={(e) => setForm({ ...form, pod_name: e.target.value, container: '' })}
                    className="w-full px-3 py-2 bg-slate-900/60 border border-slate-700 rounded-lg text-sm text-slate-200 appearance-none focus:outline-none focus:border-blue-500/50"
                  >
                    <option value="">Select a pod…</option>
                    {pods.map((p) => (
                      <option key={p.name} value={p.name}>
                        {p.name} ({p.phase})
                      </option>
                    ))}
                  </select>
                  <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                </div>
              ) : (
                <input
                  type="text"
                  value={form.pod_name}
                  onChange={(e) => setForm({ ...form, pod_name: e.target.value })}
                  placeholder="pod-name-xxxxx"
                  className="w-full px-3 py-2 bg-slate-900/60 border border-slate-700 rounded-lg text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                />
              )}
            </div>

            {/* Container */}
            {containers.length > 1 && (
              <div>
                <label className="text-xs text-slate-400 mb-1.5 block">Container</label>
                <div className="relative">
                  <select
                    value={form.container}
                    onChange={(e) => setForm({ ...form, container: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900/60 border border-slate-700 rounded-lg text-sm text-slate-200 appearance-none focus:outline-none focus:border-blue-500/50"
                  >
                    <option value="">All containers</option>
                    {containers.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                </div>
              </div>
            )}

            {/* Options */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-400">Tail lines</label>
                <select
                  value={form.tail_lines}
                  onChange={(e) => setForm({ ...form, tail_lines: Number(e.target.value) })}
                  className="px-2 py-1 bg-slate-900/60 border border-slate-700 rounded text-xs text-slate-200 appearance-none"
                >
                  {[50, 100, 200, 500, 1000, 2000].map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.previous}
                  onChange={(e) => setForm({ ...form, previous: e.target.checked })}
                  className="rounded border-slate-600"
                />
                <span className="text-xs text-slate-400">Previous container (crash logs)</span>
              </label>
            </div>

            <button
              onClick={fetchLogs}
              disabled={loading || !form.pod_name}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-600/40 disabled:cursor-not-allowed text-white text-sm font-medium rounded-lg transition-all"
            >
              {loading ? <><LoadingSpinner size="sm" /> Fetching…</> : <><RefreshCw size={13} /> Fetch Logs</>}
            </button>
          </div>
        </div>

        {/* Right: log output */}
        <div className="col-span-2">
          <div className="bg-slate-900 border border-slate-700/50 rounded-xl overflow-hidden h-full min-h-[500px] flex flex-col">
            {/* Log header bar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800/60 border-b border-slate-700/40">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-xs text-slate-400 font-mono">
                  {form.pod_name
                    ? `${form.namespace}/${form.pod_name}${form.container ? `[${form.container}]` : ''}`
                    : 'No pod selected'}
                </span>
              </div>
              {logs && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-600">
                    {logs.split('\n').length} lines
                  </span>
                  <button onClick={downloadLogs} className="text-slate-500 hover:text-slate-300 p-1 rounded">
                    <Download size={12} />
                  </button>
                  <button onClick={() => setLogs(null)} className="text-slate-500 hover:text-slate-300 p-1 rounded">
                    <Trash2 size={12} />
                  </button>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto p-4">
              {error && (
                <div className="flex items-start gap-2 text-red-400 text-xs mb-3">
                  <AlertCircle size={13} className="shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}
              {loading && (
                <div className="flex items-center gap-2 text-slate-400 text-xs">
                  <LoadingSpinner size="sm" />
                  Fetching logs from cluster…
                </div>
              )}
              {!loading && !logs && !error && (
                <div className="flex flex-col items-center justify-center h-64 text-slate-600">
                  <Terminal size={32} className="mb-3" />
                  <p className="text-sm">Select a pod and click Fetch Logs</p>
                </div>
              )}
              {logs && (
                <pre ref={logRef} className="log-output text-xs text-slate-300 whitespace-pre-wrap">
                  {logs}
                </pre>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
