'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Activity, Search, AlertTriangle, CheckCircle, Clock, ChevronRight, Server, Plus } from 'lucide-react'
import { StatusBadge } from '@/components/common/StatusBadge'
import { formatRelativeTime, formatDuration } from '@/lib/utils'
import { getHistory, type HistoryEntry } from '@/lib/api'
import type { JobStatus } from '@/lib/types'

const SEVERITY_COLS: { label: string; key: string; color: string }[] = [
  { label: 'Critical', key: 'Critical', color: 'text-red-400' },
  { label: 'High', key: 'High', color: 'text-orange-400' },
  { label: 'Medium', key: 'Medium', color: 'text-yellow-400' },
  { label: 'Low', key: 'Low', color: 'text-green-400' },
]

export default function DashboardPage() {
  const [history, setHistory] = useState<HistoryEntry[]>([])

  useEffect(() => {
    setHistory(getHistory())
  }, [])

  const total = history.length
  const completed = history.filter((h) => h.status === 'complete').length
  const failed = history.filter((h) => h.status === 'failed').length
  const running = history.filter((h) => h.status === 'running' || h.status === 'pending').length

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Page header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">EKS Troubleshooting Agent</h1>
          <p className="text-slate-400 mt-1 text-sm">
            AI-assisted read-only diagnostics for Amazon EKS clusters
          </p>
        </div>
        <Link
          href="/diagnose"
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg transition-colors"
        >
          <Plus size={15} />
          New Diagnosis
        </Link>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { icon: Activity, label: 'Total Runs', value: total, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20' },
          { icon: CheckCircle, label: 'Completed', value: completed, color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20' },
          { icon: Clock, label: 'In Progress', value: running, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' },
          { icon: AlertTriangle, label: 'Failed', value: failed, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20' },
        ].map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className={`rounded-xl border p-4 ${bg}`}>
            <div className="flex items-center gap-2 mb-2">
              <Icon size={15} className={color} />
              <span className="text-xs text-slate-400">{label}</span>
            </div>
            <p className={`text-3xl font-bold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      {/* Safety notice */}
      <div className="mb-8 flex items-start gap-3 bg-blue-500/5 border border-blue-500/20 rounded-xl p-4">
        <Server size={16} className="text-blue-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-blue-300">Read-Only Diagnostic Mode</p>
          <p className="text-xs text-slate-400 mt-1">
            All diagnostics are performed using read-only API calls. No cluster state is modified during diagnosis.
            Fix commands require explicit approval and are executed with a server-side allowlist validation.
          </p>
        </div>
      </div>

      {/* Recent diagnoses */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wide">Recent Diagnoses</h2>
          <Link href="/diagnose" className="text-xs text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1">
            Run new <ChevronRight size={12} />
          </Link>
        </div>

        {history.length === 0 ? (
          <div className="rounded-xl border border-slate-700/50 bg-slate-800/30 py-16 flex flex-col items-center gap-4 text-slate-500">
            <Search size={32} className="text-slate-600" />
            <div className="text-center">
              <p className="text-sm font-medium text-slate-400">No diagnoses yet</p>
              <p className="text-xs mt-1">Run your first EKS diagnosis to see results here.</p>
            </div>
            <Link
              href="/diagnose"
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg transition-colors"
            >
              <Plus size={14} />
              Start First Diagnosis
            </Link>
          </div>
        ) : (
          <div className="rounded-xl border border-slate-700/50 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700/50 bg-slate-800/50">
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wide">Cluster</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wide">Account ID</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wide">Region</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wide">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wide">Started</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wide">Job ID</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {history.map((item) => (
                  <tr key={item.job_id} className="border-b border-slate-700/30 hover:bg-slate-800/40 transition-colors">
                    <td className="px-4 py-3 font-medium text-slate-200">{item.cluster_name}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs font-mono">{item.account_id || '—'}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs font-mono">{item.region}</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={item.status as JobStatus} pulse />
                    </td>
                    <td className="px-4 py-3 text-slate-500 text-xs">{formatRelativeTime(item.started_at)}</td>
                    <td className="px-4 py-3 text-slate-600 text-xs font-mono">{item.job_id.slice(0, 8)}…</td>
                    <td className="px-4 py-3 text-right">
                      <Link
                        href={`/results?id=${item.job_id}`}
                        className="text-xs text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1 justify-end"
                      >
                        View <ChevronRight size={12} />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

