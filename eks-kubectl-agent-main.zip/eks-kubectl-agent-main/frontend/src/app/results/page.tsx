'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import {
  Activity, AlertTriangle, CheckCircle, Clock, ChevronLeft,
  Server, Terminal, Wrench, FileText, RefreshCw,
} from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { getDiagnosis, updateHistoryStatus } from '@/lib/api'
import { FindingsPanel } from '@/components/findings/FindingsPanel'
import { FixCard } from '@/components/fixes/FixCard'
import { FixApprovalModal } from '@/components/fixes/FixApprovalModal'
import { StatusBadge } from '@/components/common/StatusBadge'
import { SeverityBadge } from '@/components/common/SeverityBadge'
import { LoadingSpinner, PageLoader } from '@/components/common/LoadingSpinner'
import { applyFix } from '@/lib/api'
import type { DiagnosisJob, FixRecommendation, Severity } from '@/lib/types'
import { formatRelativeTime, formatDuration, severityColor } from '@/lib/utils'

type Tab = 'overview' | 'findings' | 'fixes' | 'commands' | 'report'

const SEVERITY_BARS: Severity[] = ['Critical', 'High', 'Medium', 'Low']

export default function ResultsPage() {
  const [jobId, setJobId] = useState('')
  const [activeTab, setActiveTab] = useState<Tab>('overview')
  const [pendingFix, setPendingFix] = useState<FixRecommendation | null>(null)
  const [applyingFixId, setApplyingFixId] = useState<string | null>(null)
  const [fixResult, setFixResult] = useState<{ success: boolean; message: string } | null>(null)

  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get('id') ?? ''
    setJobId(id.trim())
  }, [])

  const { data: job, isLoading, error, refetch } = useQuery<DiagnosisJob>({
    queryKey: ['diagnosis', jobId],
    queryFn: () => getDiagnosis(jobId),
    refetchInterval: (query) => {
      const status = query.state.data?.status
      return status === 'running' || status === 'pending' ? 3000 : false
    },
    enabled: !!jobId,
  })

  useEffect(() => {
    if (job) updateHistoryStatus(jobId, job.status)
  }, [job?.status, jobId])

  async function handleApply(fixId: string) {
    if (!job) return
    const fix = job.fixes.find((f) => f.fix_id === fixId)
    if (fix) setPendingFix(fix)
  }

  async function confirmApply() {
    if (!pendingFix || !job) return
    setApplyingFixId(pendingFix.fix_id)
    setPendingFix(null)
    try {
      const res = await applyFix({ job_id: job.job_id, fix_id: pendingFix.fix_id, confirmed: true })
      setFixResult({ success: res.success, message: res.output ?? res.error ?? '' })
    } catch (err: unknown) {
      setFixResult({ success: false, message: (err instanceof Error ? err.message : 'Apply failed') })
    } finally {
      setApplyingFixId(null)
    }
  }

  if (!jobId) return <div className="p-8 text-red-400">Missing job ID.</div>
  if (isLoading) return <PageLoader message="Loading diagnosis results…" />
  if (error) return (
    <div className="p-8 flex flex-col items-center gap-4 text-red-400">
      <AlertTriangle size={32} />
      <p>Failed to load results. <button onClick={() => refetch()} className="underline">Retry</button></p>
    </div>
  )
  if (!job) return null

  const isRunning = job.status === 'running' || job.status === 'pending'
  const summary = job.summary

  const TABS: { id: Tab; label: string; icon: React.ReactNode; count?: number }[] = [
    { id: 'overview', label: 'Overview', icon: <Activity size={13} /> },
    { id: 'findings', label: 'Findings', icon: <AlertTriangle size={13} />, count: summary?.total },
    { id: 'fixes', label: 'Fixes', icon: <Wrench size={13} />, count: job.fixes.length },
    { id: 'commands', label: 'Commands', icon: <Terminal size={13} />, count: job.executed_commands.length },
    { id: 'report', label: 'Report', icon: <FileText size={13} /> },
  ]

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-slate-500 mb-5">
        <Link href="/" className="hover:text-slate-300 transition-colors">Dashboard</Link>
        <span>/</span>
        <span className="text-slate-400">{job.cluster_name}</span>
        <span>/</span>
        <span className="text-slate-600 font-mono">{jobId.slice(0, 8)}…</span>
      </div>

      {/* Header */}
      <div className="flex items-start justify-between mb-6 gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-xl font-bold text-slate-100">{job.cluster_name}</h1>
            <StatusBadge status={job.status} pulse />
            {isRunning && <LoadingSpinner size="sm" />}
          </div>
          <div className="flex items-center gap-4 mt-1.5 text-xs text-slate-500 flex-wrap">
            <span className="font-mono">{job.region}</span>
            <span>ns: {job.namespace}</span>
            <span>Started {formatRelativeTime(job.started_at)}</span>
            {job.completed_at && (
              <span>Duration: {formatDuration(job.started_at, job.completed_at)}</span>
            )}
          </div>
        </div>
        <button
          onClick={() => refetch()}
          className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-400 border border-slate-700 rounded-lg hover:border-slate-500 hover:text-slate-200 transition-all"
        >
          <RefreshCw size={12} />
          Refresh
        </button>
      </div>

      {/* Running banner */}
      {isRunning && (
        <div className="mb-5 flex items-center gap-3 bg-blue-500/5 border border-blue-500/20 rounded-xl p-4">
          <div className="w-2 h-2 rounded-full bg-blue-500 pulse-blue" />
          <p className="text-sm text-blue-300">
            Diagnosis is running — collecting data from {job.cluster_name}. Auto-refreshing every 3 seconds.
          </p>
        </div>
      )}

      {/* Failed banner */}
      {job.status === 'failed' && job.error_message && (
        <div className="mb-5 flex items-start gap-3 bg-red-500/5 border border-red-500/20 rounded-xl p-4">
          <AlertTriangle size={16} className="text-red-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-300">Diagnosis Failed</p>
            <p className="text-xs text-slate-400 mt-1">{job.error_message}</p>
          </div>
        </div>
      )}

      {/* Fix result banner */}
      {fixResult && (
        <div className={`mb-5 flex items-start gap-3 rounded-xl p-4 border ${fixResult.success ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
          {fixResult.success ? <CheckCircle size={16} className="text-green-400 shrink-0 mt-0.5" /> : <AlertTriangle size={16} className="text-red-400 shrink-0 mt-0.5" />}
          <div className="flex-1">
            <p className={`text-sm font-medium ${fixResult.success ? 'text-green-300' : 'text-red-300'}`}>
              {fixResult.success ? 'Fix Applied Successfully' : 'Fix Failed'}
            </p>
            {fixResult.message && <p className="text-xs text-slate-400 mt-1 font-mono">{fixResult.message}</p>}
          </div>
          <button onClick={() => setFixResult(null)} className="text-slate-500 hover:text-slate-300 text-xs">✕</button>
        </div>
      )}

      {/* Summary cards */}
      {summary && job.status === 'complete' && (
        <div className="grid grid-cols-5 gap-3 mb-6">
          <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 col-span-1">
            <p className="text-xs text-slate-500 mb-1">Total Findings</p>
            <p className="text-3xl font-bold text-slate-100">{summary.total}</p>
          </div>
          {SEVERITY_BARS.map((s) => (
            <div key={s} className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-1">{s}</p>
              <p className={`text-3xl font-bold ${severityColor(s)}`}>
                {summary.by_severity[s] ?? 0}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-700/50 mb-5">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-all -mb-px
              ${activeTab === tab.id
                ? 'border-blue-500 text-blue-300'
                : 'border-transparent text-slate-500 hover:text-slate-300'}`}
          >
            {tab.icon}
            {tab.label}
            {tab.count !== undefined && (
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${activeTab === tab.id ? 'bg-blue-500/20 text-blue-300' : 'bg-slate-700 text-slate-400'}`}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'overview' && (
        <OverviewTab job={job} />
      )}
      {activeTab === 'findings' && (
        <FindingsPanel findings={job.findings} />
      )}
      {activeTab === 'fixes' && (
        <div className="space-y-3">
          {job.fixes.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <CheckCircle size={32} className="mx-auto mb-3 text-green-600" />
              <p className="text-sm">No fix recommendations generated.</p>
            </div>
          ) : (
            job.fixes.map((fix) => (
              <FixCard
                key={fix.fix_id}
                fix={fix}
                jobId={job.job_id}
                onApply={handleApply}
                applying={applyingFixId === fix.fix_id}
              />
            ))
          )}
        </div>
      )}
      {activeTab === 'commands' && (
        <CommandsTab commands={job.executed_commands} />
      )}
      {activeTab === 'report' && (
        <ReportTab job={job} />
      )}

      {/* Fix approval modal */}
      {pendingFix && (
        <FixApprovalModal
          fix={pendingFix}
          onConfirm={confirmApply}
          onCancel={() => setPendingFix(null)}
          applying={!!applyingFixId}
        />
      )}
    </div>
  )
}

// ---- Sub-components ----

function OverviewTab({ job }: { job: DiagnosisJob }) {
  const ctx = job.cluster_context
  return (
    <div className="space-y-5">
      {/* Root cause */}
      {job.root_cause && (
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-5">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-2">
            <AlertTriangle size={12} className="text-yellow-400" /> Root Cause
          </p>
          <p className="text-sm text-slate-300 leading-relaxed">{job.root_cause}</p>
        </div>
      )}

      {/* Cluster context */}
      {ctx && (
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-5">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Server size={12} /> Cluster Context
          </p>
          <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm">
            {[
              ['Cluster Name', ctx.cluster_name],
              ['Region', ctx.region],
              ['AWS Account', ctx.aws_account],
              ['Kubernetes Version', ctx.kubernetes_version],
              ['Node Count', String(ctx.node_count)],
              ['Namespaces', String(ctx.namespaces?.length ?? '—')],
              ['API Server', ctx.api_server],
            ].map(([label, value]) => (
              <div key={label} className="flex gap-3">
                <span className="text-slate-500 w-36 shrink-0">{label}</span>
                <span className="text-slate-200 font-mono text-xs break-all">{value || '—'}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Affected namespaces */}
      {job.summary?.affected_namespaces?.length > 0 && (
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-5">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Affected Namespaces</p>
          <div className="flex flex-wrap gap-2">
            {job.summary.affected_namespaces.map((ns) => (
              <span key={ns} className="px-2 py-1 bg-slate-700/50 rounded text-xs font-mono text-slate-300">{ns}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function CommandsTab({ commands }: { commands: DiagnosisJob['executed_commands'] }) {
  return (
    <div className="rounded-xl border border-slate-700/50 overflow-hidden">
      <table className="w-full text-xs">
        <thead>
          <tr className="bg-slate-800/60 border-b border-slate-700/50">
            <th className="text-left px-4 py-3 text-slate-500 font-medium w-12">#</th>
            <th className="text-left px-4 py-3 text-slate-500 font-medium">Command</th>
            <th className="text-left px-4 py-3 text-slate-500 font-medium">Purpose</th>
            <th className="text-left px-4 py-3 text-slate-500 font-medium w-32">Result</th>
          </tr>
        </thead>
        <tbody>
          {commands.map((cmd) => (
            <tr key={cmd.step} className="border-b border-slate-700/30 hover:bg-slate-800/30">
              <td className="px-4 py-2.5 text-slate-600">{cmd.step}</td>
              <td className="px-4 py-2.5 font-mono text-slate-300 max-w-xs truncate">{cmd.command}</td>
              <td className="px-4 py-2.5 text-slate-400">{cmd.purpose}</td>
              <td className="px-4 py-2.5">
                <span className={cmd.success ? 'text-green-400' : 'text-red-400'}>
                  {cmd.success ? '✅ OK' : '❌ Failed'}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function ReportTab({ job }: { job: DiagnosisJob }) {
  const [copied, setCopied] = useState(false)

  function buildMarkdown(): string {
    const ctx = job.cluster_context
    const now = new Date().toUTCString()
    const s = job.summary
    const lines: string[] = [
      `# EKS Incident Troubleshooting Report`,
      ``,
      `> **Generated:** ${now}`,
      ``,
      `## 1. Incident Summary`,
      ``,
      `Cluster: **\`${job.cluster_name}\`** | Region: **\`${job.region}\`** | Status: **${job.status}**`,
      ``,
      `- Total findings: **${s?.total ?? 0}**`,
      `- Critical: **${s?.by_severity?.Critical ?? 0}** | High: **${s?.by_severity?.High ?? 0}** | Medium: **${s?.by_severity?.Medium ?? 0}**`,
      ``,
      `## 2. Root Cause`,
      ``,
      job.root_cause || 'Under investigation.',
      ``,
      `## 3. Commands Executed`,
      ``,
      `| Step | Command | Purpose | Result |`,
      `|---|---|---|---|`,
      ...job.executed_commands.map(
        (c) => `| ${c.step} | \`${c.command.replace(/\|/g, '\\|')}\` | ${c.purpose} | ${c.success ? '✅' : '❌'} |`
      ),
      ``,
      `## 4. Findings`,
      ``,
      ...job.findings.map((f) =>
        `### [${f.severity}] ${f.component} — \`${f.resource}\` (ns: \`${f.namespace}\`)\n\n**Evidence:** ${f.evidence}\n\n**Impact:** ${f.impact}\n\n**Fix:** ${f.recommended_fix}\n\n---`
      ),
      ``,
      `## 5. Post-Fix Validation`,
      ``,
      '```bash',
      'kubectl get pods -A',
      'kubectl get events -A --sort-by=.lastTimestamp',
      '```',
    ]
    return lines.join('\n')
  }

  function download() {
    const md = buildMarkdown()
    const blob = new Blob([md], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `eks-incident-${job.cluster_name}-${job.job_id.slice(0, 8)}.md`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">Full incident report for this diagnosis run.</p>
        <button
          onClick={download}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-blue-500/15 text-blue-300 border border-blue-500/30 hover:bg-blue-500/25 rounded-lg transition-all"
        >
          <FileText size={12} />
          Download .md
        </button>
      </div>
      <pre className="log-output text-xs bg-slate-900/60 border border-slate-700/40 rounded-xl p-5 text-slate-300 overflow-auto max-h-[60vh]">
        {buildMarkdown()}
      </pre>
    </div>
  )
}

