'use client'
import { useState, useCallback, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Search, AlertCircle, Info, ChevronDown, RefreshCw } from 'lucide-react'
import { LoadingSpinner } from '@/components/common/LoadingSpinner'
import { startDiagnosis, saveToHistory, listAccounts, listClusters } from '@/lib/api'
import type { AccountInfo, ClusterInfo } from '@/lib/types'
import { AWS_REGIONS } from '@/lib/types'

export default function DiagnosePage() {
  const router = useRouter()

  // ── account / cluster discovery ──────────────────────────────────────────
  const [accounts, setAccounts] = useState<AccountInfo[]>([])
  const [clusters, setClusters] = useState<ClusterInfo[]>([])
  const [loadingAccounts, setLoadingAccounts] = useState(false)
  const [loadingClusters, setLoadingClusters] = useState(false)
  const [accountsError, setAccountsError] = useState<string | null>(null)

  // ── form state ────────────────────────────────────────────────────────────
  const [form, setForm] = useState({
    account_id: '',
    cluster_name: '',
    region: 'us-east-1',
    namespace: 'all',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // ── fetch accounts on mount ───────────────────────────────────────────────
  const fetchAccounts = useCallback(async () => {
    setLoadingAccounts(true)
    setAccountsError(null)
    try {
      const data = await listAccounts()
      setAccounts(data)
      if (data.length === 1) {
        setForm((f) => ({ ...f, account_id: data[0].account_id }))
      }
    } catch {
      setAccountsError('Could not load accounts. Check that the backend is deployed.')
    } finally {
      setLoadingAccounts(false)
    }
  }, [])

  useEffect(() => { fetchAccounts() }, [fetchAccounts])

  // ── fetch clusters when account or region changes ─────────────────────────
  useEffect(() => {
    if (!form.account_id) {
      setClusters([])
      return
    }
    let cancelled = false
    setLoadingClusters(true)
    setClusters([])
    setForm((f) => ({ ...f, cluster_name: '' }))

    listClusters(form.account_id, form.region)
      .then((data) => {
        if (!cancelled) {
          setClusters(data)
          // Auto-select if only one active cluster
          const active = data.filter((c) => c.status === 'ACTIVE')
          if (active.length === 1) {
            setForm((f) => ({ ...f, cluster_name: active[0].name }))
          }
        }
      })
      .catch(() => { if (!cancelled) setClusters([]) })
      .finally(() => { if (!cancelled) setLoadingClusters(false) })

    return () => { cancelled = true }
  }, [form.account_id, form.region])

  // ── submit ────────────────────────────────────────────────────────────────
  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.account_id) { setError('Please select an AWS account.'); return }
    if (!form.cluster_name) { setError('Please select a cluster.'); return }
    setError(null)
    setLoading(true)
    try {
      const res = await startDiagnosis({
        cluster_name: form.cluster_name,
        account_id: form.account_id,
        region: form.region,
        namespace: form.namespace || 'all',
      })
      saveToHistory({
        job_id: res.job_id,
        cluster_name: form.cluster_name,
        account_id: form.account_id,
        region: form.region,
        status: res.status,
        started_at: new Date().toISOString(),
      })
      router.push(`/results?id=${res.job_id}`)
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error
        ?? (err instanceof Error ? err.message : 'An unexpected error occurred.')
      setError(msg)
      setLoading(false)
    }
  }, [form, router])

  const selectedAccount = accounts.find((a) => a.account_id === form.account_id)
  const activeCount = clusters.filter((c) => c.status === 'ACTIVE').length

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-100">New EKS Diagnosis</h1>
        <p className="text-slate-400 mt-1 text-sm">
          Select an account and cluster to start a full read-only diagnostic scan.
        </p>
      </div>

      {/* Info banner */}
      <div className="flex items-start gap-3 bg-blue-500/5 border border-blue-500/20 rounded-xl p-4 mb-6">
        <Info size={15} className="text-blue-400 shrink-0 mt-0.5" />
        <p className="text-xs text-slate-400">
          The agent runs <strong className="text-slate-200">~15 read-only checks</strong> across
          nodes, pods, deployments, services, ingress, ALB, networking, DNS, storage, IAM/IRSA,
          and events. No cluster state is modified. Results are ready in 1–3 minutes.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">

        {/* ── Account selector ─────────────────────────────────────────── */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">
              AWS Account <span className="text-red-400">*</span>
            </label>
            <button
              type="button"
              onClick={fetchAccounts}
              disabled={loadingAccounts}
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              <RefreshCw size={11} className={loadingAccounts ? 'animate-spin' : ''} />
              Refresh
            </button>
          </div>

          {accountsError && (
            <div className="flex items-center gap-2 text-xs text-amber-400 mb-2">
              <AlertCircle size={12} /> {accountsError}
            </div>
          )}

          {loadingAccounts ? (
            <div className="flex items-center gap-2 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-500 text-sm">
              <LoadingSpinner size="sm" /> Loading accounts…
            </div>
          ) : accounts.length === 0 ? (
            <div className="px-4 py-3 bg-slate-800/60 border border-slate-700 rounded-lg text-slate-500 text-sm">
              No accounts configured. Set{' '}
              <code className="text-slate-400">SPOKE_ACCOUNT_IDS</code> in Terraform and re-deploy.
            </div>
          ) : (
            <div className="relative">
              <select
                value={form.account_id}
                onChange={(e) => setForm({ ...form, account_id: e.target.value })}
                required
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 text-sm appearance-none transition-all"
              >
                <option value="">— Select account —</option>
                {accounts.map((a) => (
                  <option key={a.account_id} value={a.account_id}>
                    {a.label !== a.account_id ? `${a.label} (${a.account_id})` : a.account_id}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            </div>
          )}

          {selectedAccount && (
            <p className="text-xs text-slate-500 mt-1.5 font-mono">{selectedAccount.account_id}</p>
          )}
        </div>

        {/* ── Region ───────────────────────────────────────────────────── */}
        <div>
          <label className="block text-xs font-medium text-slate-400 uppercase tracking-wide mb-2">
            AWS Region <span className="text-red-400">*</span>
          </label>
          <div className="relative">
            <select
              value={form.region}
              onChange={(e) => setForm({ ...form, region: e.target.value })}
              className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 text-sm appearance-none transition-all"
            >
              {AWS_REGIONS.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
            <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
          </div>
        </div>

        {/* ── Cluster selector ─────────────────────────────────────────── */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">
              EKS Cluster <span className="text-red-400">*</span>
            </label>
            {form.account_id && !loadingClusters && clusters.length > 0 && (
              <span className="text-xs text-slate-500">
                {activeCount} active / {clusters.length} total
              </span>
            )}
          </div>

          {!form.account_id ? (
            <div className="px-4 py-3 bg-slate-800/40 border border-slate-700/60 rounded-lg text-slate-600 text-sm">
              Select an account first
            </div>
          ) : loadingClusters ? (
            <div className="flex items-center gap-2 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-500 text-sm">
              <LoadingSpinner size="sm" /> Discovering clusters in {form.region}…
            </div>
          ) : clusters.length === 0 ? (
            <div className="px-4 py-3 bg-slate-800/60 border border-slate-700 rounded-lg text-slate-500 text-sm">
              No clusters found in <span className="font-mono text-slate-400">{form.region}</span>.
              Try a different region.
            </div>
          ) : (
            <div className="relative">
              <select
                value={form.cluster_name}
                onChange={(e) => setForm({ ...form, cluster_name: e.target.value })}
                required
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 text-sm appearance-none transition-all"
              >
                <option value="">— Select cluster —</option>
                {clusters.map((c) => (
                  <option key={`${c.region}/${c.name}`} value={c.name} disabled={c.status !== 'ACTIVE'}>
                    {c.name}{c.status !== 'ACTIVE' ? ` (${c.status})` : ''}{c.version ? ` · k8s ${c.version}` : ''}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            </div>
          )}
        </div>

        {/* ── Namespace ────────────────────────────────────────────────── */}
        <div>
          <label className="block text-xs font-medium text-slate-400 uppercase tracking-wide mb-2">
            Namespace Scope
          </label>
          <input
            type="text"
            value={form.namespace}
            onChange={(e) => setForm({ ...form, namespace: e.target.value })}
            placeholder="all"
            className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 text-sm transition-all"
          />
          <p className="text-xs text-slate-500 mt-1.5">
            Use <code className="text-slate-400">all</code> to diagnose all namespaces (recommended).
          </p>
        </div>

        {/* ── Error ────────────────────────────────────────────────────── */}
        {error && (
          <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3">
            <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-sm text-red-300">{error}</p>
          </div>
        )}

        {/* ── Checklist ────────────────────────────────────────────────── */}
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-3">
            Diagnostic Checks Included
          </p>
          <div className="grid grid-cols-2 gap-y-1.5 gap-x-4">
            {[
              'Cluster context', 'Node health', 'Pod health (all namespaces)',
              'Deployments / DaemonSets', 'Services + Endpoints', 'Ingress + ALB targets',
              'AWS Load Balancer Controller', 'VPC / Subnet IPs', 'CoreDNS health',
              'PVC / EBS CSI', 'HPA / PDB', 'EKS nodegroups + add-ons',
              'IAM / IRSA / OIDC', 'Kubernetes events', 'Auto Scaling Groups',
            ].map((c) => (
              <div key={c} className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="text-green-500">✓</span> {c}
              </div>
            ))}
          </div>
        </div>

        {/* ── Submit ───────────────────────────────────────────────────── */}
        <button
          type="submit"
          disabled={loading || !form.account_id || !form.cluster_name}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-600/50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-all"
        >
          {loading ? (
            <>
              <LoadingSpinner size="sm" />
              Starting diagnosis…
            </>
          ) : (
            <>
              <Search size={15} />
              Start Diagnosis
            </>
          )}
        </button>
      </form>
    </div>
  )
}

