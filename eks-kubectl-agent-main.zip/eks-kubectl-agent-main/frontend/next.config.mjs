const nextConfig = {
    output: 'export', // Static export for S3 + CloudFront
    trailingSlash: true, // Required for S3 static hosting
    images: { unoptimized: true }, // No image optimization in static mode
    eslint: { ignoreDuringBuilds: true },
};

export default nextConfig;