"""
EKS Troubleshooting Agent — CLI entry point.

Commands:
    diagnose  Run full read-only diagnosis and generate an incident report.
    report    Re-render the report from a previously saved JSON state (future).
    fix       Display and optionally apply a single confirmed fix.
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Confirm
from rich.table import Table

from agent.analyzers import run_all_analyzers
from agent.diagnostics import EksDiagnosticAgent
from agent.executor import CommandExecutor, ToolNotFoundError
from agent.fixes import generate_fixes, get_fix_by_id
from agent.models import FixRisk
from agent.reporter import generate_report, save_report
from agent.safety import classify_command, CommandClass, describe_classification

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="eks-agent",
    help="Safe AI-assisted EKS troubleshooting agent.",
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()

logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _check_prerequisites() -> None:
    """Verify that kubectl and aws CLI are available before proceeding."""
    executor = CommandExecutor()
    missing: list[str] = []
    for tool in ("kubectl", "aws"):
        if not executor.check_tool(tool):
            missing.append(tool)

    if missing:
        console.print(
            Panel(
                f"[bold red]Missing required tools: {', '.join(missing)}[/]\n\n"
                "Please install and ensure the following are on your PATH:\n"
                "  • kubectl — https://kubernetes.io/docs/tasks/tools/\n"
                "  • aws CLI — https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html",
                title="[red]Prerequisite Check Failed[/]",
                border_style="red",
            )
        )
        raise typer.Exit(code=1)


def _print_fix_detail(fix, console: Console) -> None:
    """Render a single fix as a rich table."""
    cmd_str = " ".join(fix.command)
    rollback_str = " ".join(fix.rollback_command) if fix.rollback_command else "N/A"

    risk_color = {"High": "red", "Medium": "yellow", "Low": "green"}.get(fix.risk.value, "white")

    table = Table(title=f"Fix: {fix.fix_id}", show_header=True, header_style="bold cyan")
    table.add_column("Field", style="bold", width=22)
    table.add_column("Details")

    table.add_row("Fix ID", f"[bold]{fix.fix_id}[/]")
    table.add_row("Description", fix.description)
    table.add_row("Risk Level", f"[{risk_color}]{fix.risk.value}[/]")
    table.add_row("Namespace", fix.namespace or "N/A")
    table.add_row("Resource", fix.resource or "N/A")
    table.add_row("Expected Result", fix.expected_result)
    table.add_row("Command", f"[bold yellow]{cmd_str}[/]")
    table.add_row("Rollback Command", rollback_str)
    table.add_row("Rollback Plan", fix.rollback_description)
    table.add_row("Confirmation Required", "[red]Yes ⚠️[/]" if fix.requires_confirmation else "[green]No[/]")

    console.print(table)


# ---------------------------------------------------------------------------
# diagnose command
# ---------------------------------------------------------------------------

@app.command()
def diagnose(
    cluster_name: str = typer.Option(..., "--cluster-name", "-c", help="EKS cluster name"),
    region: str = typer.Option(..., "--region", "-r", help="AWS region, e.g. us-east-1"),
    namespace: str = typer.Option(
        "all", "--namespace", "-n",
        help="Namespace to scope (default: all)"
    ),
    output: Path = typer.Option(
        Path("eks-incident-report.md"),
        "--output", "-o",
        help="Output path for the Markdown incident report",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Print commands without executing them",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="Enable debug logging",
    ),
    skip_prereq_check: bool = typer.Option(
        False, "--skip-prereq-check",
        help="Skip prerequisite tool availability check",
    ),
) -> None:
    """
    Run a full read-only EKS diagnostic and generate an incident report.

    All commands executed are read-only. No cluster state is modified.

    Example:

        python main.py diagnose --cluster-name my-cluster --region us-east-2
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    console.print(
        Panel(
            "[bold green]EKS Troubleshooting Agent[/]\n"
            "[dim]Read-only diagnostic mode — no changes will be made[/]",
            border_style="green",
        )
    )

    if not skip_prereq_check:
        _check_prerequisites()

    # Run diagnosis
    agent = EksDiagnosticAgent(
        cluster_name=cluster_name,
        region=region,
        namespace=namespace,
        dry_run=dry_run,
        timeout=60,
    )
    report = agent.run_full_diagnosis()

    # Analyze
    console.print("\n[bold cyan]Analyzing collected data...[/]")
    findings = run_all_analyzers(report)

    # Generate fixes
    fixes = generate_fixes(findings)
    report.fixes = fixes

    # Print findings summary
    if findings:
        console.print()
        table = Table(title="Findings Summary", show_header=True, header_style="bold")
        table.add_column("Severity", width=10)
        table.add_column("Component", width=28)
        table.add_column("Resource", width=28)
        table.add_column("Namespace", width=20)
        table.add_column("Fix ID", width=10)

        sev_colors = {
            "Critical": "bold red",
            "High": "orange3",
            "Medium": "yellow",
            "Low": "green",
            "Info": "dim",
        }
        for f in sorted(findings, key=lambda x: list(x.severity.__class__).index(x.severity)):
            color = sev_colors.get(f.severity.value, "white")
            table.add_row(
                f"[{color}]{f.severity.value}[/]",
                f.component,
                f.resource[:26],
                f.namespace[:18],
                f.fix_id or "",
            )
        console.print(table)
    else:
        console.print("[green]✅ No issues detected in automated analysis.[/]")

    # Save fixes cache for the fix command to load without re-running diagnosis
    fixes_cache = [
        {
            "fix_id": f.fix_id,
            "description": f.description,
            "command": f.command,
            "risk": f.risk.value,
            "expected_result": f.expected_result,
            "rollback_command": f.rollback_command,
            "rollback_description": f.rollback_description,
            "requires_confirmation": f.requires_confirmation,
            "namespace": f.namespace,
            "resource": f.resource,
        }
        for f in fixes
    ]
    Path("eks-fixes-cache.json").write_text(
        json.dumps(fixes_cache, indent=2), encoding="utf-8"
    )

    # Generate and save report
    report_text = generate_report(report, fixes)
    saved_path = save_report(report_text, output)

    console.print(f"\n[bold green]✅ Incident report saved to: [underline]{saved_path}[/][/]")

    # Print available fixes
    if fixes:
        console.print()
        fix_table = Table(title="Available Fixes (require confirmation)", show_header=True, header_style="bold yellow")
        fix_table.add_column("Fix ID", width=12)
        fix_table.add_column("Risk", width=8)
        fix_table.add_column("Description")
        for fix in fixes:
            risk_color = {"High": "red", "Medium": "yellow", "Low": "green"}.get(fix.risk.value, "white")
            fix_table.add_row(
                f"[bold]{fix.fix_id}[/]",
                f"[{risk_color}]{fix.risk.value}[/]",
                fix.description[:80],
            )
        console.print(fix_table)
        console.print(
            "\n[dim]To apply a fix:[/] [bold]python main.py fix --fix-id FIX-001[/]"
        )

    raise typer.Exit(code=0)


# ---------------------------------------------------------------------------
# fix command
# ---------------------------------------------------------------------------

@app.command()
def fix(
    fix_id: str = typer.Option(..., "--fix-id", help="Fix ID from the incident report, e.g. FIX-001"),
    report_path: Path = typer.Option(
        Path("eks-incident-report.md"),
        "--report",
        help="Path to the incident report (used for context display)",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Show what would run without executing",
    ),
) -> None:
    """
    Review and optionally apply a fix from the incident report.

    The agent will show the exact command, risk level, rollback plan,
    and ask for explicit confirmation before running anything.

    Example:

        python main.py fix --fix-id FIX-001-EXEC
    """
    console.print(
        Panel(
            f"[bold yellow]Fix Application — {fix_id}[/]\n"
            "[dim]You will be shown full details and asked to confirm before anything runs.[/]",
            border_style="yellow",
        )
    )

    # We need a live report to retrieve fix objects.  Re-run diagnosis is
    # expensive, so we load the fixes from a sidecar JSON file if present.
    fixes_cache_path = Path("eks-fixes-cache.json")

    fix_obj = None
    if fixes_cache_path.exists():
        try:
            raw = json.loads(fixes_cache_path.read_text(encoding="utf-8"))
            from agent.models import FixRecommendation, FixRisk
            loaded_fixes = []
            for item in raw:
                loaded_fixes.append(
                    FixRecommendation(
                        fix_id=item["fix_id"],
                        description=item["description"],
                        command=item["command"],
                        risk=FixRisk(item["risk"]),
                        expected_result=item["expected_result"],
                        rollback_command=item.get("rollback_command"),
                        rollback_description=item["rollback_description"],
                        requires_confirmation=item.get("requires_confirmation", True),
                        namespace=item.get("namespace"),
                        resource=item.get("resource"),
                    )
                )
            fix_obj = get_fix_by_id(loaded_fixes, fix_id)
        except Exception as exc:  # noqa: BLE001
            console.print(f"[yellow]Warning: could not load fixes cache: {exc}[/]")

    if fix_obj is None:
        console.print(
            f"[red]Fix '{fix_id}' not found.[/]\n"
            "Run [bold]python main.py diagnose[/] first to generate fixes, "
            "or verify the fix ID from the incident report."
        )
        raise typer.Exit(code=1)

    # Show full details
    _print_fix_detail(fix_obj, console)

    # Safety double-check
    cls = classify_command(fix_obj.command)
    if cls == CommandClass.READ_ONLY:
        console.print("[green]ℹ This command is read-only and safe to run.[/]")
    else:
        console.print(
            Panel(
                f"[bold red]⚠️  This is a MUTATING command.[/]\n"
                f"Classification: {describe_classification(fix_obj.command)}\n\n"
                f"Command: [bold yellow]{' '.join(fix_obj.command)}[/]\n\n"
                f"Rollback: [dim]{' '.join(fix_obj.rollback_command) if fix_obj.rollback_command else 'N/A'}[/]",
                title="[red]Confirmation Required[/]",
                border_style="red",
            )
        )

    if dry_run:
        console.print("[dim][DRY-RUN] Would execute:[/] " + " ".join(fix_obj.command))
        console.print("[dim]Dry-run mode — no changes made.[/]")
        raise typer.Exit(code=0)

    # Explicit confirmation
    approved = Confirm.ask(
        "\n[bold red]Do you approve running this fix?[/] (yes = execute, no = abort)",
        default=False,
    )

    if not approved:
        console.print("[yellow]Fix aborted. No changes were made.[/]")
        raise typer.Exit(code=0)

    # Execute
    console.print(f"\n[bold green]Executing fix {fix_id}...[/]")
    executor = CommandExecutor(dry_run=False)
    result = executor.run(fix_obj.command, timeout=120)

    if result.success:
        console.print(
            Panel(
                f"[bold green]✅ Fix applied successfully.[/]\n\n"
                f"[dim]{result.stdout[:500]}[/]",
                title=f"[green]{fix_id} — Success[/]",
                border_style="green",
            )
        )
        console.print("\n[bold]Post-fix validation:[/]")
        console.print(
            "Run the following to verify the fix:\n"
            "```\n"
            "kubectl get pods -A\n"
            "kubectl get events -A --sort-by=.lastTimestamp\n"
            "```"
        )
    else:
        console.print(
            Panel(
                f"[bold red]❌ Fix command failed (exit {result.returncode})[/]\n\n"
                f"[red]{result.stderr[:500]}[/]",
                title=f"[red]{fix_id} — Failed[/]",
                border_style="red",
            )
        )
        if fix_obj.rollback_command:
            console.print(
                f"\n[yellow]Consider running rollback:[/] "
                f"[bold]{' '.join(fix_obj.rollback_command)}[/]"
            )
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# report command (render saved report)
# ---------------------------------------------------------------------------

@app.command()
def report(
    report_path: Path = typer.Option(
        Path("eks-incident-report.md"),
        "--report", "-r",
        help="Path to the Markdown incident report",
    ),
) -> None:
    """
    Render a previously saved incident report in the terminal.

    Example:

        python main.py report --report eks-incident-report.md
    """
    if not report_path.exists():
        console.print(f"[red]Report not found: {report_path}[/]")
        console.print("Run [bold]python main.py diagnose[/] first.")
        raise typer.Exit(code=1)

    text = report_path.read_text(encoding="utf-8")
    console.print(Markdown(text))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()
