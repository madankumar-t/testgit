# Cross Account Role Deployment (Single Spacelift Stack)

## Role Name
crossaccountrolewithsharedsvcs2

## What This Does
- Creates identical IAM roles in multiple AWS accounts
- Trusts Sharedsvcs2 account to assume the role
- Attaches custom policy
- Designed for single Spacelift stack multi-account deployment

## Usage
1. Update terraform.tfvars with real account IDs
2. Ensure SpaceliftExecutionRole exists in target accounts
3. Attach AWS integration in Spacelift (Sharedsvcs2 account)
4. Run Terraform
