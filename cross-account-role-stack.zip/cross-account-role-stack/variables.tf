variable "region" {
  default = "us-east-1"
}

variable "sharedsvcs2_account_id" {
  description = "Account ID of Sharedsvcs2"
  type        = string
}

variable "target_accounts" {
  description = "Map of target accounts"
  type = map(object({
    account_id          = string
    spacelift_role_name = string
  }))
}
