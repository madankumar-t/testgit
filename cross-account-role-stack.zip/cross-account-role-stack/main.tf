module "cross_account_roles" {
  for_each = var.target_accounts

  source = "./modules/cross-account-role"

  providers = {
    aws = aws[each.key]
  }

  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}
