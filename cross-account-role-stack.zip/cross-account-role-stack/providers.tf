provider "aws" {
  region = var.region
}

provider "aws" {
  for_each = var.target_accounts
  alias    = each.key
  region   = var.region

  assume_role {
    role_arn = "arn:aws:iam::${each.value.account_id}:role/${each.value.spacelift_role_name}"
  }
}
