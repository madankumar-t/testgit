# Terraform AWS Timestream Module

Reusable Terraform module for Amazon Timestream databases and tables.

## Usage

```hcl
module "timestream" {
  source      = "../../"
  name        = "metrics"
  environment = "dev"
  table_name  = "app-metrics"
}
```