def build_topology(d): n=[];e=[]
for r,sv in d.items():
  if 'vpc' in sv:
    for v in sv['vpc']['vpcs']: n.append({'id':v['VpcId'],'type':'vpc'})
    for s in sv['vpc']['subnets']: n.append({'id':s['SubnetId'],'type':'subnet'}); e.append({'from':s['VpcId'],'to':s['SubnetId']})
return {'nodes':n,'edges':e}