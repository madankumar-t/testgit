from app.aws.regions import list_regions
from app.aws.session import get_session
from app.collectors import ec2,s3,iam,rds,eks
from app.collectors.vpc import collect_vpc
MAP={'ec2':ec2.collect,'s3':s3.collect,'iam':iam.collect,'rds':rds.collect,'eks':eks.collect,'vpc':collect_vpc}
def route_request(i): return {r:{s:MAP[s](get_session(r)) for s in i['services']} for r in list_regions()}