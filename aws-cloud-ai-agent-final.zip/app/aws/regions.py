import boto3
def list_regions(): return [r['RegionName'] for r in boto3.client('ec2').describe_regions()['Regions']]