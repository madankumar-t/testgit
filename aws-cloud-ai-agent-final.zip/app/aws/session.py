import boto3
def get_session(r): return boto3.Session(region_name=r)