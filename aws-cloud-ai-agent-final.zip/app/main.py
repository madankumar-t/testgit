from fastapi import FastAPI
from app.agent.agent import run_agent
app=FastAPI()
@app.post('/query')
def query(prompt:str): return run_agent(prompt)