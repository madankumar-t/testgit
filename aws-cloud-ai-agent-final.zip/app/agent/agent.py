from app.agent.intent import extract_intent
from app.aws.router import route_request
from app.agent.summarizer import summarize
from app.analysis.topology import build_topology
def run_agent(p): d=route_request(extract_intent(p)); return {'summary':summarize(d),'topology':build_topology(d)}