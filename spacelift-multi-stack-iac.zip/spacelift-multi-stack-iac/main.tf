resource "spacelift_stack" "cross_account_role" {
  for_each = var.accounts

  name       = "cross-account-role-${each.key}"
  repository = var.repository
  branch     = var.branch

  project_root = "/"

  terraform_workflow_tool = "TERRAFORM_FOSS"

  description = "Cross account IAM role deployment for ${each.key}"

  labels = [
    "cross-account",
    each.key
  ]
}

resource "spacelift_aws_integration_attachment" "attach" {
  for_each = var.accounts

  stack_id       = spacelift_stack.cross_account_role[each.key].id
  integration_id = each.value.aws_integration_id

  read  = true
  write = true
}
