# Spacelift Multi-Stack IaC (Terraform)

This project creates multiple Spacelift stacks using Terraform.

## What It Does

- Creates one Spacelift stack per AWS account
- Attaches AWS integrations automatically
- Fully Infrastructure-as-Code managed

## Structure

- versions.tf
- provider.tf
- variables.tf
- main.tf
- terraform.tfvars.example

## Usage

1. Generate API key in Spacelift (Settings → API Keys)
2. Copy terraform.tfvars.example to terraform.tfvars
3. Fill in:
   - API credentials
   - GitHub repository
   - AWS integration IDs
4. Run:

   terraform init
   terraform plan
   terraform apply

## Output

Creates stacks:
- cross-account-role-sandbox1
- cross-account-role-sandbox2
- cross-account-role-security

Each attached to its AWS integration.
