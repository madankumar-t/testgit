variable "spacelift_api_key_id" {
  description = "Spacelift API Key ID"
  type        = string
  sensitive   = true
}

variable "spacelift_api_key_secret" {
  description = "Spacelift API Key Secret"
  type        = string
  sensitive   = true
}

variable "repository" {
  description = "GitHub repository in org/repo format"
  type        = string
}

variable "branch" {
  description = "Git branch"
  type        = string
  default     = "main"
}

variable "accounts" {
  description = "Map of AWS accounts and integrations"
  type = map(object({
    aws_integration_id = string
  }))
}
