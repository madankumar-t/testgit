
variable "role_name" {
  description = "IAM Role name"
  type        = string
  default     = "crossaccountrolewithsharedsvcs2"
}

variable "trusted_principals" {
  description = "List of AWS principals allowed to assume the role"
  type        = list(string)
}
