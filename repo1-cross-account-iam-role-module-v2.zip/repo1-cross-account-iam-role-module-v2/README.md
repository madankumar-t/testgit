
# Cross Account IAM Role Module

This repository publishes a module to Spacelift Private Registry.

## Published Module
spacelift.io/<your-org>/cross-account-iam-role

## Versioning
Bump module_version in spacelift/config.yaml for every change.
