import boto3
import json
import os

cf = boto3.client("cloudfront")
elbv2 = boto3.client("elasticloadbalancingv2")
sns = boto3.client("sns")

SNS_TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]

def lambda_handler(event, context):
    print("Received event:")
    print(json.dumps(event))

    alb_arn = event["detail"]["responseElements"]["loadBalancer"]["loadBalancerArn"]

    alb_info = elbv2.describe_load_balancers(LoadBalancerArns=[alb_arn])
    alb_dns = alb_info["LoadBalancers"][0]["DNSName"]

    print(f"Checking CloudFront for ALB: {alb_dns}")

    attached = False
    distributions = cf.list_distributions()

    if "DistributionList" in distributions and "Items" in distributions["DistributionList"]:
        for dist in distributions["DistributionList"]["Items"]:
            origins = dist["Origins"]["Items"]
            for origin in origins:
                if alb_dns in origin.get("DomainName", ""):
                    print("ALB is attached to CloudFront")
                    attached = True
                    break

    if not attached:
        message = f"ALB ({alb_dns}) is NOT attached to any CloudFront distribution."
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject="ALB Missing CloudFront Association",
            Message=message
        )

    return {"attached": attached}
