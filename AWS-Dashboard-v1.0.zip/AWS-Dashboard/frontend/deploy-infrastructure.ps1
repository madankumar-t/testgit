# Frontend Infrastructure Deployment Script
# This script deploys the S3 + CloudFront infrastructure using CloudFormation

param(
    [string]$StackName = "aws-inventory-dashboard-frontend",
    [string]$BucketName = "nxt-inventory-dashboard",
    [string]$CustomDomain = "",
    [string]$CertificateArn = "",
    [switch]$Update
)

Write-Host "🚀 Deploying Frontend Infrastructure..." -ForegroundColor Cyan
Write-Host ""

# Build parameters
$parameters = @(
    "ParameterKey=S3BucketName,ParameterValue=$BucketName"
)

if ($CustomDomain) {
    $parameters += "ParameterKey=CustomDomainName,ParameterValue=$CustomDomain"
}

if ($CertificateArn) {
    $parameters += "ParameterKey=ACMCertificateArn,ParameterValue=$CertificateArn"
}

# Deploy CloudFormation stack
Write-Host "📦 Deploying CloudFormation stack: $StackName" -ForegroundColor Yellow

if ($Update) {
    Write-Host "Updating existing stack..." -ForegroundColor Yellow
    aws cloudformation update-stack `
        --stack-name $StackName `
        --template-body file://frontend-infrastructure.yaml `
        --parameters $parameters `
        --capabilities CAPABILITY_IAM `
        --region us-east-1
}
else {
    Write-Host "Creating new stack..." -ForegroundColor Yellow
    aws cloudformation create-stack `
        --stack-name $StackName `
        --template-body file://frontend-infrastructure.yaml `
        --parameters $parameters `
        --capabilities CAPABILITY_IAM `
        --region us-east-1
}

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Stack deployment failed" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "⏳ Waiting for stack to complete..." -ForegroundColor Yellow
aws cloudformation wait stack-create-complete --stack-name $StackName --region us-east-1 2>$null
if ($LASTEXITCODE -ne 0) {
    aws cloudformation wait stack-update-complete --stack-name $StackName --region us-east-1
}

Write-Host ""
Write-Host "✅ Frontend infrastructure deployed successfully!" -ForegroundColor Green
Write-Host ""

# Get outputs
Write-Host "📊 Stack Outputs:" -ForegroundColor Cyan
aws cloudformation describe-stacks `
    --stack-name $StackName `
    --region us-east-1 `
    --query "Stacks[0].Outputs" `
    --output table

Write-Host ""
Write-Host "🎉 Next steps:" -ForegroundColor Cyan
Write-Host "1. Build and deploy frontend:"
Write-Host "   npm run build:static" -ForegroundColor Yellow
Write-Host "   aws s3 sync out/ s3://$BucketName --delete" -ForegroundColor Yellow
Write-Host ""
Write-Host "2. Get CloudFront Distribution ID:"
Write-Host "   aws cloudformation describe-stacks --stack-name $StackName --query 'Stacks[0].Outputs[?OutputKey==``CloudFrontDistributionId``].OutputValue' --output text" -ForegroundColor Yellow
Write-Host ""
Write-Host "3. Invalidate CloudFront cache:"
Write-Host "   aws cloudfront create-invalidation --distribution-id YOUR_DIST_ID --paths '/*'" -ForegroundColor Yellow
