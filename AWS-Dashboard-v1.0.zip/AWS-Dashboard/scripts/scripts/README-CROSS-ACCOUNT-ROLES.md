# Cross-Account Role Setup Guide

This guide explains how to set up cross-account IAM roles that allow the Ops account Lambda `RefreshFunction` to collect inventory data from child accounts and update DynamoDB.

## Overview

The AWS Inventory Dashboard uses a Lambda function (`RefreshFunction`) in the Ops account that:
1. Assumes IAM roles in child accounts
2. Collects inventory data (EC2, S3, RDS, etc.)
3. Stores the data in DynamoDB tables in the Ops account

## Architecture

```
┌─────────────────────────────────┐
│        Ops Account               │
│                                  │
│  ┌──────────────────────────┐  │
│  │   RefreshFunction         │  │
│  │   (Lambda)                │  │
│  │                           │  │
│  │   Execution Role:        │  │
│  │   RefreshFunctionRole-XXX │  │
│  └───────────┬──────────────┘  │
│              │                  │
│              │ assumes role     │
│              ▼                  │
│  ┌──────────────────────────┐  │
│  │   DynamoDB Tables         │  │
│  │   - InventoryTable        │  │
│  │   - MetadataTable         │  │
│  └──────────────────────────┘  │
└─────────────────────────────────┘
              │
              │
    ┌─────────┴─────────┐
    │                   │
    ▼                   ▼
┌─────────┐        ┌─────────┐
│ Child   │        │ Child   │
│ Account │        │ Account │
│   1     │        │   2     │
│         │        │         │
│ Inventory│        │ Inventory│
│ ReadRole │        │ ReadRole │
└─────────┘        └─────────┘
```

## Quick Start

### Option 1: Using Property File (Recommended)

1. **Copy the example property file:**
   ```bash
   cp scripts/cross-account-config.example.properties scripts/cross-account-config.properties
   ```

2. **Edit the property file** with your values:
   ```properties
   OPS_ACCOUNT_ID=123456789012
   EXTERNAL_ID=my-secure-external-id
   CHILD_ACCOUNTS=987654321098,111222333444
   ```

3. **Run the script:**
   ```bash
   # Bash
   cd scripts
   ./setup-ops-to-child-roles.sh
   
   # PowerShell
   cd scripts
   .\setup-ops-to-child-roles.ps1
   ```

See [README-PROPERTY-FILE.md](README-PROPERTY-FILE.md) for detailed property file documentation.

### Option 2: Setup for Specific Accounts (Command Line)

**Bash (Linux/Mac):**
```bash
cd scripts
./setup-ops-to-child-roles.sh \
  --child-accounts 123456789012,987654321098 \
  --external-id my-secure-external-id
```

**PowerShell (Windows):**
```powershell
cd scripts
.\setup-ops-to-child-roles.ps1 `
  -ChildAccounts "123456789012,987654321098" `
  -ExternalId "my-secure-external-id"
```

### Option 3: Setup from File

Create `accounts.txt`:
```
123456789012
987654321098
111222333444
```

**Bash:**
```bash
./setup-ops-to-child-roles.sh \
  --child-accounts-file accounts.txt \
  --external-id my-secure-external-id
```

**PowerShell:**
```powershell
.\setup-ops-to-child-roles.ps1 `
  -ChildAccountsFile "accounts.txt" `
  -ExternalId "my-secure-external-id"
```

## Script Options

| Option | Description | Default |
|--------|-------------|---------|
| `--ops-account-id` / `-OpsAccountId` | Ops account ID | Auto-detect |
| `--child-accounts` / `-ChildAccounts` | Comma-separated account IDs | Required |
| `--child-accounts-file` / `-ChildAccountsFile` | File with account IDs (one per line) | - |
| `--role-name` / `-RoleName` | Role name in child accounts | `InventoryReadRole` |
| `--external-id` / `-ExternalId` | External ID for security | (optional) |
| `--lambda-function-name` / `-LambdaFunctionName` | Lambda function name | `RefreshFunction` |
| `--dry-run` / `-DryRun` | Show what would be done | false |

## What the Script Does

1. **Detects Ops Account ID** (if not provided)
2. **Finds Lambda Execution Role** by:
   - Checking Lambda function configuration
   - Searching IAM roles containing "RefreshFunction"
   - Falls back to account root (less secure)
3. **For each child account:**
   - Creates `InventoryReadRole` (or updates if exists)
   - Sets up trust policy allowing Lambda role to assume it
   - Attaches read-only permissions policy
   - Verifies the setup

## Trust Policy

The trust policy allows the Lambda execution role from the Ops account to assume the role in child accounts.

**With External ID (Recommended):**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::OPS_ACCOUNT:role/RefreshFunctionRole-XXX"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "your-external-id"
        }
      }
    }
  ]
}
```

**Without External ID:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::OPS_ACCOUNT:role/RefreshFunctionRole-XXX"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

## Permissions Policy

The `InventoryReadRole` has read-only permissions for:
- **EC2**: Instances, VPCs, security groups, subnets, etc.
- **S3**: Buckets, properties, tags
- **RDS**: Instances, clusters, snapshots
- **DynamoDB**: Tables (read-only, not write)
- **IAM**: Roles (read-only)
- **EKS**: Clusters, node groups
- **ECS**: Clusters, services, tasks
- **Lambda**: Functions (read-only)
- **STS**: GetCallerIdentity

**Note:** The role in child accounts has **read-only** permissions. The Lambda function writes to DynamoDB in the **Ops account** using its own execution role permissions.

## External ID (Recommended)

External ID adds security by requiring a shared secret when assuming the role. This prevents the "confused deputy" problem.

### To Use External ID:

1. **Generate a secure External ID:**
   ```bash
   # Generate UUID
   uuidgen
   # Or use a meaningful value
   echo "inventory-dashboard-$(date +%s)"
   ```

2. **Run script with External ID:**
   ```bash
   ./setup-ops-to-child-roles.sh \
     --child-accounts 123456789012 \
     --external-id "your-secure-external-id"
   ```

3. **Update Lambda environment variable:**
   - AWS Console → Lambda → RefreshFunction → Configuration → Environment variables
   - Add/Update: `EXTERNAL_ID` = `your-secure-external-id`
   - Or update in `template.yaml` and redeploy

## Verification

### Test Role Assumption

From the Ops account, test assuming the role:

```bash
# Without External ID
aws sts assume-role \
  --role-arn arn:aws:iam::CHILD_ACCOUNT_ID:role/InventoryReadRole \
  --role-session-name test-session

# With External ID
aws sts assume-role \
  --role-arn arn:aws:iam::CHILD_ACCOUNT_ID:role/InventoryReadRole \
  --role-session-name test-session \
  --external-id your-external-id
```

### Check Lambda Logs

After setup, trigger a refresh and check CloudWatch logs:

```bash
# View logs
aws logs tail /aws/lambda/inventory-dashboard-RefreshFunction --follow

# Or in AWS Console
# CloudWatch → Log groups → /aws/lambda/inventory-dashboard-RefreshFunction
```

Look for:
- ✅ `Successfully assumed role arn:aws:iam::CHILD_ACCOUNT:role/InventoryReadRole`
- ✅ `Collected X resources for account CHILD_ACCOUNT`
- ❌ `AccessDenied` errors (check trust policy)

### Test Data Collection

Trigger a manual refresh:

```bash
# Via API (if you have the endpoint)
curl -X POST https://YOUR_API/inventory/refresh \
  -H "Authorization: Bearer YOUR_TOKEN"

# Or invoke Lambda directly
aws lambda invoke \
  --function-name inventory-dashboard-RefreshFunction \
  --payload '{"service": "ec2"}' \
  response.json
```

## Troubleshooting

### Error: "User is not authorized to perform: sts:AssumeRole"

**Cause:** Trust policy doesn't match Lambda execution role.

**Solution:**
1. Get the exact Lambda role ARN:
   ```bash
   aws lambda get-function-configuration \
     --function-name RefreshFunction \
     --query 'Role' --output text
   ```

2. Update trust policy in child account manually or re-run the script

### Error: "AccessDenied when calling the AssumeRole operation"

**Possible causes:**
1. **External ID mismatch** - Check Lambda `EXTERNAL_ID` env var matches trust policy
2. **Wrong principal** - Verify Lambda role ARN in trust policy
3. **Role doesn't exist** - Run setup script again

**Check:**
```bash
# Verify External ID in Lambda
aws lambda get-function-configuration \
  --function-name RefreshFunction \
  --query 'Environment.Variables.EXTERNAL_ID' --output text

# Verify trust policy
aws iam get-role --role-name InventoryReadRole \
  --query 'Role.AssumeRolePolicyDocument'
```

### Script Can't Find Lambda Role

If auto-detection fails:

1. **Find role manually:**
   ```bash
   aws iam list-roles --query 'Roles[?contains(RoleName, `RefreshFunction`)].Arn' --output text
   ```

2. **The script will use account root** - This works but is less secure. Consider specifying the role manually.

### Role Already Exists

The script will **update** the existing role's trust policy. This is expected and safe.

## Lambda Environment Variables

After setup, ensure these Lambda environment variables are set:

- `INVENTORY_ROLE_NAME`: `InventoryReadRole` (or your custom name)
- `EXTERNAL_ID`: Your external ID (if used)
- `INVENTORY_TABLE_NAME`: DynamoDB table name
- `METADATA_TABLE_NAME`: DynamoDB metadata table name

## Best Practices

1. ✅ **Use External ID** for production deployments
2. ✅ **Use least privilege** - The read-only policy is minimal
3. ✅ **Regular audits** - Review roles and permissions periodically
4. ✅ **Monitor CloudTrail** - Track role assumption events
5. ✅ **Use AWS Organizations** - For automatic account discovery
6. ✅ **Tag roles** - Add tags to identify inventory-related roles
7. ✅ **Test after setup** - Verify role assumption works

## Related Files

- `scripts/policies/inventory-read-policy.json` - Read-only permissions policy
- `backend/template.yaml` - Lambda function and role configuration
- `backend/src/refresh_handler.py` - Lambda function code
- `backend/src/utils/aws_client.py` - Role assumption logic

## Support

For issues:
1. Check CloudWatch logs for detailed error messages
2. Review IAM policies in both accounts
3. Verify trust relationships
4. Test role assumption manually
5. Check Lambda environment variables

