# PowerShell script to diagnose and fix trust policy issues
# Usage: .\fix-trust-policy-issue.ps1 -MemberAccountId <ID> -MainAccountId <ID> [-LambdaRoleName <NAME>] [-ExternalId <ID>]

param(
    [Parameter(Mandatory=$true)]
    [string]$MemberAccountId,
    
    [Parameter(Mandatory=$true)]
    [string]$MainAccountId,
    
    [Parameter(Mandatory=$false)]
    [string]$LambdaRoleName = "",
    
    [Parameter(Mandatory=$false)]
    [string]$ExternalId = "",
    
    [Parameter(Mandatory=$false)]
    [string]$RoleName = "InventoryReadRole"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Trust Policy Diagnostic & Fix" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Member Account ID: $MemberAccountId"
Write-Host "Main Account ID: $MainAccountId"
Write-Host "Role Name: $RoleName"
if (-not [string]::IsNullOrEmpty($LambdaRoleName)) {
    Write-Host "Lambda Role: $LambdaRoleName"
} else {
    Write-Host "Lambda Role: (will use account root)"
}
if (-not [string]::IsNullOrEmpty($ExternalId)) {
    Write-Host "External ID: *** (hidden)"
} else {
    Write-Host "External ID: (not using)"
}
Write-Host ""

# Step 1: Check if role exists
Write-Host "Step 1: Checking if role exists..." -ForegroundColor Yellow
try {
    $Role = Get-IAMRole -RoleName $RoleName -ErrorAction Stop
    Write-Host "✓ Role exists" -ForegroundColor Green
    $RoleExists = $true
} catch {
    Write-Host "✗ Role does not exist" -ForegroundColor Red
    Write-Host "  You need to create the role first."
    Write-Host "  Run: .\create-cross-account-role-complete.ps1 -MemberAccountId $MemberAccountId -MainAccountId $MainAccountId"
    exit 1
}

# Step 2: Get current trust policy
Write-Host "Step 2: Checking current trust policy..." -ForegroundColor Yellow
$CurrentTrustPolicy = (Get-IAMRole -RoleName $RoleName).AssumeRolePolicyDocument
Write-Host "Current trust policy:"
$CurrentTrustPolicy | ConvertTo-Json -Depth 10
Write-Host ""

# Step 3: Build expected principal
$ExpectedPrincipal = if (-not [string]::IsNullOrEmpty($LambdaRoleName)) {
    "arn:aws:iam::${MainAccountId}:role/${LambdaRoleName}"
} else {
    "arn:aws:iam::${MainAccountId}:root"
}

Write-Host "Step 3: Expected principal ARN" -ForegroundColor Yellow
Write-Host "Expected: $ExpectedPrincipal"
Write-Host ""

# Step 4: Check principal
$CurrentPrincipal = $CurrentTrustPolicy.Statement[0].Principal.AWS
if ($CurrentPrincipal -eq $ExpectedPrincipal -or $CurrentPrincipal -like "*${MainAccountId}:root*") {
    Write-Host "✓ Principal ARN is correct" -ForegroundColor Green
    $PrincipalOk = $true
} else {
    Write-Host "✗ Principal ARN mismatch" -ForegroundColor Red
    Write-Host "  Current: $CurrentPrincipal"
    Write-Host "  Expected: $ExpectedPrincipal"
    $PrincipalOk = $false
}

# Step 5: Check External ID
if (-not [string]::IsNullOrEmpty($ExternalId)) {
    $CurrentExternalId = $CurrentTrustPolicy.Statement[0].Condition.StringEquals."sts:ExternalId"
    if ($CurrentExternalId -eq $ExternalId) {
        Write-Host "✓ External ID matches" -ForegroundColor Green
        $ExternalIdOk = $true
    } elseif ([string]::IsNullOrEmpty($CurrentExternalId)) {
        Write-Host "⚠ External ID not set in trust policy (but you provided one)" -ForegroundColor Yellow
        $ExternalIdOk = $false
    } else {
        Write-Host "✗ External ID mismatch" -ForegroundColor Red
        Write-Host "  Current: $CurrentExternalId"
        Write-Host "  Expected: $ExternalId"
        $ExternalIdOk = $false
    }
} else {
    $HasExternalId = $CurrentTrustPolicy.Statement[0].Condition.StringEquals."sts:ExternalId"
    if (-not [string]::IsNullOrEmpty($HasExternalId)) {
        Write-Host "⚠ Trust policy requires External ID but you didn't provide one" -ForegroundColor Yellow
        Write-Host "  Current External ID in policy: $HasExternalId"
        $ExternalIdOk = $false
    } else {
        Write-Host "✓ No External ID required" -ForegroundColor Green
        $ExternalIdOk = $true
    }
}

Write-Host ""

# Step 6: Fix if needed
if (-not $PrincipalOk -or -not $ExternalIdOk) {
    Write-Host "Step 4: Fixing trust policy..." -ForegroundColor Yellow
    
    $TrustPolicy = @{
        Version = "2012-10-17"
        Statement = @(
            @{
                Effect = "Allow"
                Principal = @{
                    AWS = $ExpectedPrincipal
                }
                Action = "sts:AssumeRole"
            }
        )
    }
    
    if (-not [string]::IsNullOrEmpty($ExternalId)) {
        $TrustPolicy.Statement[0].Condition = @{
            StringEquals = @{
                "sts:ExternalId" = $ExternalId
            }
        }
    }
    
    $TrustPolicyJson = $TrustPolicy | ConvertTo-Json -Depth 10
    Write-Host "New trust policy:"
    Write-Host $TrustPolicyJson
    Write-Host ""
    
    $Confirm = Read-Host "Update trust policy? (y/n)"
    if ($Confirm -eq 'y' -or $Confirm -eq 'Y') {
        Update-IAMAssumeRolePolicy -RoleName $RoleName -PolicyDocument $TrustPolicyJson
        Write-Host "✓ Trust policy updated" -ForegroundColor Green
    } else {
        Write-Host "Skipped. Trust policy not updated."
    }
} else {
    Write-Host "✓ Trust policy is correct" -ForegroundColor Green
    Write-Host ""
    Write-Host "If you're still getting AccessDenied errors, check:"
    Write-Host "1. External ID matches in Lambda environment variable"
    Write-Host "2. Lambda execution role has sts:AssumeRole permission"
    Write-Host "3. No other IAM policies are blocking the assumption"
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Next Steps" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Verify Lambda has External ID set (if using):"
Write-Host "   Get-LMFunctionConfiguration -FunctionName inventory-dashboard-RefreshFunction | Select-Object -ExpandProperty Environment | Select-Object -ExpandProperty Variables"
Write-Host ""
Write-Host "2. Test role assumption:"
$TestCmd = "aws sts assume-role --role-arn arn:aws:iam::${MemberAccountId}:role/${RoleName} --role-session-name test-session"
if (-not [string]::IsNullOrEmpty($ExternalId)) {
    $TestCmd += " --external-id $ExternalId"
}
Write-Host "   $TestCmd"
Write-Host ""
Write-Host "3. Check CloudWatch logs after fix"
Write-Host ""

