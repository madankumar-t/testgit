# PowerShell script to generate trust policy JSON for cross-account role
# Usage: .\create-trust-policy.ps1 -MainAccountId <ACCOUNT_ID> [-LambdaRoleName <ROLE_NAME>] [-ExternalId <ID>] | Out-File trust-policy.json

param(
    [Parameter(Mandatory=$true)]
    [string]$MainAccountId,
    
    [Parameter(Mandatory=$false)]
    [string]$LambdaRoleName = "",
    
    [Parameter(Mandatory=$false)]
    [string]$ExternalId = ""
)

# Build principal ARN
if ([string]::IsNullOrEmpty($LambdaRoleName)) {
    $PrincipalArn = "arn:aws:iam::${MainAccountId}:root"
} else {
    $PrincipalArn = "arn:aws:iam::${MainAccountId}:role/${LambdaRoleName}"
}

# Generate trust policy
$trustPolicy = @{
    Version = "2012-10-17"
    Statement = @(
        @{
            Effect = "Allow"
            Principal = @{
                AWS = $PrincipalArn
            }
            Action = "sts:AssumeRole"
        }
    )
}

# Add External ID condition if provided
if (-not [string]::IsNullOrEmpty($ExternalId)) {
    $trustPolicy.Statement[0].Condition = @{
        StringEquals = @{
            "sts:ExternalId" = $ExternalId
        }
    }
}

# Output as JSON
$trustPolicy | ConvertTo-Json -Depth 10

