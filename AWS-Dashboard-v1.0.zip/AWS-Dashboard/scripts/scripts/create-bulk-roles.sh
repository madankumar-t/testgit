#!/bin/bash

# Script to create cross-account roles in multiple member accounts
# Usage: ./create-bulk-roles.sh <MAIN_ACCOUNT_ID> <ACCOUNTS_FILE> [LAMBDA_ROLE_NAME] [EXTERNAL_ID]

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

MAIN_ACCOUNT_ID="${1}"
ACCOUNTS_FILE="${2}"
LAMBDA_ROLE_NAME="${3}"
EXTERNAL_ID="${4}"

if [ -z "$MAIN_ACCOUNT_ID" ] || [ -z "$ACCOUNTS_FILE" ]; then
    echo -e "${RED}Error: Main account ID and accounts file are required${NC}"
    echo "Usage: $0 <MAIN_ACCOUNT_ID> <ACCOUNTS_FILE> [LAMBDA_ROLE_NAME] [EXTERNAL_ID]"
    echo ""
    echo "Accounts file format (one per line):"
    echo "  ACCOUNT_ID:ACCOUNT_NAME"
    echo "  or"
    echo "  ACCOUNT_ID"
    exit 1
fi

if [ ! -f "$ACCOUNTS_FILE" ]; then
    echo -e "${RED}Error: Accounts file not found: $ACCOUNTS_FILE${NC}"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CREATE_SCRIPT="${SCRIPT_DIR}/create-cross-account-role-complete.sh"

if [ ! -f "$CREATE_SCRIPT" ]; then
    echo -e "${RED}Error: Create script not found: $CREATE_SCRIPT${NC}"
    exit 1
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Bulk Role Creation${NC}"
echo -e "${BLUE}========================================${NC}"
echo "Main Account ID: $MAIN_ACCOUNT_ID"
echo "Accounts File: $ACCOUNTS_FILE"
[ -n "$LAMBDA_ROLE_NAME" ] && echo "Lambda Role: $LAMBDA_ROLE_NAME" || echo "Lambda Role: (using account root)"
[ -n "$EXTERNAL_ID" ] && echo "External ID: *** (hidden)" || echo "External ID: (not using)"
echo ""

# Read accounts file
SUCCESS=0
FAILED=0
TOTAL=0

while IFS= read -r line || [ -n "$line" ]; do
    # Skip empty lines and comments
    [[ -z "$line" || "$line" =~ ^# ]] && continue
    
    TOTAL=$((TOTAL + 1))
    
    # Parse account ID (format: ACCOUNT_ID:ACCOUNT_NAME or just ACCOUNT_ID)
    if [[ "$line" == *:* ]]; then
        ACCOUNT_ID="${line%%:*}"
        ACCOUNT_NAME="${line#*:}"
    else
        ACCOUNT_ID="$line"
        ACCOUNT_NAME="Account $ACCOUNT_ID"
    fi
    
    echo -e "${YELLOW}[$TOTAL] Processing: $ACCOUNT_ID ($ACCOUNT_NAME)${NC}"
    
    # Switch to member account (assumes AWS_PROFILE or assume role)
    # For this script, we assume you're already authenticated to each account
    # or using AWS SSO/assume role
    
    if "$CREATE_SCRIPT" "$ACCOUNT_ID" "$MAIN_ACCOUNT_ID" "$LAMBDA_ROLE_NAME" "$EXTERNAL_ID" >/tmp/role-creation-$ACCOUNT_ID.log 2>&1; then
        echo -e "${GREEN}✓ Success: $ACCOUNT_ID${NC}"
        SUCCESS=$((SUCCESS + 1))
    else
        echo -e "${RED}✗ Failed: $ACCOUNT_ID${NC}"
        echo "  See log: /tmp/role-creation-$ACCOUNT_ID.log"
        FAILED=$((FAILED + 1))
    fi
    echo ""
done < "$ACCOUNTS_FILE"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Summary${NC}"
echo -e "${BLUE}========================================${NC}"
echo "Total: $TOTAL"
echo -e "${GREEN}Success: $SUCCESS${NC}"
echo -e "${RED}Failed: $FAILED${NC}"
echo ""

if [ $FAILED -gt 0 ]; then
    echo "Failed accounts logs:"
    ls -la /tmp/role-creation-*.log 2>/dev/null | grep -v "$(date +%Y)" || true
    exit 1
fi

