#!/bin/bash

# Script to diagnose and fix trust policy issues for cross-account roles
# Usage: ./fix-trust-policy-issue.sh <MEMBER_ACCOUNT_ID> <MAIN_ACCOUNT_ID> [LAMBDA_ROLE_NAME] [EXTERNAL_ID]

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

MEMBER_ACCOUNT_ID="${1}"
MAIN_ACCOUNT_ID="${2}"
LAMBDA_ROLE_NAME="${3}"
EXTERNAL_ID="${4}"
ROLE_NAME="${5:-InventoryReadRole}"

if [ -z "$MEMBER_ACCOUNT_ID" ] || [ -z "$MAIN_ACCOUNT_ID" ]; then
    echo -e "${RED}Error: Member account ID and Main account ID are required${NC}"
    echo "Usage: $0 <MEMBER_ACCOUNT_ID> <MAIN_ACCOUNT_ID> [LAMBDA_ROLE_NAME] [EXTERNAL_ID] [ROLE_NAME]"
    exit 1
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Trust Policy Diagnostic & Fix${NC}"
echo -e "${BLUE}========================================${NC}"
echo "Member Account ID: $MEMBER_ACCOUNT_ID"
echo "Main Account ID: $MAIN_ACCOUNT_ID"
echo "Role Name: $ROLE_NAME"
[ -n "$LAMBDA_ROLE_NAME" ] && echo "Lambda Role: $LAMBDA_ROLE_NAME" || echo "Lambda Role: (will use account root)"
[ -n "$EXTERNAL_ID" ] && echo "External ID: *** (hidden)" || echo "External ID: (not using)"
echo ""

# Step 1: Check if role exists
echo -e "${YELLOW}Step 1: Checking if role exists in member account...${NC}"
if aws iam get-role --role-name "$ROLE_NAME" --profile default >/dev/null 2>&1; then
    echo -e "${GREEN}✓ Role exists${NC}"
    ROLE_EXISTS=true
else
    echo -e "${RED}✗ Role does not exist${NC}"
    echo "  You need to create the role first."
    echo "  Run: ./create-cross-account-role-complete.sh $MEMBER_ACCOUNT_ID $MAIN_ACCOUNT_ID $LAMBDA_ROLE_NAME $EXTERNAL_ID"
    exit 1
fi

# Step 2: Get current trust policy
echo -e "${YELLOW}Step 2: Checking current trust policy...${NC}"
CURRENT_TRUST_POLICY=$(aws iam get-role --role-name "$ROLE_NAME" --query 'Role.AssumeRolePolicyDocument' --output json 2>/dev/null || echo '{}')

echo "Current trust policy:"
echo "$CURRENT_TRUST_POLICY" | jq '.' 2>/dev/null || echo "$CURRENT_TRUST_POLICY"
echo ""

# Step 3: Build correct principal ARN
if [ -n "$LAMBDA_ROLE_NAME" ]; then
    EXPECTED_PRINCIPAL="arn:aws:iam::${MAIN_ACCOUNT_ID}:role/${LAMBDA_ROLE_NAME}"
else
    EXPECTED_PRINCIPAL="arn:aws:iam::${MAIN_ACCOUNT_ID}:root"
fi

echo -e "${YELLOW}Step 3: Expected principal ARN${NC}"
echo "Expected: $EXPECTED_PRINCIPAL"
echo ""

# Step 4: Check if principal matches
CURRENT_PRINCIPAL=$(echo "$CURRENT_TRUST_POLICY" | jq -r '.Statement[0].Principal.AWS' 2>/dev/null || echo "not found")

if [ "$CURRENT_PRINCIPAL" == "$EXPECTED_PRINCIPAL" ] || [ "$CURRENT_PRINCIPAL" == "arn:aws:iam::${MAIN_ACCOUNT_ID}:root" ]; then
    echo -e "${GREEN}✓ Principal ARN is correct${NC}"
    PRINCIPAL_OK=true
else
    echo -e "${RED}✗ Principal ARN mismatch${NC}"
    echo "  Current: $CURRENT_PRINCIPAL"
    echo "  Expected: $EXPECTED_PRINCIPAL"
    PRINCIPAL_OK=false
fi

# Step 5: Check External ID
if [ -n "$EXTERNAL_ID" ]; then
    CURRENT_EXTERNAL_ID=$(echo "$CURRENT_TRUST_POLICY" | jq -r '.Statement[0].Condition.StringEquals."sts:ExternalId"' 2>/dev/null || echo "not found")
    
    if [ "$CURRENT_EXTERNAL_ID" == "$EXTERNAL_ID" ]; then
        echo -e "${GREEN}✓ External ID matches${NC}"
        EXTERNAL_ID_OK=true
    elif [ "$CURRENT_EXTERNAL_ID" == "not found" ] || [ "$CURRENT_EXTERNAL_ID" == "null" ]; then
        echo -e "${YELLOW}⚠ External ID not set in trust policy (but you provided one)${NC}"
        EXTERNAL_ID_OK=false
    else
        echo -e "${RED}✗ External ID mismatch${NC}"
        echo "  Current: $CURRENT_EXTERNAL_ID"
        echo "  Expected: $EXTERNAL_ID"
        EXTERNAL_ID_OK=false
    fi
else
    # Check if External ID is in policy but not provided
    HAS_EXTERNAL_ID=$(echo "$CURRENT_TRUST_POLICY" | jq -r '.Statement[0].Condition.StringEquals."sts:ExternalId"' 2>/dev/null || echo "null")
    if [ "$HAS_EXTERNAL_ID" != "null" ] && [ -n "$HAS_EXTERNAL_ID" ]; then
        echo -e "${YELLOW}⚠ Trust policy requires External ID but you didn't provide one${NC}"
        echo "  Current External ID in policy: $HAS_EXTERNAL_ID"
        echo "  You need to provide this External ID when assuming the role"
        EXTERNAL_ID_OK=false
    else
        echo -e "${GREEN}✓ No External ID required (matches configuration)${NC}"
        EXTERNAL_ID_OK=true
    fi
fi

echo ""

# Step 6: Fix if needed
if [ "$PRINCIPAL_OK" = false ] || [ "$EXTERNAL_ID_OK" = false ]; then
    echo -e "${YELLOW}Step 4: Fixing trust policy...${NC}"
    
    # Generate correct trust policy
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    TRUST_POLICY=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "${EXPECTED_PRINCIPAL}"
      },
      "Action": "sts:AssumeRole"$([ -n "$EXTERNAL_ID" ] && cat <<INNER
,
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "${EXTERNAL_ID}"
        }
      }
INNER
)
    }
  ]
}
EOF
)
    
    echo "$TRUST_POLICY" > /tmp/trust-policy-fix.json
    echo "New trust policy:"
    cat /tmp/trust-policy-fix.json | jq '.' 2>/dev/null || cat /tmp/trust-policy-fix.json
    echo ""
    
    read -p "Update trust policy? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        aws iam update-assume-role-policy \
            --role-name "$ROLE_NAME" \
            --policy-document file:///tmp/trust-policy-fix.json
        
        echo -e "${GREEN}✓ Trust policy updated${NC}"
        rm /tmp/trust-policy-fix.json
    else
        echo "Skipped. Trust policy not updated."
        rm /tmp/trust-policy-fix.json
    fi
else
    echo -e "${GREEN}✓ Trust policy is correct${NC}"
    echo ""
    echo "If you're still getting AccessDenied errors, check:"
    echo "1. External ID matches in Lambda environment variable"
    echo "2. Lambda execution role has sts:AssumeRole permission"
    echo "3. No other IAM policies are blocking the assumption"
fi

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Next Steps${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo "1. Verify Lambda has External ID set (if using):"
echo "   aws lambda get-function-configuration \\"
echo "     --function-name inventory-dashboard-RefreshFunction \\"
echo "     --query 'Environment.Variables.EXTERNAL_ID'"
echo ""
echo "2. Test role assumption:"
echo "   aws sts assume-role \\"
echo "     --role-arn arn:aws:iam::${MEMBER_ACCOUNT_ID}:role/${ROLE_NAME} \\"
echo "     --role-session-name test-session$([ -n "$EXTERNAL_ID" ] && echo " \\" && echo "     --external-id $EXTERNAL_ID" || echo "")"
echo ""
echo "3. Check CloudWatch logs after fix"
echo ""

