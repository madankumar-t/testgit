#!/bin/bash

# Script to generate trust policy JSON for cross-account role
# Usage: ./create-trust-policy.sh <MAIN_ACCOUNT_ID> [LAMBDA_ROLE_NAME] [EXTERNAL_ID] > trust-policy.json

set -e

MAIN_ACCOUNT_ID="${1}"
LAMBDA_ROLE_NAME="${2}"
EXTERNAL_ID="${3}"

if [ -z "$MAIN_ACCOUNT_ID" ]; then
    echo "Error: Main account ID is required" >&2
    echo "Usage: $0 <MAIN_ACCOUNT_ID> [LAMBDA_ROLE_NAME] [EXTERNAL_ID]" >&2
    exit 1
fi

# Build principal ARN
if [ -n "$LAMBDA_ROLE_NAME" ]; then
    PRINCIPAL_ARN="arn:aws:iam::${MAIN_ACCOUNT_ID}:role/${LAMBDA_ROLE_NAME}"
else
    PRINCIPAL_ARN="arn:aws:iam::${MAIN_ACCOUNT_ID}:root"
fi

# Generate trust policy
cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "${PRINCIPAL_ARN}"
      },
      "Action": "sts:AssumeRole"$( [ -n "$EXTERNAL_ID" ] && cat <<INNER
,
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "${EXTERNAL_ID}"
        }
      }
INNER
)
    }
  ]
}
EOF

