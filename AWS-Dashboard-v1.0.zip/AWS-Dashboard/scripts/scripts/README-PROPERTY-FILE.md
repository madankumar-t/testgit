# Using Property File Configuration

The cross-account role setup scripts can read all configuration from a property file, making it easier to manage and reuse settings.

## Quick Start

1. **Copy the example file:**
   ```bash
   cp scripts/cross-account-config.example.properties scripts/cross-account-config.properties
   ```

2. **Edit the property file** with your values:
   ```bash
   # Edit with your favorite editor
   nano scripts/cross-account-config.properties
   # or
   vi scripts/cross-account-config.properties
   ```

3. **Run the script:**
   ```bash
   ./scripts/setup-ops-to-child-roles.sh
   ```

## Property File Format

The property file uses a simple `KEY=VALUE` format:

```properties
# Comments start with #
OPS_ACCOUNT_ID=123456789012
LAMBDA_FUNCTION_NAME=RefreshFunction
ROLE_NAME=InventoryReadRole
EXTERNAL_ID=my-secure-external-id
CHILD_ACCOUNTS=123456789012,987654321098
```

## Available Properties

| Property | Description | Required | Default |
|----------|-------------|----------|---------|
| `OPS_ACCOUNT_ID` | Ops account ID | No (auto-detect) | - |
| `LAMBDA_FUNCTION_NAME` | Lambda function name | No | `RefreshFunction` |
| `ROLE_NAME` | Role name in child accounts | No | `InventoryReadRole` |
| `EXTERNAL_ID` | External ID for security | No | (empty) |
| `CHILD_ACCOUNTS` | Comma-separated account IDs | Yes* | - |
| `CHILD_ACCOUNTS_FILE` | Path to file with account IDs | Yes* | - |
| `DRY_RUN` | Show what would be done | No | `false` |
| `POLICY_FILE` | Path to permissions policy | No | `policies/inventory-read-policy.json` |

*Either `CHILD_ACCOUNTS` or `CHILD_ACCOUNTS_FILE` must be provided.

## Command Line Overrides

Command line arguments **override** property file values. This allows you to:

- Use a base configuration from the property file
- Override specific values for one-time runs

**Example:**
```bash
# Use property file but override External ID
./setup-ops-to-child-roles.sh --external-id temporary-id

# Use property file but add one more account
./setup-ops-to-child-roles.sh --child-accounts 111222333444
```

## Examples

### Example 1: Basic Setup

**Property file (`cross-account-config.properties`):**
```properties
OPS_ACCOUNT_ID=123456789012
LAMBDA_FUNCTION_NAME=RefreshFunction
ROLE_NAME=InventoryReadRole
EXTERNAL_ID=secure-id-abc123
CHILD_ACCOUNTS=987654321098,111222333444
```

**Run:**
```bash
./setup-ops-to-child-roles.sh
```

### Example 2: Using Account File

**Property file:**
```properties
EXTERNAL_ID=secure-id-abc123
CHILD_ACCOUNTS_FILE=accounts.txt
```

**Account file (`accounts.txt`):**
```
987654321098
111222333444
555666777888
```

**Run:**
```bash
./setup-ops-to-child-roles.sh
```

### Example 3: Override Property File

**Property file:**
```properties
CHILD_ACCOUNTS=987654321098,111222333444
EXTERNAL_ID=default-id
```

**Run with override:**
```bash
# Use different External ID for this run
./setup-ops-to-child-roles.sh --external-id temporary-id
```

### Example 4: Custom Config File

**Run with custom config file:**
```bash
./setup-ops-to-child-roles.sh --config-file my-custom-config.properties
```

## Property File Location

By default, the script looks for `cross-account-config.properties` in the same directory as the script.

**Default location:**
- Bash: `scripts/cross-account-config.properties`
- PowerShell: `scripts\cross-account-config.properties`

**Custom location:**
```bash
./setup-ops-to-child-roles.sh --config-file /path/to/my-config.properties
```

## Best Practices

1. **Don't commit property files with secrets:**
   - Add `cross-account-config.properties` to `.gitignore`
   - Commit `cross-account-config.example.properties` as a template

2. **Use External ID:**
   - Always set `EXTERNAL_ID` in production
   - Generate a secure value (UUID or timestamp-based)

3. **Organize by environment:**
   - `cross-account-config.dev.properties`
   - `cross-account-config.prod.properties`
   - Use `--config-file` to specify which one

4. **Version control:**
   - Keep example/template files in version control
   - Document required properties in README

## Troubleshooting

### Property file not found

If the script can't find the property file:
- Check the file path
- Use `--config-file` to specify the full path
- The script will use defaults if the file is missing

### Properties not being read

Common issues:
- **Comments on same line:** Properties must be on their own line
- **Spaces around `=`:** Use `KEY=VALUE` not `KEY = VALUE`
- **Empty values:** Use empty string: `EXTERNAL_ID=`

### Command line overrides not working

Command line arguments always override property file values. If a value isn't changing:
- Check for typos in the command line argument
- Verify the property file value is being read (check script output)

## Security Notes

⚠️ **Important:**
- Property files may contain sensitive information (External ID)
- Never commit property files with real values to version control
- Use environment-specific property files
- Consider using AWS Secrets Manager for production deployments

