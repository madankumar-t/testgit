$env:AWS_PROFILE = "NXT-MASTER"

$envVars = @{
    EXTERNAL_ID          = "990c1f3e-5f4b-4d3a-8e2a-5b6c7d8e9f0a"
    INVENTORY_ROLE_NAME  = "InventoryReadRole"
    INVENTORY_ACCOUNTS   = "455737279564,887627432664,780781249373,014402785795,358027144360,196690901583"
    INVENTORY_TABLE_NAME = "aws-inventory-data-dev"
    METADATA_TABLE_NAME  = "aws-inventory-metadata-dev"
}

$envJson = ($envVars.GetEnumerator() | ForEach-Object { "`"$($_.Key)`":`"$($_.Value)`"" }) -join ","
$envString = "Variables={$envJson}"

Write-Host "Updating Lambda environment variables..." -ForegroundColor Cyan
aws lambda update-function-configuration `
    --function-name inventory-dashboard-RefreshFunction-ox4DeJBH5N9R `
    --environment $envString

Write-Host "`nDone!" -ForegroundColor Green
