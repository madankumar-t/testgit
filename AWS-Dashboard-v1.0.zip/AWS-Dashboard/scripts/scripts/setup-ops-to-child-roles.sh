#!/bin/bash

################################################################################
# Setup Cross-Account Roles: Ops Account → Child Accounts
# 
# Creates IAM roles in child accounts that allow the Ops account Lambda
# RefreshFunction to assume roles and collect inventory data for DynamoDB.
#
# Usage:
#   ./setup-ops-to-child-roles.sh [OPTIONS] [--config-file FILE]
#
# Options:
#   --config-file FILE             Property file with all configuration (default: cross-account-config.properties)
#   --ops-account-id ACCOUNT_ID     Ops account ID (overrides config file)
#   --child-accounts ACCOUNT1,ACCOUNT2  Comma-separated child account IDs (overrides config file)
#   --child-accounts-file FILE     File with one account ID per line (overrides config file)
#   --role-name NAME               Role name in child accounts (overrides config file)
#   --external-id ID               External ID for security (overrides config file)
#   --lambda-function-name NAME    Lambda function name (overrides config file)
#   --dry-run                      Show what would be done without making changes (overrides config file)
#
# Examples:
#   # Using property file (recommended)
#   ./setup-ops-to-child-roles.sh
#
#   # Using property file with overrides
#   ./setup-ops-to-child-roles.sh --external-id my-secure-id
#
#   # Using command line only
#   ./setup-ops-to-child-roles.sh --child-accounts 123456789012,987654321098
#
################################################################################

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_CONFIG_FILE="${SCRIPT_DIR}/cross-account-config.properties"

# Defaults
CONFIG_FILE="$DEFAULT_CONFIG_FILE"
OPS_ACCOUNT_ID=""
CHILD_ACCOUNTS=()
ROLE_NAME="InventoryReadRole"
EXTERNAL_ID=""
LAMBDA_FUNCTION_NAME="RefreshFunction"
DRY_RUN=false
CHILD_ACCOUNTS_FILE=""
POLICY_FILE="${SCRIPT_DIR}/policies/inventory-read-policy.json"

# Function to read property file
read_properties() {
    local prop_file="$1"
    
    if [ ! -f "$prop_file" ]; then
        return 1
    fi
    
    # Read properties, ignoring comments and empty lines
    while IFS='=' read -r key value || [ -n "$key" ]; do
        # Skip comments and empty lines
        [[ "$key" =~ ^[[:space:]]*# ]] && continue
        [[ -z "$key" ]] && continue
        
        # Remove leading/trailing whitespace
        key=$(echo "$key" | xargs)
        value=$(echo "$value" | xargs)
        
        # Skip if key is empty after trimming
        [[ -z "$key" ]] && continue
        
        # Set variable based on key
        case "$key" in
            OPS_ACCOUNT_ID)
                [ -z "$OPS_ACCOUNT_ID" ] && OPS_ACCOUNT_ID="$value"
                ;;
            LAMBDA_FUNCTION_NAME)
                [ -z "$LAMBDA_FUNCTION_NAME" ] && LAMBDA_FUNCTION_NAME="$value"
                ;;
            ROLE_NAME)
                [ "$ROLE_NAME" = "InventoryReadRole" ] && ROLE_NAME="$value"
                ;;
            EXTERNAL_ID)
                [ -z "$EXTERNAL_ID" ] && EXTERNAL_ID="$value"
                ;;
            CHILD_ACCOUNTS)
                if [ -z "$CHILD_ACCOUNTS_FILE" ] && [ -n "$value" ]; then
                    IFS=',' read -ra CHILD_ACCOUNTS <<< "$value"
                fi
                ;;
            CHILD_ACCOUNTS_FILE)
                [ -z "$CHILD_ACCOUNTS_FILE" ] && CHILD_ACCOUNTS_FILE="$value"
                ;;
            DRY_RUN)
                if [ "$DRY_RUN" = false ] && [ "$value" = "true" ]; then
                    DRY_RUN=true
                fi
                ;;
            POLICY_FILE)
                if [ "$POLICY_FILE" = "${SCRIPT_DIR}/policies/inventory-read-policy.json" ]; then
                    if [[ "$value" = /* ]]; then
                        POLICY_FILE="$value"
                    else
                        POLICY_FILE="${SCRIPT_DIR}/$value"
                    fi
                fi
                ;;
        esac
    done < <(grep -v '^[[:space:]]*#' "$prop_file" | grep -v '^[[:space:]]*$')
}

# Parse arguments first to get config file
while [[ $# -gt 0 ]]; do
    case $1 in
        --config-file)
            CONFIG_FILE="$2"
            shift 2
            ;;
        *)
            # Will parse other arguments after loading config
            break
            ;;
    esac
done

# Define helper functions first
info() { echo -e "${BLUE}ℹ${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }
warning() { echo -e "${YELLOW}⚠${NC} $1"; }
error() { echo -e "${RED}✗${NC} $1"; }

# Load properties from file if it exists
if [ -f "$CONFIG_FILE" ]; then
    info "Loading configuration from: $CONFIG_FILE"
    read_properties "$CONFIG_FILE"
else
    if [ "$CONFIG_FILE" != "$DEFAULT_CONFIG_FILE" ]; then
        warning "Config file not found: $CONFIG_FILE"
        warning "Using defaults and command line arguments"
    fi
fi

# Parse remaining arguments (these override config file values)
while [[ $# -gt 0 ]]; do
    case $1 in
        --config-file)
            shift 2
            ;;
        --ops-account-id)
            OPS_ACCOUNT_ID="$2"
            shift 2
            ;;
        --child-accounts)
            CHILD_ACCOUNTS=()
            IFS=',' read -ra CHILD_ACCOUNTS <<< "$2"
            shift 2
            ;;
        --child-accounts-file)
            CHILD_ACCOUNTS_FILE="$2"
            CHILD_ACCOUNTS=()  # Clear array if file is specified
            shift 2
            ;;
        --role-name)
            ROLE_NAME="$2"
            shift 2
            ;;
        --external-id)
            EXTERNAL_ID="$2"
            shift 2
            ;;
        --lambda-function-name)
            LAMBDA_FUNCTION_NAME="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            head -n 30 "$0" | grep "^#" | sed 's/^# //'
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}" >&2
            exit 1
            ;;
    esac
done

# Load child accounts from file if specified
if [ -n "$CHILD_ACCOUNTS_FILE" ]; then
    if [ ! -f "$CHILD_ACCOUNTS_FILE" ]; then
        # Try relative to script directory
        if [ -f "${SCRIPT_DIR}/${CHILD_ACCOUNTS_FILE}" ]; then
            CHILD_ACCOUNTS_FILE="${SCRIPT_DIR}/${CHILD_ACCOUNTS_FILE}"
        else
            echo -e "${RED}Error: File not found: $CHILD_ACCOUNTS_FILE${NC}" >&2
            exit 1
        fi
    fi
    CHILD_ACCOUNTS=()
    while IFS= read -r line; do
        [[ -z "$line" || "$line" =~ ^# ]] && continue
        CHILD_ACCOUNTS+=("$line")
    done < "$CHILD_ACCOUNTS_FILE"
fi

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --ops-account-id)
            OPS_ACCOUNT_ID="$2"
            shift 2
            ;;
        --child-accounts)
            IFS=',' read -ra CHILD_ACCOUNTS <<< "$2"
            shift 2
            ;;
        --child-accounts-file)
            if [ ! -f "$2" ]; then
                echo -e "${RED}Error: File not found: $2${NC}" >&2
                exit 1
            fi
            while IFS= read -r line; do
                [[ -z "$line" || "$line" =~ ^# ]] && continue
                CHILD_ACCOUNTS+=("$line")
            done < "$2"
            shift 2
            ;;
        --role-name)
            ROLE_NAME="$2"
            shift 2
            ;;
        --external-id)
            EXTERNAL_ID="$2"
            shift 2
            ;;
        --lambda-function-name)
            LAMBDA_FUNCTION_NAME="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            head -n 25 "$0" | grep "^#" | sed 's/^# //'
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}" >&2
            exit 1
            ;;
    esac
done


# Validate AWS CLI
if ! command -v aws &> /dev/null; then
    error "AWS CLI not found. Please install it first."
    exit 1
fi

# Get Ops account ID
if [ -z "$OPS_ACCOUNT_ID" ]; then
    info "Detecting Ops account ID..."
    OPS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null || echo "")
    if [ -z "$OPS_ACCOUNT_ID" ]; then
        error "Could not detect Ops account ID. Provide with --ops-account-id"
        exit 1
    fi
fi
success "Ops Account ID: $OPS_ACCOUNT_ID"

# Validate child accounts
if [ ${#CHILD_ACCOUNTS[@]} -eq 0 ]; then
    error "No child accounts specified. Use --child-accounts or --child-accounts-file"
    exit 1
fi

# Find Lambda execution role
info "Finding Lambda execution role for: $LAMBDA_FUNCTION_NAME..."
LAMBDA_ROLE_ARN=""
LAMBDA_ROLE_NAME=""

# Try Lambda function configuration
if LAMBDA_CONFIG=$(aws lambda get-function-configuration --function-name "$LAMBDA_FUNCTION_NAME" 2>/dev/null); then
    LAMBDA_ROLE_ARN=$(echo "$LAMBDA_CONFIG" | grep -o '"Role": "[^"]*"' | cut -d'"' -f4 || echo "")
    if [ -n "$LAMBDA_ROLE_ARN" ]; then
        LAMBDA_ROLE_NAME=$(echo "$LAMBDA_ROLE_ARN" | sed 's/.*role\///')
        success "Found Lambda role: $LAMBDA_ROLE_NAME"
    fi
fi

# Search IAM roles if not found
if [ -z "$LAMBDA_ROLE_NAME" ]; then
    info "Searching IAM roles..."
    for pattern in "RefreshFunction" "inventory-dashboard-RefreshFunction"; do
        ROLE_ARN=$(aws iam list-roles --query "Roles[?contains(RoleName, \`$pattern\`)].Arn" --output text 2>/dev/null | head -n1 || echo "")
        if [ -n "$ROLE_ARN" ]; then
            LAMBDA_ROLE_ARN="$ROLE_ARN"
            LAMBDA_ROLE_NAME=$(echo "$ROLE_ARN" | sed 's/.*role\///')
            success "Found Lambda role: $LAMBDA_ROLE_NAME"
            break
        fi
    done
fi

# Fallback warning
if [ -z "$LAMBDA_ROLE_NAME" ]; then
    warning "Could not find Lambda role. Using account root (less secure)."
    LAMBDA_ROLE_ARN="arn:aws:iam::${OPS_ACCOUNT_ID}:root"
fi

# Validate policy file
if [ ! -f "$POLICY_FILE" ]; then
    error "Policy file not found: $POLICY_FILE"
    exit 1
fi
POLICY_DOCUMENT=$(cat "$POLICY_FILE")

# Create trust policy
create_trust_policy() {
    local role_arn=$1
    local ext_id=$2
    
    if [ -n "$ext_id" ] && [ -n "$LAMBDA_ROLE_NAME" ]; then
        cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "${role_arn}"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "${ext_id}"
        }
      }
    }
  ]
}
EOF
    elif [ -n "$ext_id" ]; then
        cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::${OPS_ACCOUNT_ID}:root"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "${ext_id}"
        }
      }
    }
  ]
}
EOF
    elif [ -n "$LAMBDA_ROLE_NAME" ]; then
        cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "${role_arn}"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
    else
        cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::${OPS_ACCOUNT_ID}:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
    fi
}

# Setup role in child account
setup_role() {
    local child_account=$1
    
    info "Setting up role in account: $child_account"
    
    local trust_policy
    if [ -n "$LAMBDA_ROLE_NAME" ]; then
        trust_policy=$(create_trust_policy "$LAMBDA_ROLE_ARN" "$EXTERNAL_ID")
    else
        trust_policy=$(create_trust_policy "" "$EXTERNAL_ID")
    fi
    
    if [ "$DRY_RUN" = true ]; then
        info "[DRY RUN] Would create/update role: $ROLE_NAME"
        echo "$trust_policy" | jq '.' 2>/dev/null || echo "$trust_policy"
        return 0
    fi
    
    # Create or update role
    local trust_file=$(mktemp)
    echo "$trust_policy" > "$trust_file"
    
    if aws iam get-role --role-name "$ROLE_NAME" > /dev/null 2>&1; then
        warning "Role exists. Updating trust policy..."
        aws iam update-assume-role-policy \
            --role-name "$ROLE_NAME" \
            --policy-document "file://$trust_file" > /dev/null
        success "Trust policy updated"
    else
        info "Creating role..."
        aws iam create-role \
            --role-name "$ROLE_NAME" \
            --assume-role-policy-document "file://$trust_file" \
            --description "Allows Ops account Lambda RefreshFunction to collect inventory and update DynamoDB" > /dev/null
        success "Role created"
    fi
    rm -f "$trust_file"
    
    # Attach permissions
    info "Attaching permissions policy..."
    local policy_file=$(mktemp)
    echo "$POLICY_DOCUMENT" > "$policy_file"
    aws iam put-role-policy \
        --role-name "$ROLE_NAME" \
        --policy-name InventoryReadPolicy \
        --policy-document "file://$policy_file" > /dev/null
    rm -f "$policy_file"
    success "Permissions attached"
    
    success "Account $child_account: Setup complete"
    echo "  Role ARN: arn:aws:iam::${child_account}:role/${ROLE_NAME}"
}

# Main execution
echo ""
echo "=========================================="
echo "  Cross-Account Role Setup"
echo "  Ops Account → Child Accounts"
echo "=========================================="
echo ""
echo "Ops Account:        $OPS_ACCOUNT_ID"
echo "Lambda Role:        ${LAMBDA_ROLE_NAME:-(account root)}"
echo "Child Accounts:     ${#CHILD_ACCOUNTS[@]}"
echo "Role Name:          $ROLE_NAME"
if [ -n "$EXTERNAL_ID" ]; then
    echo "External ID:        ${EXTERNAL_ID:0:4}****"
else
    echo "External ID:        (not set - recommended for production)"
fi
echo ""

if [ "$DRY_RUN" = true ]; then
    warning "DRY RUN MODE - No changes will be made"
    echo ""
fi

# Process accounts
SUCCESS=0
FAILED=()

for account in "${CHILD_ACCOUNTS[@]}"; do
    account=$(echo "$account" | xargs)
    [ -z "$account" ] && continue
    
    echo "----------------------------------------"
    if setup_role "$account"; then
        SUCCESS=$((SUCCESS + 1))
    else
        FAILED+=("$account")
        error "Account $account: Setup failed"
    fi
    echo ""
done

# Summary
echo "=========================================="
echo "  Summary"
echo "=========================================="
echo "Total:    ${#CHILD_ACCOUNTS[@]}"
echo "Success:  $SUCCESS"
echo "Failed:   ${#FAILED[@]}"

if [ ${#FAILED[@]} -gt 0 ]; then
    error "Failed accounts:"
    for acc in "${FAILED[@]}"; do
        echo "  - $acc"
    done
    exit 1
fi

echo ""
success "All roles setup successfully!"
echo ""
echo "Next steps:"
echo "1. Verify roles in AWS Console"
echo "2. If using External ID, update Lambda environment variable:"
echo "   EXTERNAL_ID = $EXTERNAL_ID"
echo "3. Test role assumption:"
echo "   aws sts assume-role \\"
echo "     --role-arn arn:aws:iam::<CHILD_ACCOUNT>:role/$ROLE_NAME \\"
echo "     --role-session-name test"
if [ -n "$EXTERNAL_ID" ]; then
    echo "     --external-id $EXTERNAL_ID"
fi
echo "4. Trigger Lambda refresh to test data collection"

