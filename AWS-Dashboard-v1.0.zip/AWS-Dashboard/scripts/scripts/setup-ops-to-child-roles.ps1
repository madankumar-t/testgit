#Requires -Version 5.1

################################################################################
# Setup Cross-Account Roles: Ops Account → Child Accounts
# 
# Creates IAM roles in child accounts that allow the Ops account Lambda
# RefreshFunction to assume roles and collect inventory data for DynamoDB.
#
# Usage:
#   .\setup-ops-to-child-roles.ps1 [OPTIONS] [-ConfigFile FILE]
#
# Options:
#   -ConfigFile FILE               Property file with all configuration (default: cross-account-config.properties)
#   -OpsAccountId ACCOUNT_ID       Ops account ID (overrides config file)
#   -ChildAccounts ACCOUNT1,ACCOUNT2  Comma-separated child account IDs (overrides config file)
#   -ChildAccountsFile FILE        File with one account ID per line (overrides config file)
#   -RoleName NAME                 Role name in child accounts (overrides config file)
#   -ExternalId ID                 External ID for security (overrides config file)
#   -LambdaFunctionName NAME       Lambda function name (overrides config file)
#   -DryRun                        Show what would be done without making changes (overrides config file)
#
# Examples:
#   # Using property file (recommended)
#   .\setup-ops-to-child-roles.ps1
#
#   # Using property file with overrides
#   .\setup-ops-to-child-roles.ps1 -ExternalId "my-secure-id"
#
#   # Using command line only
#   .\setup-ops-to-child-roles.ps1 -ChildAccounts "123456789012,987654321098"
#
################################################################################

[CmdletBinding()]
param(
    [string]$ConfigFile = "",
    [string]$OpsAccountId = "",
    [string[]]$ChildAccounts = @(),
    [string]$ChildAccountsFile = "",
    [string]$RoleName = "InventoryReadRole",
    [string]$ExternalId = "",
    [string]$LambdaFunctionName = "RefreshFunction",
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

# Get script directory
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DefaultConfigFile = Join-Path $ScriptDir "cross-account-config.properties"
$PolicyFile = Join-Path $ScriptDir "policies\inventory-read-policy.json"

# Helper functions
function Write-Info { 
    param([string]$Msg) 
    Write-Host "[INFO] $Msg" -ForegroundColor Cyan 
}
function Write-Success { 
    param([string]$Msg) 
    Write-Host "[SUCCESS] $Msg" -ForegroundColor Green 
}
function Write-Warning { 
    param([string]$Msg) 
    Write-Host "[WARNING] $Msg" -ForegroundColor Yellow 
}
function Write-Error { 
    param([string]$Msg) 
    Write-Host "[ERROR] $Msg" -ForegroundColor Red 
}

# Function to read property file
function Read-Properties {
    param([string]$PropFile)
    
    if (-not (Test-Path $PropFile)) {
        return $false
    }
    
    $content = Get-Content $PropFile
    foreach ($line in $content) {
        # Skip comments and empty lines
        if ($line -match '^\s*#' -or $line -match '^\s*$') {
            continue
        }
        
        # Parse key=value
        if ($line -match '^([^=]+)=(.*)$') {
            $key = $matches[1].Trim()
            $value = $matches[2].Trim()
            
            # Set variables if not already set by command line
            switch ($key) {
                "OPS_ACCOUNT_ID" {
                    if (-not $OpsAccountId) { $script:OpsAccountId = $value }
                }
                "LAMBDA_FUNCTION_NAME" {
                    if (-not $LambdaFunctionName -or $LambdaFunctionName -eq "RefreshFunction") {
                        $script:LambdaFunctionName = $value
                    }
                }
                "ROLE_NAME" {
                    if ($RoleName -eq "InventoryReadRole") {
                        $script:RoleName = $value
                    }
                }
                "EXTERNAL_ID" {
                    if (-not $ExternalId) { $script:ExternalId = $value }
                }
                "CHILD_ACCOUNTS" {
                    if (-not $ChildAccountsFile -and $value) {
                        $script:ChildAccounts = $value -split ',' | ForEach-Object { $_.Trim() }
                    }
                }
                "CHILD_ACCOUNTS_FILE" {
                    if (-not $ChildAccountsFile) {
                        $script:ChildAccountsFile = $value
                    }
                }
                "DRY_RUN" {
                    if (-not $DryRun -and $value -eq "true") {
                        $script:DryRun = $true
                    }
                }
                "POLICY_FILE" {
                    if ($PolicyFile -eq (Join-Path $ScriptDir "policies\inventory-read-policy.json")) {
                        if ([System.IO.Path]::IsPathRooted($value)) {
                            $script:PolicyFile = $value
                        }
                        else {
                            $script:PolicyFile = Join-Path $ScriptDir $value
                        }
                    }
                }
            }
        }
    }
    return $true
}

# Load properties from file
if (-not $ConfigFile) {
    $ConfigFile = $DefaultConfigFile
}

if (Test-Path $ConfigFile) {
    Write-Info "Loading configuration from: $ConfigFile"
    $null = Read-Properties -PropFile $ConfigFile
}
else {
    if ($ConfigFile -ne $DefaultConfigFile) {
        Write-Warning "Config file not found: $ConfigFile"
        Write-Warning "Using defaults and command line arguments"
    }
}

# Validate AWS CLI
try {
    $null = Get-Command aws -ErrorAction Stop
}
catch {
    Write-Error "AWS CLI not found. Please install it first."
    exit 1
}

# Load child accounts from file if specified
if ($ChildAccountsFile) {
    # Try relative to script directory if not found
    if (-not (Test-Path $ChildAccountsFile)) {
        $testPath = Join-Path $ScriptDir $ChildAccountsFile
        if (Test-Path $testPath) {
            $ChildAccountsFile = $testPath
        }
    }
    
    if (Test-Path $ChildAccountsFile) {
        Write-Info "Loading accounts from file: $ChildAccountsFile"
        $fileAccounts = Get-Content $ChildAccountsFile | Where-Object {
            $_ -and $_ -notmatch '^\s*#' -and $_.Trim()
        } | ForEach-Object { $_.Trim() }
        $ChildAccounts = $fileAccounts
    }
    else {
        Write-Error "Child accounts file not found: $ChildAccountsFile"
        exit 1
    }
}

# Validate child accounts
if ($ChildAccounts.Count -eq 0) {
    Write-Error "No child accounts specified. Use -ChildAccounts or -ChildAccountsFile"
    exit 1
}

# Get Ops account ID
if (-not $OpsAccountId) {
    Write-Info "Detecting Ops account ID..."
    try {
        $caller = aws sts get-caller-identity --output json | ConvertFrom-Json
        $OpsAccountId = $caller.Account
    }
    catch {
        Write-Error "Could not detect Ops account ID. Provide with -OpsAccountId"
        exit 1
    }
}
Write-Success "Ops Account ID: $OpsAccountId"

# Find Lambda execution role
Write-Info "Finding Lambda execution role for: $LambdaFunctionName..."
$LambdaRoleArn = ""
$LambdaRoleName = ""

# Try Lambda function configuration
try {
    $lambdaConfig = aws lambda get-function-configuration --function-name $LambdaFunctionName --output json 2>$null | ConvertFrom-Json
    if ($lambdaConfig.Role) {
        $LambdaRoleArn = $lambdaConfig.Role
        $LambdaRoleName = $LambdaRoleArn -replace '.*role/', ''
        Write-Success "Found Lambda role: $LambdaRoleName"
    }
}
catch {
    # Continue to search IAM
}

# Search IAM roles
if (-not $LambdaRoleName) {
    Write-Info "Searching IAM roles..."
    $patterns = @("RefreshFunction", "inventory-dashboard-RefreshFunction")
    foreach ($pattern in $patterns) {
        try {
            $roles = aws iam list-roles --output json | ConvertFrom-Json
            $match = $roles.Roles | Where-Object { $_.RoleName -like "*$pattern*" } | Select-Object -First 1
            if ($match) {
                $LambdaRoleArn = $match.Arn
                $LambdaRoleName = $match.RoleName
                Write-Success "Found Lambda role: $LambdaRoleName"
                break
            }
        }
        catch {
            # Continue
        }
    }
}

# Fallback
if (-not $LambdaRoleName) {
    Write-Warning "Could not find Lambda role. Using account root (less secure)."
    $LambdaRoleArn = "arn:aws:iam::${OpsAccountId}:root"
}

# Validate policy file
if (-not (Test-Path $PolicyFile)) {
    Write-Error "Policy file not found: $PolicyFile"
    exit 1
}
$PolicyDocument = Get-Content $PolicyFile -Raw

# Create trust policy
function New-TrustPolicy {
    param(
        [string]$RoleArn,
        [string]$ExtId
    )
    
    if ($ExtId -and $LambdaRoleName) {
        $trust = @{
            Version   = "2012-10-17"
            Statement = @(
                @{
                    Effect    = "Allow"
                    Principal = @{ AWS = $RoleArn }
                    Action    = "sts:AssumeRole"
                    Condition = @{
                        StringEquals = @{ "sts:ExternalId" = $ExtId }
                    }
                }
            )
        }
    }
    elseif ($ExtId) {
        $trust = @{
            Version   = "2012-10-17"
            Statement = @(
                @{
                    Effect    = "Allow"
                    Principal = @{ AWS = "arn:aws:iam::${OpsAccountId}:root" }
                    Action    = "sts:AssumeRole"
                    Condition = @{
                        StringEquals = @{ "sts:ExternalId" = $ExtId }
                    }
                }
            )
        }
    }
    elseif ($LambdaRoleName) {
        $trust = @{
            Version   = "2012-10-17"
            Statement = @(
                @{
                    Effect    = "Allow"
                    Principal = @{ AWS = $RoleArn }
                    Action    = "sts:AssumeRole"
                }
            )
        }
    }
    else {
        $trust = @{
            Version   = "2012-10-17"
            Statement = @(
                @{
                    Effect    = "Allow"
                    Principal = @{ AWS = "arn:aws:iam::${OpsAccountId}:root" }
                    Action    = "sts:AssumeRole"
                }
            )
        }
    }
    
    return $trust | ConvertTo-Json -Depth 10
}

# Setup role in child account
function Setup-Role {
    param([string]$ChildAccount)
    
    Write-Info "Setting up role in account: $ChildAccount"
    
    $trustJson = New-TrustPolicy -RoleArn $LambdaRoleArn -ExtId $ExternalId
    $trustFile = [System.IO.Path]::GetTempFileName()
    
    try {
        $trustJson | Out-File -FilePath $trustFile -Encoding utf8 -NoNewline
        
        if ($DryRun) {
            Write-Info "[DRY RUN] Would create/update role: $RoleName"
            $trustJson | ConvertFrom-Json | ConvertTo-Json -Depth 10
            return $true
        }
        
        # Check if role exists
        $roleExists = $false
        try {
            $null = aws iam get-role --role-name $RoleName --output json 2>$null
            $roleExists = $true
        }
        catch {
            $roleExists = $false
        }
        
        if ($roleExists) {
            Write-Warning "Role exists. Updating trust policy..."
            aws iam update-assume-role-policy `
                --role-name $RoleName `
                --policy-document "file://$trustFile" | Out-Null
            Write-Success "Trust policy updated"
        }
        else {
            Write-Info "Creating role..."
            aws iam create-role `
                --role-name $RoleName `
                --assume-role-policy-document "file://$trustFile" `
                --description "Allows Ops account Lambda RefreshFunction to collect inventory and update DynamoDB" | Out-Null
            Write-Success "Role created"
        }
        
        # Attach permissions
        Write-Info "Attaching permissions policy..."
        $policyFile = [System.IO.Path]::GetTempFileName()
        $PolicyDocument | Out-File -FilePath $policyFile -Encoding utf8 -NoNewline
        aws iam put-role-policy `
            --role-name $RoleName `
            --policy-name InventoryReadPolicy `
            --policy-document "file://$policyFile" | Out-Null
        Remove-Item $policyFile -Force
        Write-Success "Permissions attached"
        
        Write-Success "Account $ChildAccount : Setup complete"
        Write-Host "  Role ARN: arn:aws:iam::${ChildAccount}:role/${RoleName}"
        return $true
    }
    catch {
        Write-Error "Failed: $_"
        return $false
    }
    finally {
        if (Test-Path $trustFile) { Remove-Item $trustFile -Force }
    }
}

# Main execution
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Cross-Account Role Setup" -ForegroundColor Cyan
Write-Host "  Ops Account → Child Accounts" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ops Account:        $OpsAccountId"
Write-Host "Lambda Role:        $(if ($LambdaRoleName) { $LambdaRoleName } else { '(account root)' })"
Write-Host "Child Accounts:     $($ChildAccounts.Count)"
Write-Host "Role Name:          $RoleName"
if ($ExternalId) {
    Write-Host "External ID:        $($ExternalId.Substring(0, [Math]::Min(4, $ExternalId.Length)))****"
}
else {
    Write-Host "External ID:        (not set - recommended for production)"
}
Write-Host ""

if ($DryRun) {
    Write-Warning "DRY RUN MODE - No changes will be made"
    Write-Host ""
}

# Process accounts
$Success = 0
$Failed = @()

foreach ($account in $ChildAccounts) {
    $account = $account.Trim()
    if (-not $account) { continue }
    
    Write-Host "----------------------------------------" -ForegroundColor Gray
    if (Setup-Role -ChildAccount $account) {
        $Success++
    }
    else {
        $Failed += $account
        Write-Error "Account $account : Setup failed"
    }
    Write-Host ""
}

# Summary
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Summary" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Total:    $($ChildAccounts.Count)"
Write-Host "Success:  $Success"
Write-Host "Failed:   $($Failed.Count)"

if ($Failed.Count -gt 0) {
    Write-Error "Failed accounts:"
    foreach ($acc in $Failed) {
        Write-Host "  - $acc"
    }
    exit 1
}

Write-Host ""
Write-Success "All roles setup successfully!"
Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Verify roles in AWS Console"
Write-Host "2. If using External ID, update Lambda environment variable:"
Write-Host "   EXTERNAL_ID = $ExternalId"
Write-Host "3. Test role assumption:"
Write-Host "   aws sts assume-role \"
Write-Host "     --role-arn arn:aws:iam::<CHILD_ACCOUNT>:role/$RoleName \"
Write-Host "     --role-session-name test"
if ($ExternalId) {
    Write-Host "     --external-id $ExternalId"
}
Write-Host "4. Trigger Lambda refresh to test data collection"

