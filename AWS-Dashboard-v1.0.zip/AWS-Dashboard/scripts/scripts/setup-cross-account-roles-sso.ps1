#Requires -Version 5.1

################################################################################
# Setup Cross-Account Roles with SSO
# 
# Creates IAM roles in child accounts using SSO profiles.
# All configuration is read from cross-account-config.properties
#
# Usage:
#   .\setup-cross-account-roles-sso.ps1
#
################################################################################

[CmdletBinding()]
param(
    [string]$ConfigFile = "cross-account-config.properties"
)

$ErrorActionPreference = "Stop"

# Get script directory
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $ScriptDir $ConfigFile

# Helper functions
function Write-Info { 
    param([string]$Msg) 
    Write-Host "[INFO] $Msg" -ForegroundColor Cyan 
}
function Write-Success { 
    param([string]$Msg) 
    Write-Host "[SUCCESS] $Msg" -ForegroundColor Green 
}
function Write-Warning { 
    param([string]$Msg) 
    Write-Host "[WARNING] $Msg" -ForegroundColor Yellow 
}
function Write-Error { 
    param([string]$Msg) 
    Write-Host "[ERROR] $Msg" -ForegroundColor Red 
}

# Function to read property file
function Read-Properties {
    param([string]$PropFile)
    
    if (-not (Test-Path $PropFile)) {
        Write-Error "Configuration file not found: $PropFile"
        exit 1
    }
    
    $config = @{}
    $content = Get-Content $PropFile
    foreach ($line in $content) {
        # Skip comments and empty lines
        if ($line -match '^\s*#' -or $line -match '^\s*$') {
            continue
        }
        
        # Parse key=value
        if ($line -match '^([^=]+)=(.*)$') {
            $key = $matches[1].Trim()
            $value = $matches[2].Trim()
            $config[$key] = $value
        }
    }
    
    return $config
}

# Main script
Write-Info "Loading configuration from: $ConfigPath"
$config = Read-Properties -PropFile $ConfigPath

# Validate required configuration
if (-not $config['OPS_ACCOUNT_ID']) {
    Write-Error "OPS_ACCOUNT_ID is required in configuration file"
    exit 1
}

if (-not $config['LAMBDA_FUNCTION_NAME']) {
    Write-Error "LAMBDA_FUNCTION_NAME is required in configuration file"
    exit 1
}

if (-not $config['CHILD_ACCOUNT_PROFILES']) {
    Write-Error "CHILD_ACCOUNT_PROFILES is required in configuration file"
    exit 1
}

if (-not $config['OPS_ACCOUNT_PROFILE']) {
    Write-Error "OPS_ACCOUNT_PROFILE is required in configuration file"
    exit 1
}

$OpsAccountId = $config['OPS_ACCOUNT_ID']
$OpsAccountProfile = $config['OPS_ACCOUNT_PROFILE']
$LambdaFunctionName = $config['LAMBDA_FUNCTION_NAME']
$RoleName = if ($config['ROLE_NAME']) { $config['ROLE_NAME'] } else { "InventoryReadRole" }
$ExternalId = $config['EXTERNAL_ID']
$PolicyFile = Join-Path $ScriptDir $config['POLICY_FILE']

Write-Success "Configuration loaded"

# Get Lambda execution role ARN
Write-Info "Finding Lambda execution role for: $LambdaFunctionName..."
try {
    $env:AWS_PROFILE = $OpsAccountProfile
    $lambdaRole = aws lambda get-function-configuration --function-name $LambdaFunctionName --query 'Role' --output text 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "Could not get Lambda role from function. Searching IAM roles..."
        $lambdaRole = aws iam list-roles --query "Roles[?contains(RoleName, 'RefreshFunction')].Arn | [0]" --output text 2>&1
        
        if ($LASTEXITCODE -ne 0 -or $lambdaRole -eq "None") {
            Write-Error "Could not find Lambda execution role"
            exit 1
        }
    }
    
    Write-Success "Found Lambda role: $lambdaRole"
}
catch {
    Write-Error "Failed to get Lambda role: $_"
    exit 1
}

# Parse child account profiles
$childAccounts = @()
foreach ($entry in $config['CHILD_ACCOUNT_PROFILES'] -split ',') {
    $parts = $entry.Trim() -split ':'
    if ($parts.Count -eq 2) {
        $childAccounts += @{
            AccountId = $parts[0].Trim()
            Profile   = $parts[1].Trim()
        }
    }
}

if ($childAccounts.Count -eq 0) {
    Write-Error "No valid child accounts found in CHILD_ACCOUNT_PROFILES"
    exit 1
}

# Create trust policy JSON with proper formatting
$trustPolicyFile = Join-Path $ScriptDir "trust-policy.json"

if ($ExternalId) {
    $trustPolicyContent = @"
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "$lambdaRole"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "$ExternalId"
        }
      }
    }
  ]
}
"@
    $externalIdMasked = $ExternalId.Substring(0, 4) + "****"
}
else {
    $trustPolicyContent = @"
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "$lambdaRole"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
"@
    $externalIdMasked = "(none)"
}

# Save trust policy to file
$trustPolicyContent | Out-File -FilePath $trustPolicyFile -Encoding ASCII -NoNewline
$trustPolicyJson = ($trustPolicyContent -replace "`r`n", "" -replace "`n", "" -replace "\s+", " ").Trim()

# Load permissions policy
if (-not (Test-Path $PolicyFile)) {
    Write-Error "Permissions policy file not found: $PolicyFile"
    exit 1
}

$permissionsPolicy = Get-Content $PolicyFile -Raw

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Cross-Account Role Setup (SSO)" -ForegroundColor Cyan
Write-Host "  Ops Account -> Child Accounts" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ops Account:        $OpsAccountId"
Write-Host "Ops Profile:        $OpsAccountProfile"
Write-Host "Lambda Role:        $lambdaRole"
Write-Host "Child Accounts:     $($childAccounts.Count)"
Write-Host "Role Name:          $RoleName"
Write-Host "External ID:        $externalIdMasked"
Write-Host ""

# Setup roles in each child account
$successCount = 0
$failCount = 0
$results = @()

foreach ($account in $childAccounts) {
    $accountId = $account.AccountId
    $profile = $account.Profile
    
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Info "Setting up role in account: $accountId (Profile: $profile)"
    
    # Switch to child account profile
    $env:AWS_PROFILE = $profile
    
    # Verify we're in the correct account
    $currentAccount = aws sts get-caller-identity --query 'Account' --output text 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to authenticate with profile: $profile"
        Write-Error "Error details: $currentAccount"
        Write-Warning "Run: aws sso login --profile $profile"
        $failCount++
        $results += "[FAILED] $accountId ($profile) - Authentication failed"
        Write-Host ""
        continue
    }
    
    if ($currentAccount -ne $accountId) {
        Write-Error "Profile $profile is for account $currentAccount, expected $accountId"
        $failCount++
        $results += "[FAILED] $accountId ($profile) - Account ID mismatch"
        Write-Host ""
        continue
    }
    
    # Check if role exists (suppress error output)
    $roleExists = $false
    $ErrorActionPreference = "SilentlyContinue"
    $existingRole = aws iam get-role --role-name $RoleName --query 'Role.Arn' --output text 2>&1 | Out-Null
    $ErrorActionPreference = "Stop"
    
    if ($LASTEXITCODE -eq 0) {
        $roleExists = $true
        Write-Info "Role already exists, updating..."
    }
    else {
        Write-Info "Creating new role..."
    }
    
    if ($roleExists) {
        # Update trust policy
        $output = aws iam update-assume-role-policy --role-name $RoleName --policy-document "file://$trustPolicyFile" 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Failed to update trust policy: $output"
            $failCount++
            $results += "[FAILED] $accountId ($profile) - Trust policy update failed"
            Write-Host ""
            continue
        }
        Write-Success "Trust policy updated"
    }
    else {
        # Create role
        $output = aws iam create-role --role-name $RoleName --assume-role-policy-document "file://$trustPolicyFile" --description "Role for AWS Inventory Dashboard data collection" 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Failed to create role: $output"
            $failCount++
            $results += "[FAILED] $accountId ($profile) - Role creation failed"
            Write-Host ""
            continue
        }
        Write-Success "Role created"
    }
    
    # Attach/update inline policy
    Write-Info "Attaching permissions policy..."
    $output = aws iam put-role-policy --role-name $RoleName --policy-name "InventoryReadPolicy" --policy-document "file://$PolicyFile" 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to attach policy: $output"
        $failCount++
        $results += "[FAILED] $accountId ($profile) - Policy attachment failed"
        Write-Host ""
        continue
    }
    Write-Success "Permissions attached"
    
    $roleArn = "arn:aws:iam::${accountId}:role/$RoleName"
    Write-Success "Account $accountId : Setup complete"
    Write-Host "  Role ARN: $roleArn"
    
    $successCount++
    $results += "[SUCCESS] $accountId ($profile) - $roleArn"
    
    Write-Host ""
}

# Summary
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Summary" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Total:    $($childAccounts.Count)"
Write-Host "Success:  $successCount" -ForegroundColor Green
Write-Host "Failed:   $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Green" })
Write-Host ""

foreach ($result in $results) {
    if ($result -like "[SUCCESS]*") {
        Write-Host $result -ForegroundColor Green
    }
    else {
        Write-Host $result -ForegroundColor Red
    }
}

if ($successCount -gt 0) {
    Write-Host ""
    Write-Success "Setup completed!"
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "1. Update Lambda environment variables:"
    Write-Host "   aws lambda update-function-configuration \"
    Write-Host "     --function-name $LambdaFunctionName \"
    Write-Host "     --environment Variables={EXTERNAL_ID=$ExternalId,INVENTORY_ROLE_NAME=$RoleName} \"
    Write-Host "     --profile $OpsAccountProfile"
    Write-Host ""
    Write-Host "2. Test role assumption from ops account:"
    Write-Host "   `$env:AWS_PROFILE = '$OpsAccountProfile'"
    Write-Host "   aws sts assume-role \"
    Write-Host "     --role-arn arn:aws:iam::<CHILD_ACCOUNT_ID>:role/$RoleName \"
    Write-Host "     --role-session-name test-session \"
    Write-Host "     --external-id $ExternalId"
}

if ($failCount -gt 0) {
    Write-Host ""
    Write-Warning "Some accounts failed. Check SSO authentication:"
    Write-Host "Run: aws sso login --profile <PROFILE_NAME>"
    exit 1
}
