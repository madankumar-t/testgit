$ErrorActionPreference = "SilentlyContinue"
$env:AWS_PROFILE = "NXT-MASTER"

$profiles = @(
    @{Account = "455737279564"; Profile = "NXT-SANDBOX" }
    @{Account = "887627432664"; Profile = "Nxt-Prod-Internal-Systems" }
    @{Account = "780781249373"; Profile = "NXT-OPERATION" }
    @{Account = "014402785795"; Profile = "Nxt-Internal-Systems" }
    @{Account = "358027144360"; Profile = "Nexturn-Solutions-Suite" }
    @{Account = "196690901583"; Profile = "Next-ETC" }
)

$policyFile = "policies/inventory-read-policy.json"

Write-Host "Updating InventoryReadRole in all child accounts with Lambda permissions..." -ForegroundColor Cyan
Write-Host ""

foreach ($item in $profiles) {
    $env:AWS_PROFILE = $item.Profile
    Write-Host "[INFO] Updating $($item.Account) ($($item.Profile))..." -ForegroundColor Cyan
    
    # Test SSO auth first
    $testAuth = aws sts get-caller-identity --query 'Account' --output text 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[WARNING] SSO token expired for $($item.Profile). Skipping..." -ForegroundColor Yellow
        Write-Host "         Run: aws sso login --profile $($item.Profile)" -ForegroundColor Gray
        continue
    }
    
    $output = aws iam put-role-policy `
        --role-name InventoryReadRole `
        --policy-name "InventoryReadPolicy" `
        --policy-document "file://$policyFile" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[SUCCESS] Updated $($item.Account)" -ForegroundColor Green
    }
    else {
        Write-Host "[ERROR] Failed: $output" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Done! All roles updated with Lambda permissions." -ForegroundColor Green
