
# AWS SNS Topic Terraform Module

## Features
- Automatically detects AWS Account ID
- Supports Standard and FIFO topics
- Content-based deduplication
- Encryption (KMS)
- Archive policy
- Basic and Advanced access policies
- Subscriptions

## Usage
```hcl
module "sns" {
  source = "./sns-topic-module"

  name       = "orders"
  fifo_topic = true
}
```
