# Redis Terraform Module

This module deploys AWS ElastiCache Redis with Cluster Mode Enabled or Disabled.
Includes examples, Spacelift config, and Terraform Cloud usage.

Refer to documentation inside repository for full usage examples.
