
import { useState } from "react";
import Login from "./Login";
import Dashboard from "./Dashboard";

export default function App() {
  const [token, setToken] = useState(null);

  return (
    <div>
      {!token ? (
        <Login onLogin={setToken} />
      ) : (
        <Dashboard token={token} onLogout={() => setToken(null)} />
      )}
    </div>
  );
}
