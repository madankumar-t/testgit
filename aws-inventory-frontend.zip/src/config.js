
const config = {
  region: "us-east-2",
  userPoolId: "us-east-2_l0Eu9OfDs",
  clientId: "3tki36tlvb5m41j7hb6sbhtnv1",
  apiUrl: "https://br1kh43rzl.execute-api.us-east-2.amazonaws.com/prod/inventory"
};

export default config;
