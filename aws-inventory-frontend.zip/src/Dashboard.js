
import { useEffect, useState } from "react";
import config from "./config";

export default function Dashboard({ token, onLogout }) {
  const [service, setService] = useState("ec2");
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    fetch(
      `${config.apiUrl}?service=${service}&page=${page}&size=10&search=${search}`,
      { headers: { Authorization: token } }
    )
      .then(res => res.json())
      .then(data => {
        setItems(data.items || []);
        setTotal(data.total || 0);
      });
  }, [service, search, page, token]);

  return (
    <div className="dashboard">
      <header>
        <h2>AWS Inventory Dashboard</h2>
        <button onClick={onLogout}>Logout</button>
      </header>

      <div className="controls">
        <select onChange={e => { setService(e.target.value); setPage(1); }}>
          <option value="ec2">EC2</option>
          <option value="s3">S3</option>
          <option value="rds">RDS</option>
          <option value="dynamodb">DynamoDB</option>
          <option value="iam">IAM Roles</option>
        </select>
        <input placeholder="Search" onChange={e => setSearch(e.target.value)} />
      </div>

      <table>
        <thead>
          <tr>
            {items[0] && Object.keys(items[0]).map(k => <th key={k}>{k}</th>)}
          </tr>
        </thead>
        <tbody>
          {items.map((row, i) => (
            <tr key={i}>
              {Object.values(row).map((v, j) => <td key={j}>{String(v)}</td>)}
            </tr>
          ))}
        </tbody>
      </table>

      <div className="pagination">
        <button disabled={page === 1} onClick={() => setPage(p => p - 1)}>Prev</button>
        <span>Page {page}</span>
        <button disabled={page * 10 >= total} onClick={() => setPage(p => p + 1)}>Next</button>
      </div>
    </div>
  );
}
