
import {
  CognitoUserPool,
  CognitoUser,
  AuthenticationDetails
} from "amazon-cognito-identity-js";
import config from "./config";

const userPool = new CognitoUserPool({
  UserPoolId: config.userPoolId,
  ClientId: config.clientId
});

export default function Login({ onLogin }) {
  let username = "";
  let password = "";

  const login = () => {
    const user = new CognitoUser({ Username: username, Pool: userPool });
    const auth = new AuthenticationDetails({ Username: username, Password: password });

    user.authenticateUser(auth, {
      onSuccess: session => onLogin(session.getIdToken().getJwtToken()),
      onFailure: err => alert(err.message)
    });
  };

  return (
    <div className="login-box">
      <h2>AWS Inventory Login</h2>
      <input placeholder="Username" onChange={e => username = e.target.value} />
      <input type="password" placeholder="Password" onChange={e => password = e.target.value} />
      <button onClick={login}>Login</button>
    </div>
  );
}
