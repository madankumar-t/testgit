"""
Shared data models for the EKS Troubleshooting Agent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Severity(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    INFO = "Info"


class FixRisk(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


@dataclass
class CommandResult:
    command: str
    stdout: str
    stderr: str
    returncode: int

    @property
    def success(self) -> bool:
        return self.returncode == 0

    @property
    def output(self) -> str:
        """Combined output for analysis."""
        return self.stdout if self.stdout else self.stderr


@dataclass
class ExecutedCommand:
    step: int
    command: str
    purpose: str
    result_summary: str
    success: bool


@dataclass
class Finding:
    component: str
    namespace: str
    resource: str
    severity: Severity
    evidence: str
    impact: str
    recommended_fix: str
    fix_command: Optional[str] = None
    rollback_command: Optional[str] = None
    fix_id: Optional[str] = None


@dataclass
class FixRecommendation:
    fix_id: str
    description: str
    command: list[str]
    risk: FixRisk
    expected_result: str
    rollback_command: Optional[list[str]]
    rollback_description: str
    requires_confirmation: bool = True
    namespace: Optional[str] = None
    resource: Optional[str] = None


@dataclass
class ClusterContext:
    cluster_name: str
    region: str
    aws_account: str = "unknown"
    aws_user: str = "unknown"
    kubernetes_version: str = "unknown"
    node_count: int = 0
    namespaces: list[str] = field(default_factory=list)
    kubectl_context: str = "unknown"
    api_server: str = "unknown"


@dataclass
class DiagnosisReport:
    cluster_context: ClusterContext
    executed_commands: list[ExecutedCommand] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    fixes: list[FixRecommendation] = field(default_factory=list)
    raw_results: dict[str, CommandResult] = field(default_factory=dict)
    root_cause: str = "Under investigation."
    escalation_notes: list[str] = field(default_factory=list)
