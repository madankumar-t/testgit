"""
Safety layer for command classification.

Separates read-only (safe) commands from mutating commands that require
explicit user confirmation before execution.
"""

from __future__ import annotations

import re
from enum import Enum, auto


class CommandClass(Enum):
    READ_ONLY = auto()    # Safe to run without confirmation
    MUTATING = auto()     # Requires explicit user confirmation
    UNKNOWN = auto()      # Default to requiring confirmation


# ---------------------------------------------------------------------------
# Read-only command prefix patterns
# Each entry is (binary, subcommand_or_None, optional_subcommand2)
# ---------------------------------------------------------------------------
_READONLY_KUBECTL = {
    ("kubectl", "get"),
    ("kubectl", "describe"),
    ("kubectl", "logs"),
    ("kubectl", "top"),
    ("kubectl", "auth", "can-i"),
    ("kubectl", "config", "current-context"),
    ("kubectl", "config", "get-contexts"),
    ("kubectl", "config", "view"),
    ("kubectl", "cluster-info"),
    ("kubectl", "version"),
    ("kubectl", "api-resources"),
    ("kubectl", "api-versions"),
    ("kubectl", "explain"),
    ("kubectl", "rollout", "history"),
    ("kubectl", "rollout", "status"),
}

_READONLY_AWS = {
    ("aws", "sts", "get-caller-identity"),
    ("aws", "eks", "describe-cluster"),
    ("aws", "eks", "list-clusters"),
    ("aws", "eks", "describe-addon"),
    ("aws", "eks", "list-addons"),
    ("aws", "eks", "describe-nodegroup"),
    ("aws", "eks", "list-nodegroups"),
    ("aws", "eks", "describe-fargate-profile"),
    ("aws", "elbv2", "describe-load-balancers"),
    ("aws", "elbv2", "describe-listeners"),
    ("aws", "elbv2", "describe-rules"),
    ("aws", "elbv2", "describe-target-groups"),
    ("aws", "elbv2", "describe-target-health"),
    ("aws", "elbv2", "describe-tags"),
    ("aws", "ec2", "describe-vpcs"),
    ("aws", "ec2", "describe-subnets"),
    ("aws", "ec2", "describe-security-groups"),
    ("aws", "ec2", "describe-route-tables"),
    ("aws", "ec2", "describe-network-interfaces"),
    ("aws", "ec2", "describe-nat-gateways"),
    ("aws", "ec2", "describe-vpc-endpoints"),
    ("aws", "ec2", "describe-instances"),
    ("aws", "ec2", "describe-availability-zones"),
    ("aws", "iam", "get-role"),
    ("aws", "iam", "get-policy"),
    ("aws", "iam", "get-policy-version"),
    ("aws", "iam", "get-role-policy"),
    ("aws", "iam", "list-attached-role-policies"),
    ("aws", "iam", "list-roles"),
    ("aws", "iam", "list-policies"),
    ("aws", "iam", "list-open-id-connect-providers"),
    ("aws", "iam", "get-open-id-connect-provider"),
    ("aws", "logs", "describe-log-groups"),
    ("aws", "logs", "describe-log-streams"),
    ("aws", "logs", "filter-log-events"),
    ("aws", "logs", "get-log-events"),
    ("aws", "cloudwatch", "get-metric-statistics"),
    ("aws", "cloudwatch", "get-metric-data"),
    ("aws", "cloudwatch", "list-metrics"),
    ("aws", "cloudwatch", "describe-alarms"),
    ("aws", "autoscaling", "describe-auto-scaling-groups"),
    ("aws", "autoscaling", "describe-policies"),
    ("aws", "autoscaling", "describe-scaling-activities"),
}

_READONLY_HELM = {
    ("helm", "list"),
    ("helm", "status"),
    ("helm", "get", "values"),
    ("helm", "get", "manifest"),
    ("helm", "get", "hooks"),
    ("helm", "get", "notes"),
    ("helm", "get", "all"),
    ("helm", "history"),
    ("helm", "search"),
    ("helm", "version"),
    ("helm", "env"),
    ("helm", "show"),
}

# ---------------------------------------------------------------------------
# Mutating command prefix patterns (always require confirmation)
# ---------------------------------------------------------------------------
_MUTATING_KUBECTL = {
    ("kubectl", "delete"),
    ("kubectl", "apply"),
    ("kubectl", "patch"),
    ("kubectl", "edit"),
    ("kubectl", "create"),
    ("kubectl", "replace"),
    ("kubectl", "rollout", "restart"),
    ("kubectl", "rollout", "undo"),
    ("kubectl", "scale"),
    ("kubectl", "cordon"),
    ("kubectl", "uncordon"),
    ("kubectl", "drain"),
    ("kubectl", "taint"),
    ("kubectl", "label"),
    ("kubectl", "annotate"),
    ("kubectl", "exec"),
    ("kubectl", "cp"),
    ("kubectl", "port-forward"),
    ("kubectl", "proxy"),
    ("kubectl", "set"),
    ("kubectl", "expose"),
    ("kubectl", "run"),
}

_MUTATING_AWS = {
    ("aws", "eks", "update-cluster-config"),
    ("aws", "eks", "update-cluster-version"),
    ("aws", "eks", "update-addon"),
    ("aws", "eks", "update-nodegroup-config"),
    ("aws", "eks", "update-nodegroup-version"),
    ("aws", "elbv2", "modify-load-balancer-attributes"),
    ("aws", "elbv2", "modify-listener"),
    ("aws", "elbv2", "modify-rule"),
    ("aws", "elbv2", "modify-target-group"),
    ("aws", "elbv2", "modify-target-group-attributes"),
    ("aws", "ec2", "authorize-security-group-ingress"),
    ("aws", "ec2", "authorize-security-group-egress"),
    ("aws", "ec2", "revoke-security-group-ingress"),
    ("aws", "ec2", "revoke-security-group-egress"),
    ("aws", "iam", "attach-role-policy"),
    ("aws", "iam", "detach-role-policy"),
    ("aws", "iam", "put-role-policy"),
    ("aws", "iam", "delete-role-policy"),
    ("aws", "autoscaling", "update-auto-scaling-group"),
    ("aws", "autoscaling", "set-desired-capacity"),
}

_MUTATING_HELM = {
    ("helm", "upgrade"),
    ("helm", "install"),
    ("helm", "uninstall"),
    ("helm", "rollback"),
    ("helm", "repo", "add"),
    ("helm", "repo", "update"),
}


def _match_prefix(command: list[str], prefix_set: set[tuple]) -> bool:
    """Return True if the command starts with any prefix tuple in the set."""
    for prefix in prefix_set:
        n = len(prefix)
        if len(command) >= n and tuple(command[:n]) == prefix:
            return True
    return False


def _contains_force_flag(command: list[str]) -> bool:
    """Return True if the command contains a --force flag."""
    return any(re.fullmatch(r"--force(=.*)?", token) for token in command)


def classify_command(command: list[str]) -> CommandClass:
    """
    Classify a command as READ_ONLY, MUTATING, or UNKNOWN.

    Read-only commands are safe to run automatically.
    Mutating commands require explicit user confirmation.
    UNKNOWN defaults to requiring confirmation.

    Args:
        command: Command tokens as a list, e.g. ["kubectl", "get", "pods", "-A"]

    Returns:
        CommandClass enum value.
    """
    if not command:
        return CommandClass.UNKNOWN

    # --force always escalates to MUTATING regardless of verb
    if _contains_force_flag(command):
        return CommandClass.MUTATING

    # Check explicit mutating prefixes first (higher priority)
    if (
        _match_prefix(command, _MUTATING_KUBECTL)
        or _match_prefix(command, _MUTATING_AWS)
        or _match_prefix(command, _MUTATING_HELM)
    ):
        return CommandClass.MUTATING

    # Check read-only prefixes
    if (
        _match_prefix(command, _READONLY_KUBECTL)
        or _match_prefix(command, _READONLY_AWS)
        or _match_prefix(command, _READONLY_HELM)
    ):
        return CommandClass.READ_ONLY

    return CommandClass.UNKNOWN


def is_safe(command: list[str]) -> bool:
    """Return True only if the command is classified as READ_ONLY."""
    return classify_command(command) == CommandClass.READ_ONLY


def requires_confirmation(command: list[str]) -> bool:
    """Return True if the command is MUTATING or UNKNOWN."""
    return classify_command(command) != CommandClass.READ_ONLY


def describe_classification(command: list[str]) -> str:
    """Human-readable classification string for display."""
    cls = classify_command(command)
    labels = {
        CommandClass.READ_ONLY: "READ-ONLY (safe)",
        CommandClass.MUTATING: "MUTATING (requires confirmation)",
        CommandClass.UNKNOWN: "UNKNOWN (requires confirmation)",
    }
    return labels[cls]
