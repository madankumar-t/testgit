"""
Fix recommendations.

This module generates FixRecommendation objects from Findings.
It never applies fixes automatically — all fixes require confirmation.
"""

from __future__ import annotations

from agent.models import Finding, FixRecommendation, FixRisk, Severity

# ---------------------------------------------------------------------------
# Fix generators
# Each generator inspects a Finding and optionally returns a FixRecommendation.
# ---------------------------------------------------------------------------


def _fix_crash_loop(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Pods" or "CrashLoopBackOff" not in finding.evidence:
        return None
    ns = finding.namespace
    pod = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Restart the Deployment owning pod '{pod}' in namespace '{ns}' "
            "to get a fresh container with the latest ConfigMap/Secret state."
        ),
        command=["kubectl", "rollout", "restart", "deployment", "-n", ns],
        risk=FixRisk.LOW,
        expected_result="All pods are replaced with fresh containers.",
        rollback_command=["kubectl", "rollout", "undo", "deployment", "-n", ns],
        rollback_description="Undo the rollout, reverting to the previous ReplicaSet.",
        namespace=ns,
        resource=pod,
    )


def _fix_image_pull(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Pods" or not any(
        kw in finding.evidence for kw in ("ImagePullBackOff", "ErrImagePull")
    ):
        return None
    ns = finding.namespace
    pod = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Describe pod '{pod}' to inspect the image pull error, "
            "then correct the image tag or ECR policy."
        ),
        command=["kubectl", "describe", "pod", pod, "-n", ns],
        risk=FixRisk.LOW,
        expected_result="Image pull error details revealed for remediation.",
        rollback_command=None,
        rollback_description="No state change — describe is read-only.",
        namespace=ns,
        resource=pod,
    )


def _fix_oom_killed(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Pods" or "OOMKilled" not in finding.evidence:
        return None
    ns = finding.namespace
    # Extract deployment name heuristically (strip pod suffix)
    deploy = "-".join(finding.resource.split("-")[:-2]) if finding.resource.count("-") >= 2 else finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Increase memory limit for Deployment '{deploy}' in namespace '{ns}' to prevent OOMKill."
        ),
        command=[
            "kubectl", "patch", "deployment", deploy, "-n", ns,
            "--type=json",
            "-p",
            '[{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"1Gi"}]',
        ],
        risk=FixRisk.MEDIUM,
        expected_result="Deployment pods restart with increased memory limit.",
        rollback_command=[
            "kubectl", "rollout", "undo", "deployment", deploy, "-n", ns,
        ],
        rollback_description="Roll back the deployment to the previous revision.",
        namespace=ns,
        resource=deploy,
    )


def _fix_pending_pod(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Pods" or "Pending" not in finding.evidence:
        return None
    ns = finding.namespace
    pod = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Describe pod '{pod}' in namespace '{ns}' to identify scheduling failure reason."
        ),
        command=["kubectl", "describe", "pod", pod, "-n", ns],
        risk=FixRisk.LOW,
        expected_result="Scheduling failure reason exposed (resources, taints, PVC, affinity).",
        rollback_command=None,
        rollback_description="No state change — describe is read-only.",
        namespace=ns,
        resource=pod,
    )


def _fix_empty_endpoints(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Services":
        return None
    ns = finding.namespace
    svc = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Service '{svc}' in namespace '{ns}' has no endpoints. "
            "Patch the service selector to match running pod labels."
        ),
        command=["kubectl", "describe", "svc", svc, "-n", ns],
        risk=FixRisk.LOW,
        expected_result="Service selector mismatch identified for correction.",
        rollback_command=None,
        rollback_description="Describe is read-only.",
        namespace=ns,
        resource=svc,
    )


def _fix_pvc_pending(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Storage":
        return None
    ns = finding.namespace
    pvc = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"PVC '{pvc}' in '{ns}' is Pending. Describe PVC to identify provisioning error."
        ),
        command=["kubectl", "describe", "pvc", pvc, "-n", ns],
        risk=FixRisk.LOW,
        expected_result="PVC provisioning error identified.",
        rollback_command=None,
        rollback_description="Describe is read-only.",
        namespace=ns,
        resource=pvc,
    )


def _fix_alb_controller_iam(finding: Finding) -> FixRecommendation | None:
    if finding.component != "AWS Load Balancer Controller":
        return None
    if "AccessDenied" not in finding.evidence and "is not authorized" not in finding.evidence:
        return None
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            "ALB controller has IAM AccessDenied errors. "
            "Restart the controller after verifying and updating the IRSA role policy."
        ),
        command=[
            "kubectl", "rollout", "restart",
            "deployment/aws-load-balancer-controller",
            "-n", "kube-system",
        ],
        risk=FixRisk.LOW,
        expected_result="Controller pods restart and pick up updated IRSA credentials.",
        rollback_command=[
            "kubectl", "rollout", "undo",
            "deployment/aws-load-balancer-controller",
            "-n", "kube-system",
        ],
        rollback_description="Undo the rollout to the previous controller version.",
        namespace="kube-system",
        resource="aws-load-balancer-controller",
    )


def _fix_coredns(finding: Finding) -> FixRecommendation | None:
    if finding.component != "DNS":
        return None
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description="Restart CoreDNS pods to clear DNS error state.",
        command=[
            "kubectl", "rollout", "restart", "deployment/coredns", "-n", "kube-system",
        ],
        risk=FixRisk.LOW,
        expected_result="CoreDNS pods restart and resume serving DNS.",
        rollback_command=[
            "kubectl", "rollout", "undo", "deployment/coredns", "-n", "kube-system",
        ],
        rollback_description="Roll CoreDNS back to the previous version.",
        namespace="kube-system",
        resource="coredns",
    )


def _fix_unhealthy_deployment(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Deployments":
        return None
    ns = finding.namespace
    deploy = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Deployment '{deploy}' in '{ns}' has fewer ready replicas than desired. "
            "Perform a rollout restart to replace unhealthy pods."
        ),
        command=["kubectl", "rollout", "restart", f"deployment/{deploy}", "-n", ns],
        risk=FixRisk.LOW,
        expected_result="All replicas replaced with fresh pods.",
        rollback_command=["kubectl", "rollout", "undo", f"deployment/{deploy}", "-n", ns],
        rollback_description="Undo rollout to the previous ReplicaSet.",
        namespace=ns,
        resource=deploy,
    )


def _fix_node_not_ready(finding: Finding) -> FixRecommendation | None:
    if finding.component != "Nodes" or "NotReady" not in finding.evidence:
        return None
    node = finding.resource
    return FixRecommendation(
        fix_id=f"{finding.fix_id}-EXEC",
        description=(
            f"Node '{node}' is NotReady. Cordon and drain the node to migrate workloads "
            "while investigating the root cause."
        ),
        command=["kubectl", "cordon", node],
        risk=FixRisk.MEDIUM,
        expected_result="Node is cordoned — no new pods will be scheduled. Existing pods remain.",
        rollback_command=["kubectl", "uncordon", node],
        rollback_description="Uncordon the node to allow scheduling again.",
        namespace="cluster",
        resource=node,
    )


# ---------------------------------------------------------------------------
# Fix registry
# ---------------------------------------------------------------------------

_FIX_GENERATORS = [
    _fix_crash_loop,
    _fix_image_pull,
    _fix_oom_killed,
    _fix_pending_pod,
    _fix_empty_endpoints,
    _fix_pvc_pending,
    _fix_alb_controller_iam,
    _fix_coredns,
    _fix_unhealthy_deployment,
    _fix_node_not_ready,
]


def generate_fixes(findings: list[Finding]) -> list[FixRecommendation]:
    """
    Generate FixRecommendation objects from a list of findings.

    Every recommendation has requires_confirmation=True.
    No fix is automatically applied — the caller must handle confirmation.

    Args:
        findings: List of Finding objects from analyzers.

    Returns:
        List of FixRecommendation objects, sorted by risk (High first).
    """
    fixes: list[FixRecommendation] = []
    seen_ids: set[str] = set()

    for finding in findings:
        for generator in _FIX_GENERATORS:
            fix = generator(finding)
            if fix is not None and fix.fix_id not in seen_ids:
                seen_ids.add(fix.fix_id)
                fixes.append(fix)

    # Sort: High risk last (so lower risk fixes surface first)
    risk_order = {FixRisk.LOW: 0, FixRisk.MEDIUM: 1, FixRisk.HIGH: 2}
    fixes.sort(key=lambda f: risk_order.get(f.risk, 99))
    return fixes


def get_fix_by_id(fixes: list[FixRecommendation], fix_id: str) -> FixRecommendation | None:
    """Return the fix with the given fix_id, or None."""
    for fix in fixes:
        if fix.fix_id == fix_id:
            return fix
    return None
