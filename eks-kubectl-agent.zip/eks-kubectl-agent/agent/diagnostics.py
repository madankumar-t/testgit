"""
EKS diagnostic orchestrator.

Runs all read-only diagnostic checks in priority order, collecting
CommandResult objects and populating a DiagnosisReport.
"""

from __future__ import annotations

import logging
from typing import Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from agent.executor import CommandExecutor, ToolNotFoundError
from agent.models import (
    ClusterContext,
    CommandResult,
    DiagnosisReport,
    ExecutedCommand,
)

logger = logging.getLogger(__name__)
console = Console()


class EksDiagnosticAgent:
    """
    Orchestrates all read-only diagnostic checks against an EKS cluster.

    Every command executed is recorded and included in the final DiagnosisReport.
    No mutating commands are ever issued here.
    """

    def __init__(
        self,
        cluster_name: str,
        region: str,
        namespace: str = "all",
        dry_run: bool = False,
        timeout: int = 60,
    ) -> None:
        self.cluster_name = cluster_name
        self.region = region
        self.namespace = namespace
        self.dry_run = dry_run
        self.timeout = timeout

        self.executor = CommandExecutor(dry_run=dry_run)
        self._step = 0
        self.report = DiagnosisReport(
            cluster_context=ClusterContext(
                cluster_name=cluster_name,
                region=region,
            )
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _run(self, command: list[str], purpose: str) -> CommandResult:
        """Execute a command, record it, and return the result."""
        self._step += 1
        result = self.executor.run(command, timeout=self.timeout)

        summary = (
            f"OK ({result.returncode})"
            if result.success
            else f"FAILED ({result.returncode}): {result.stderr[:120]}"
        )

        self.report.executed_commands.append(
            ExecutedCommand(
                step=self._step,
                command=result.command,
                purpose=purpose,
                result_summary=summary,
                success=result.success,
            )
        )
        self.report.raw_results[result.command] = result
        return result

    def _ns_flags(self) -> list[str]:
        """Return namespace flags for kubectl commands."""
        if self.namespace == "all":
            return ["-A"]
        return ["-n", self.namespace]

    # ------------------------------------------------------------------
    # Step 1 – Cluster Context
    # ------------------------------------------------------------------

    def _check_cluster_context(self) -> None:
        console.print("[bold cyan]▶ Step 1: Cluster context[/]")

        r = self._run(
            ["kubectl", "config", "current-context"],
            "Get current kubectl context",
        )
        if r.success:
            self.report.cluster_context.kubectl_context = r.stdout.strip()

        r = self._run(["kubectl", "cluster-info"], "Get cluster API server info")
        if r.success:
            for line in r.stdout.splitlines():
                if "control plane" in line.lower() or "is running at" in line.lower():
                    self.report.cluster_context.api_server = line.strip()
                    break

        r = self._run(
            ["aws", "sts", "get-caller-identity"],
            "Get AWS caller identity",
        )
        if r.success:
            import json
            try:
                identity = json.loads(r.stdout)
                self.report.cluster_context.aws_account = identity.get("Account", "unknown")
                self.report.cluster_context.aws_user = identity.get("Arn", "unknown")
            except json.JSONDecodeError:
                pass

        self._run(
            ["aws", "eks", "list-clusters", "--region", self.region],
            "List EKS clusters in region",
        )

        r = self._run(
            [
                "aws", "eks", "describe-cluster",
                "--name", self.cluster_name,
                "--region", self.region,
            ],
            "Describe EKS cluster",
        )
        if r.success:
            import json
            try:
                data = json.loads(r.stdout)
                cluster = data.get("cluster", {})
                self.report.cluster_context.kubernetes_version = cluster.get(
                    "version", "unknown"
                )
            except json.JSONDecodeError:
                pass

    # ------------------------------------------------------------------
    # Step 2 – Node Health
    # ------------------------------------------------------------------

    def _check_nodes(self) -> None:
        console.print("[bold cyan]▶ Step 2: Node health[/]")
        self._run(["kubectl", "get", "nodes", "-o", "wide"], "List nodes with details")
        self._run(["kubectl", "describe", "nodes"], "Describe all nodes")

        try:
            self.executor.assert_tool("kubectl")
            r = self._run(["kubectl", "top", "nodes"], "Node CPU/memory utilization")
        except ToolNotFoundError:
            pass

        r = self._run(["kubectl", "get", "nodes"], "Get node count and status")
        if r.success:
            lines = [l for l in r.stdout.splitlines() if l and not l.startswith("NAME")]
            self.report.cluster_context.node_count = len(lines)

    # ------------------------------------------------------------------
    # Step 3 – Namespaces
    # ------------------------------------------------------------------

    def _check_namespaces(self) -> None:
        console.print("[bold cyan]▶ Step 3: Namespaces[/]")
        r = self._run(["kubectl", "get", "namespaces"], "List all namespaces")
        if r.success:
            ns_list = []
            for line in r.stdout.splitlines():
                parts = line.split()
                if parts and not line.startswith("NAME"):
                    ns_list.append(parts[0])
            self.report.cluster_context.namespaces = ns_list

    # ------------------------------------------------------------------
    # Step 4 – Pod Health
    # ------------------------------------------------------------------

    def _check_pods(self) -> None:
        console.print("[bold cyan]▶ Step 4: Pod health[/]")
        self._run(
            ["kubectl", "get", "pods", "-A", "-o", "wide"],
            "List all pods across all namespaces",
        )
        self._run(
            ["kubectl", "get", "pods", "-A", "--field-selector=status.phase!=Running"],
            "Find non-Running pods",
        )
        self._run(
            ["kubectl", "get", "pods", "-A", "--field-selector=status.phase=Pending"],
            "Find Pending pods",
        )

    # ------------------------------------------------------------------
    # Step 5 – Workloads
    # ------------------------------------------------------------------

    def _check_workloads(self) -> None:
        console.print("[bold cyan]▶ Step 5: Workloads[/]")
        workloads = [
            (["kubectl", "get", "deploy", "-A"], "List all Deployments"),
            (["kubectl", "get", "rs", "-A"], "List all ReplicaSets"),
            (["kubectl", "get", "ds", "-A"], "List all DaemonSets"),
            (["kubectl", "get", "sts", "-A"], "List all StatefulSets"),
            (["kubectl", "get", "jobs", "-A"], "List all Jobs"),
            (["kubectl", "get", "cronjobs", "-A"], "List all CronJobs"),
        ]
        for cmd, purpose in workloads:
            self._run(cmd, purpose)

    # ------------------------------------------------------------------
    # Step 6 – Services and Endpoints
    # ------------------------------------------------------------------

    def _check_services(self) -> None:
        console.print("[bold cyan]▶ Step 6: Services and endpoints[/]")
        self._run(["kubectl", "get", "svc", "-A", "-o", "wide"], "List all Services")
        self._run(["kubectl", "get", "endpoints", "-A"], "List all Endpoints")
        self._run(["kubectl", "get", "endpointslices", "-A"], "List all EndpointSlices")

    # ------------------------------------------------------------------
    # Step 7 – Ingress and ALB
    # ------------------------------------------------------------------

    def _check_ingress(self) -> None:
        console.print("[bold cyan]▶ Step 7: Ingress and ALB resources[/]")
        self._run(["kubectl", "get", "ingress", "-A"], "List all Ingress resources")
        self._run(["kubectl", "get", "ingressclass"], "List IngressClasses")
        self._run(
            ["kubectl", "get", "targetgroupbindings", "-A"],
            "List TargetGroupBindings (AWS LBC CRD)",
        )
        self._run(
            ["aws", "elbv2", "describe-load-balancers", "--region", self.region],
            "Describe all ALBs/NLBs",
        )
        self._run(
            ["aws", "elbv2", "describe-target-groups", "--region", self.region],
            "Describe all target groups",
        )

    # ------------------------------------------------------------------
    # Step 8 – AWS Load Balancer Controller
    # ------------------------------------------------------------------

    def _check_alb_controller(self) -> None:
        console.print("[bold cyan]▶ Step 8: AWS Load Balancer Controller[/]")
        self._run(
            ["kubectl", "get", "deploy", "-n", "kube-system", "aws-load-balancer-controller"],
            "Check ALB controller Deployment",
        )
        self._run(
            ["kubectl", "describe", "deploy", "-n", "kube-system", "aws-load-balancer-controller"],
            "Describe ALB controller Deployment",
        )
        self._run(
            [
                "kubectl", "logs", "-n", "kube-system",
                "deployment/aws-load-balancer-controller",
                "--tail=300",
            ],
            "Tail ALB controller logs (300 lines)",
        )
        self._run(
            ["kubectl", "get", "sa", "aws-load-balancer-controller", "-n", "kube-system", "-o", "yaml"],
            "Get ALB controller ServiceAccount (IRSA annotation)",
        )
        self._run(
            ["helm", "list", "-n", "kube-system"],
            "List Helm releases in kube-system",
        )

    # ------------------------------------------------------------------
    # Step 9 – Networking / VPC CNI
    # ------------------------------------------------------------------

    def _check_networking(self) -> None:
        console.print("[bold cyan]▶ Step 9: Networking / VPC CNI[/]")
        self._run(
            ["kubectl", "get", "pods", "-n", "kube-system", "-o", "wide"],
            "List kube-system pods",
        )
        self._run(
            ["kubectl", "get", "ds", "-n", "kube-system"],
            "List kube-system DaemonSets",
        )
        self._run(
            ["kubectl", "logs", "-n", "kube-system", "-l", "k8s-app=aws-node", "--tail=200"],
            "Tail VPC CNI (aws-node) logs",
        )
        self._run(
            ["kubectl", "describe", "ds", "aws-node", "-n", "kube-system"],
            "Describe aws-node DaemonSet",
        )
        self._run(
            ["aws", "ec2", "describe-vpcs", "--region", self.region],
            "Describe VPCs",
        )
        self._run(
            ["aws", "ec2", "describe-subnets", "--region", self.region],
            "Describe subnets",
        )
        self._run(
            ["aws", "ec2", "describe-security-groups", "--region", self.region],
            "Describe security groups",
        )
        self._run(
            ["aws", "ec2", "describe-route-tables", "--region", self.region],
            "Describe route tables",
        )
        self._run(
            ["aws", "ec2", "describe-nat-gateways", "--region", self.region],
            "Describe NAT gateways",
        )
        self._run(
            ["aws", "ec2", "describe-vpc-endpoints", "--region", self.region],
            "Describe VPC endpoints",
        )

    # ------------------------------------------------------------------
    # Step 10 – DNS / CoreDNS
    # ------------------------------------------------------------------

    def _check_dns(self) -> None:
        console.print("[bold cyan]▶ Step 10: DNS / CoreDNS[/]")
        self._run(
            ["kubectl", "get", "pods", "-n", "kube-system", "-l", "k8s-app=kube-dns"],
            "List CoreDNS pods",
        )
        self._run(
            ["kubectl", "logs", "-n", "kube-system", "-l", "k8s-app=kube-dns", "--tail=200"],
            "Tail CoreDNS logs",
        )
        self._run(
            ["kubectl", "get", "svc", "-n", "kube-system", "kube-dns"],
            "Get kube-dns Service",
        )
        self._run(
            ["kubectl", "describe", "configmap", "coredns", "-n", "kube-system"],
            "Describe CoreDNS ConfigMap",
        )

    # ------------------------------------------------------------------
    # Step 11 – Storage
    # ------------------------------------------------------------------

    def _check_storage(self) -> None:
        console.print("[bold cyan]▶ Step 11: Storage / PV / PVC / EBS CSI[/]")
        self._run(["kubectl", "get", "pv"], "List PersistentVolumes")
        self._run(["kubectl", "get", "pvc", "-A"], "List PersistentVolumeClaims")
        self._run(["kubectl", "get", "storageclass"], "List StorageClasses")
        self._run(
            [
                "kubectl", "logs", "-n", "kube-system",
                "-l", "app.kubernetes.io/name=aws-ebs-csi-driver",
                "--tail=200",
            ],
            "Tail EBS CSI driver logs",
        )

    # ------------------------------------------------------------------
    # Step 12 – Autoscaling
    # ------------------------------------------------------------------

    def _check_autoscaling(self) -> None:
        console.print("[bold cyan]▶ Step 12: Autoscaling[/]")
        self._run(["kubectl", "get", "hpa", "-A"], "List HorizontalPodAutoscalers")
        self._run(["kubectl", "get", "pdb", "-A"], "List PodDisruptionBudgets")
        self._run(["kubectl", "top", "pods", "-A"], "Pod CPU/memory utilization")
        self._run(
            ["aws", "autoscaling", "describe-auto-scaling-groups", "--region", self.region],
            "Describe Auto Scaling Groups",
        )
        r = self._run(
            [
                "aws", "eks", "list-nodegroups",
                "--cluster-name", self.cluster_name,
                "--region", self.region,
            ],
            "List EKS nodegroups",
        )
        if r.success:
            import json
            try:
                data = json.loads(r.stdout)
                for ng in data.get("nodegroups", []):
                    self._run(
                        [
                            "aws", "eks", "describe-nodegroup",
                            "--cluster-name", self.cluster_name,
                            "--nodegroup-name", ng,
                            "--region", self.region,
                        ],
                        f"Describe nodegroup: {ng}",
                    )
            except json.JSONDecodeError:
                pass

        # Check for Karpenter
        self._run(
            ["kubectl", "get", "pods", "-n", "karpenter"],
            "Check Karpenter pods (if installed)",
        )

    # ------------------------------------------------------------------
    # Step 13 – IAM / IRSA
    # ------------------------------------------------------------------

    def _check_iam_irsa(self) -> None:
        console.print("[bold cyan]▶ Step 13: IAM / IRSA[/]")
        self._run(
            [
                "aws", "eks", "describe-cluster",
                "--name", self.cluster_name,
                "--region", self.region,
                "--query", "cluster.identity.oidc.issuer",
            ],
            "Get OIDC issuer URL",
        )
        self._run(
            ["aws", "iam", "list-open-id-connect-providers"],
            "List OIDC identity providers",
        )

    # ------------------------------------------------------------------
    # Step 14 – Events
    # ------------------------------------------------------------------

    def _check_events(self) -> None:
        console.print("[bold cyan]▶ Step 14: Kubernetes events[/]")
        self._run(
            ["kubectl", "get", "events", "-A", "--sort-by=.lastTimestamp"],
            "Get all events sorted by time",
        )

    # ------------------------------------------------------------------
    # Step 15 – EKS Add-ons
    # ------------------------------------------------------------------

    def _check_addons(self) -> None:
        console.print("[bold cyan]▶ Step 15: EKS managed add-ons[/]")
        addons = ["vpc-cni", "coredns", "kube-proxy", "aws-ebs-csi-driver"]
        for addon in addons:
            self._run(
                [
                    "aws", "eks", "describe-addon",
                    "--cluster-name", self.cluster_name,
                    "--addon-name", addon,
                    "--region", self.region,
                ],
                f"Describe add-on: {addon}",
            )

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run_full_diagnosis(self) -> DiagnosisReport:
        """
        Execute all diagnostic steps and return a populated DiagnosisReport.

        All commands are read-only. No cluster state is modified.
        """
        console.rule("[bold green]EKS Troubleshooting Agent — Diagnostic Run[/]")
        console.print(
            f"  Cluster : [bold]{self.cluster_name}[/]\n"
            f"  Region  : [bold]{self.region}[/]\n"
            f"  NS scope: [bold]{self.namespace}[/]"
        )
        console.print()

        steps = [
            self._check_cluster_context,
            self._check_nodes,
            self._check_namespaces,
            self._check_pods,
            self._check_workloads,
            self._check_services,
            self._check_ingress,
            self._check_alb_controller,
            self._check_networking,
            self._check_dns,
            self._check_storage,
            self._check_autoscaling,
            self._check_iam_irsa,
            self._check_events,
            self._check_addons,
        ]

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Running diagnostics...", total=len(steps))
            for step_fn in steps:
                progress.update(task, description=f"[cyan]{step_fn.__name__}[/]")
                try:
                    step_fn()
                except Exception as exc:  # noqa: BLE001
                    logger.error("Error in %s: %s", step_fn.__name__, exc)
                    console.print(f"[red]  ✗ {step_fn.__name__} failed: {exc}[/]")
                progress.advance(task)

        console.rule("[bold green]Diagnostic complete[/]")
        return self.report
