# EKS Troubleshooting Agent — Deployment Guide

## Overview

Three independently deployable components, all managed from a **single `terraform apply`**:

| Component | Technology | Where |
|-----------|-----------|-------|
| **Spoke IAM roles** | CloudFormation (deployed by Terraform) | Every member account |
| **Backend** | Lambda + API Gateway + DynamoDB | Central AWS account (Terraform) |
| **Frontend** | Next.js 14 static export | S3 + CloudFront (Terraform + CLI) |
| **CLI Agent** | Python 3.12 + Typer | Local workstation / bastion |

```
You run once:   terraform apply   (from the master / central account)
                        │
         ┌──────────────┼──────────────────────────┐
         ▼              ▼                           ▼
  Spoke IAM roles   Central backend          S3 + CloudFront
  deployed into     ─────────────            (frontend hosting)
  every member      Lambda (VPC)
  account via       API Gateway
  CloudFormation    DynamoDB
         │
         │  sts:AssumeRole spoke role
         ▼
  Member Acc 1 ── Private EKS cluster(s)
  Member Acc 2 ── Private EKS cluster(s)
  Member Acc N ── Private EKS cluster(s)
```

---

## Prerequisites

| Tool | Min Version | Notes |
|------|-------------|-------|
| Python | 3.12+ | Terraform calls it to build the Lambda layer and deploy spoke roles |
| Node.js | 18+ | Frontend build |
| AWS CLI v2 | 2.15+ | S3 sync, CloudFront invalidation |
| Terraform | 1.6+ | All infrastructure |
| kubectl | 1.29+ | CLI agent only |
| helm | 3.x | CLI agent only (optional) |
| boto3 | 1.34+ | Installed by `pip install boto3` — used by deploy_spoke_roles.py |

**IAM permissions for the deployer identity (central account):**

```
# Lambda / API GW / DynamoDB / S3 / CloudFront
lambda:* apigateway:* dynamodb:* s3:* cloudfront:* logs:* xray:*

# IAM (to create Lambda execution role + spoke roles)
iam:CreateRole iam:AttachRolePolicy iam:PutRolePolicy
iam:GetRole iam:PassRole iam:CreateInstanceProfile

# EKS / VPC read (for Lambda policy scoping)
eks:* ec2:Describe* elasticloadbalancing:Describe*
autoscaling:Describe* sts:GetCallerIdentity sts:AssumeRole

# CloudFormation (to deploy spoke stacks in member accounts)
cloudformation:CreateStack cloudformation:UpdateStack
cloudformation:DescribeStacks cloudformation:DeleteStack
```

**The deployer also needs to be able to assume the bootstrap role in each member account** (see Step 2).

---

## Step 1 — Clone and configure

```bash
git clone <repo-url>
cd eks-kubectl-agent
```

```bash
# Install the deploy_spoke_roles.py dependency
pip install boto3
```

Copy the example tfvars and fill in your values:

```bash
cd infrastructure/terraform
cp terraform.tfvars.example terraform.tfvars
```

Edit `terraform.tfvars`:

```hcl
# ── Where to deploy the central app ──────────────────────────────────────
aws_region  = "us-east-1"
environment = "prod"

# ── VPC: private subnets for Lambda ENIs ─────────────────────────────────
# These subnets must have network paths (TGW / VPC peering) to every
# member account VPC where EKS private endpoints are hosted.
vpc_subnet_ids         = ["subnet-aaa11111", "subnet-bbb22222"]
vpc_security_group_ids = ["sg-ccc33333"]

# ── Member accounts ───────────────────────────────────────────────────────
# Add every AWS account that contains EKS clusters you want to manage.
# Key = 12-digit account ID,  Value = label shown in the UI.
spoke_accounts = {
  "123456789012" = "Production"
  "234567890123" = "Staging"
  "345678901234" = "Dev"
}

# Role that Terraform assumes in each member account to deploy the spoke stack.
# AWS Organizations creates this role automatically when accounts are provisioned
# through the console, Control Tower, or account factory.
bootstrap_role_name = "OrganizationAccountAccessRole"

# Set false only if you are managing spoke roles manually.
deploy_spoke_roles = true

# ── Leave these at defaults unless you need to change them ───────────────
spoke_role_name = "eks-agent-spoke-role"
eks_regions     = "us-east-1,us-east-2,us-west-2,eu-west-1,eu-central-1,ap-southeast-1"
cors_origin     = "*"     # tighten after Step 3
```

---

## Step 2 — Verify bootstrap access to member accounts

Terraform deploys the spoke role by assuming `OrganizationAccountAccessRole` in each
member account. Confirm your current identity can do this before running `terraform apply`:

```bash
# Test for each member account
aws sts assume-role \
  --role-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/OrganizationAccountAccessRole \
  --role-session-name test-access \
  --query "AssumedRoleUser.Arn" --output text
```

Expected output: `arn:aws:sts::<MEMBER_ACCOUNT_ID>:assumed-role/OrganizationAccountAccessRole/test-access`

> If this fails, verify:
> - The deployer identity is in the **master/management account** of the Organization
> - The member account was provisioned through AWS Organizations (not created independently)
> - If created independently, manually create `OrganizationAccountAccessRole` in the member account
>   (trust policy allowing `arn:aws:iam::<CENTRAL_ACCOUNT_ID>:root`)

---

## Step 3 — Deploy everything with Terraform

```bash
cd infrastructure/terraform

terraform init

# Review all planned changes
terraform plan

# Deploy — this does all of the following in one run:
#  1. Creates spoke IAM roles in every member account (CloudFormation)
#  2. Builds the Lambda layer (pip install → .layer_build/)
#  3. Packages and deploys all Lambda functions
#  4. Creates API Gateway, DynamoDB, IAM roles
#  5. Creates S3 bucket and CloudFront distribution (frontend hosting)
terraform apply
```

Terraform output after apply:

```
cloudfront_url          = "https://dXXXXXXXXXXX.cloudfront.net"
api_gateway_stage_url   = "https://abc123.execute-api.us-east-1.amazonaws.com/prod"
s3_bucket_name          = "eks-kubectl-agent-prod-frontend-111122223333"
spoke_role_arns         = {
  "123456789012 (Production)" = "arn:aws:iam::123456789012:role/eks-agent-spoke-role"
  "234567890123 (Staging)"    = "arn:aws:iam::234567890123:role/eks-agent-spoke-role"
}
registered_accounts     = { "123456789012" = "Production", ... }
```

Save `cloudfront_url` — you need it in Step 4.

---

## Step 4 — Grant the spoke role access to each EKS cluster

The spoke role is now created in each member account, but the EKS cluster must
also recognise it. Do this **once per cluster** in each member account.

### Option A — EKS Access Entries (recommended, EKS 1.29+)

```bash
# Run in the member account (switch profile / role first)
aws eks create-access-entry \
  --cluster-name <CLUSTER_NAME> \
  --principal-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role \
  --type STANDARD \
  --region <REGION>

aws eks associate-access-policy \
  --cluster-name <CLUSTER_NAME> \
  --principal-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy \
  --access-scope type=cluster \
  --region <REGION>
```

### Option B — aws-auth ConfigMap (EKS < 1.29)

```bash
kubectl edit configmap aws-auth -n kube-system
```

Add under `mapRoles`:

```yaml
- rolearn: arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role
  username: eks-agent
  groups:
    - eks-agent-readonly
```

Then create the ClusterRole binding:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: eks-agent-readonly
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: view          # built-in read-only role
subjects:
  - kind: Group
    name: eks-agent-readonly
    apiGroup: rbac.authorization.k8s.io
```

```bash
kubectl apply -f eks-agent-rbac.yaml
```

> Repeat for every cluster in every member account.

---

## Step 5 — Deploy the frontend

### 5.1 Install dependencies

```bash
cd eks-kubectl-agent/frontend
npm install
```

### 5.2 Build

Replace `<CLOUDFRONT_URL>` with the value from Step 3 output:

```bash
# Linux / macOS
NEXT_PUBLIC_API_URL=https://<CLOUDFRONT_URL>/api/v1 npm run build

# Windows PowerShell
$env:NEXT_PUBLIC_API_URL="https://<CLOUDFRONT_URL>/api/v1"; npm run build
```

Output is written to `frontend/out/`.

### 5.3 Upload to S3

```bash
# Get bucket name from Terraform output
BUCKET=$(cd ../infrastructure/terraform && terraform output -raw s3_bucket_name)

# Hashed assets — long-lived cache (1 year)
aws s3 sync out/_next/static/ s3://$BUCKET/_next/static/ \
  --cache-control "max-age=31536000,public,immutable" \
  --delete

# Everything else — no cache (so re-deploys take effect immediately)
aws s3 sync out/ s3://$BUCKET/ \
  --cache-control "max-age=0,no-cache,no-store,must-revalidate" \
  --exclude "_next/static/*" \
  --delete
```

Windows PowerShell:

```powershell
$BUCKET = (terraform -chdir=..\infrastructure\terraform output -raw s3_bucket_name)

aws s3 sync out\_next\static\ "s3://$BUCKET/_next/static/" `
  --cache-control "max-age=31536000,public,immutable" --delete

aws s3 sync out\ "s3://$BUCKET/" `
  --cache-control "max-age=0,no-cache,no-store,must-revalidate" `
  --exclude "_next/static/*" --delete
```

### 5.4 Invalidate CloudFront

```bash
CF_ID=$(cd ../infrastructure/terraform && terraform output -raw cloudfront_distribution_id 2>/dev/null)
aws cloudfront create-invalidation --distribution-id $CF_ID --paths "/*"
```

### 5.5 Tighten CORS

Re-apply Terraform with the exact CloudFront URL to restrict API access to your domain only:

```bash
cd infrastructure/terraform
terraform apply -var="cors_origin=https://<CLOUDFRONT_URL>"
```

---

## Step 6 — Verify the deployment

Open `https://<CLOUDFRONT_URL>` in a browser.

1. **Dashboard** — should load with zero diagnoses (expected for first deploy)
2. Navigate to **New Diagnosis**
3. The **Account** dropdown should list all accounts from `spoke_accounts`
4. Selecting an account + region should populate the **Cluster** dropdown
5. Run a diagnosis — status should move `pending → running → complete`

### Quick API smoke test

```bash
API=https://<CLOUDFRONT_URL>/api/v1

# List registered accounts
curl -s "$API/accounts" | python -m json.tool

# List clusters in an account
curl -s "$API/clusters?account_id=123456789012&region=us-east-1" | python -m json.tool
```

---

## Step 7 — CLI Agent (optional, local use)

The CLI runs on any host with **direct network access** to the private EKS API endpoint
(VPN, AWS Client VPN, Direct Connect, or an EC2 bastion in the same VPC).

### 7.1 Install

```bash
cd eks-kubectl-agent

python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 7.2 Authenticate

```bash
# Assume the spoke role for the target account
aws sts assume-role \
  --role-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role \
  --role-session-name local-diag \
  --query "Credentials" --output json

# Update kubeconfig
aws eks update-kubeconfig \
  --name <CLUSTER_NAME> \
  --region <REGION> \
  --role-arn arn:aws:iam::<MEMBER_ACCOUNT_ID>:role/eks-agent-spoke-role
```

### 7.3 Run

```bash
# Full diagnosis on current context
python main.py diagnose

# Explicit cluster
python main.py diagnose --cluster my-cluster --region us-east-1

# Scope to one namespace
python main.py diagnose --namespace kube-system

# Apply a fix (prompts for confirmation)
python main.py fix FIX-001

# Generate Markdown incident report
python main.py report
```

---

## Updating

### Add a new member account

1. Add the account to `spoke_accounts` in `terraform.tfvars`
2. Run `terraform apply` — spoke role is created automatically
3. Add the spoke role to the cluster's access entries (Step 4)

### Update Lambda code

```bash
cd infrastructure/terraform
terraform apply   # archive_file detects source changes and redeploys automatically
```

### Update frontend

```bash
cd frontend
npm run build
# re-run Step 5.3 and 5.4
```

---

## Networking requirements

```
Central VPC (Lambda)
       │
       │  HTTPS 443 egress
       │
  ┌────▼─────────────────────┐
  │  Transit Gateway /        │
  │  VPC Peering              │
  └────┬─────────────────────┘
       │
  ┌────▼────────────┐   ┌─────────────────┐   ┌─────────────────┐
  │ Member VPC A    │   │ Member VPC B     │   │ Member VPC N    │
  │ EKS private EP  │   │ EKS private EP   │   │ EKS private EP  │
  └─────────────────┘   └─────────────────┘   └─────────────────┘
```

| Requirement | Details |
|-------------|---------|
| Lambda VPC | Private subnets in at least 2 AZs for ENI placement |
| Egress HTTPS (443) | Lambda SG must allow outbound 443 to spoke VPC CIDRs |
| EKS private endpoint | Each cluster must have `endpointPrivateAccess: true` |
| DynamoDB access | VPC Gateway Endpoint for DynamoDB recommended (avoids NAT charges) |
| Public AWS APIs | NAT Gateway or VPC Interface Endpoints for STS, EKS, EC2, ELB, IAM |

---

## Variable reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `aws_region` | no | `us-east-1` | Central account region |
| `environment` | no | `prod` | `dev` / `staging` / `prod` |
| `project` | no | `eks-kubectl-agent` | Resource name prefix |
| `vpc_subnet_ids` | **yes** | — | Private subnet IDs for Lambda ENIs |
| `vpc_security_group_ids` | **yes** | — | SG IDs for Lambda ENIs |
| `spoke_accounts` | no | `{}` | Map of account ID → label |
| `deploy_spoke_roles` | no | `true` | Auto-deploy spoke CloudFormation stacks |
| `bootstrap_role_name` | no | `OrganizationAccountAccessRole` | Role to assume in member accounts |
| `spoke_role_name` | no | `eks-agent-spoke-role` | Role name created in member accounts |
| `eks_regions` | no | 10 regions | Regions scanned by cluster discovery |
| `cors_origin` | no | `*` | Lock to CloudFront URL in production |
| `api_throttle_rate` | no | `20` | API GW requests/second |
| `api_throttle_burst` | no | `50` | API GW burst limit |
| `dynamodb_table_name` | no | `eks-agent-jobs` | DynamoDB table name |

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `deploy_spoke_roles.py` — `AccessDenied` | Deployer cannot assume `OrganizationAccountAccessRole` | Confirm deployer is in master account; verify member account was created via Organizations |
| Account dropdown empty in UI | `SPOKE_ACCOUNT_IDS` env var not set | Add `spoke_accounts` to tfvars and re-apply Terraform |
| Cluster dropdown empty | Lambda cannot assume spoke role | Confirm `deploy_spoke_roles` ran successfully; check CloudWatch logs for `list_clusters` |
| Lambda `dial tcp: i/o timeout` | Lambda VPC cannot reach cluster private endpoint | Add TGW / VPC peering + route between central and spoke VPCs |
| Lambda `not authorized` from Kubernetes | Spoke role not in `aws-auth` / EKS access entry | Complete Step 4 for that cluster |
| Diagnosis stuck in `pending` | Worker Lambda not invoked | Check `diagnose_start` CloudWatch logs; verify `lambda:InvokeFunction` IAM permission |
| Layer `exec format error` | Wrong CPU architecture | `build_layer.py` uses `--platform manylinux2014_aarch64`; ensure pip ≥ 22 |
| Frontend blank page / 404 | Wrong `NEXT_PUBLIC_API_URL` | Rebuild with the correct CloudFront URL in Step 5.2 |
| API returns 403 CORS | `cors_origin` mismatch | Re-apply Terraform: `terraform apply -var="cors_origin=https://your-cf-url"` |
| `ModuleNotFoundError: shared` | Lambda layer not built | Run `terraform apply`; check `null_resource.build_layer` local-exec output |


| Component | Technology | Hosting |
|-----------|-----------|---------|
| **CLI Agent** | Python 3.12 + Typer | Local workstation / bastion / Cloud9 (needs VPN/network path to cluster) |
| **Backend** | Lambda + API Gateway + DynamoDB | AWS Serverless — **Terraform only** |
| **Frontend** | Next.js 14 (static export) | S3 + CloudFront |

**Architecture overview**

```
Central AWS Account
├── Lambda functions  (VPC-attached, private subnets)
├── API Gateway HTTP API
└── DynamoDB (job storage, 24 h TTL)

Spoke Account A          Spoke Account B          Spoke Account N
└── eks-agent-spoke-role └── eks-agent-spoke-role └── eks-agent-spoke-role
    └── Private EKS          └── Private EKS          └── Private EKS

CloudFront → S3 (static frontend)  →  API Gateway  →  Lambda
                                                            │
                                               sts:AssumeRole (spoke role)
                                                            │
                                               Kubernetes API (private endpoint)
                                               boto3 (EKS / EC2 / ELB / IAM …)
```

---

## Prerequisites

| Tool | Min Version | Purpose |
|------|-------------|---------|
| Python | 3.12 | CLI agent + Lambda layer build script |
| Node.js | 18 | Frontend build |
| AWS CLI v2 | 2.15 | S3 sync, CloudFront invalidation |
| Terraform | 1.6 | Backend + infrastructure deployment |
| kubectl | 1.29 | CLI agent (must be on PATH) |
| helm | 3.x | CLI agent (optional — checks skip if missing) |

**Deployer IAM permissions required (central account):**

```
eks:* ec2:Describe* elasticloadbalancing:Describe*
iam:CreateRole iam:AttachRolePolicy iam:GetRole iam:PassRole
sts:GetCallerIdentity lambda:* apigateway:*
s3:* cloudfront:* dynamodb:* logs:* xray:*
```

---

## Step 0 — Deploy Spoke Roles in Every Target Account

Do this **once per spoke account** before deploying the central stack.
The Lambda functions assume `arn:aws:iam::{account_id}:role/eks-agent-spoke-role`
in each target account. The cluster's `aws-auth` ConfigMap (or EKS access entries)
must map this role to a Kubernetes group with sufficient read permissions.

```bash
# Run in each spoke account (repeat for every account that has clusters)
aws cloudformation deploy \
  --stack-name eks-agent-spoke \
  --template-file infrastructure/member-account/spoke-role.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides CentralAccountId=<CENTRAL_ACCOUNT_ID> \
  --region <REGION>

# Note the output role ARN
aws cloudformation describe-stacks \
  --stack-name eks-agent-spoke \
  --query "Stacks[0].Outputs[?OutputKey=='SpokeRoleArn'].OutputValue" \
  --output text
```

**Add the spoke role to the cluster's aws-auth ConfigMap:**

```yaml
# kubectl edit configmap aws-auth -n kube-system
mapRoles:
  - rolearn: arn:aws:iam::<SPOKE_ACCOUNT_ID>:role/eks-agent-spoke-role
    username: eks-agent
    groups:
      - eks-agent-readonly   # bind to a ClusterRole with get/list/watch + pod log access
```

Or, if using EKS access entries (recommended for EKS 1.29+):

```bash
aws eks create-access-entry \
  --cluster-name <CLUSTER_NAME> \
  --principal-arn arn:aws:iam::<SPOKE_ACCOUNT_ID>:role/eks-agent-spoke-role \
  --type STANDARD \
  --region <REGION>

aws eks associate-access-policy \
  --cluster-name <CLUSTER_NAME> \
  --principal-arn arn:aws:iam::<SPOKE_ACCOUNT_ID>:role/eks-agent-spoke-role \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy \
  --access-scope type=cluster \
  --region <REGION>
```

---

## Step 1 — Deploy Backend (Terraform)

The Terraform configuration is in `infrastructure/terraform/`.
It deploys: Lambda functions, API Gateway, DynamoDB, IAM roles, Lambda layer,
S3 bucket, CloudFront distribution.

Terraform **automatically builds the Lambda layer** via a `null_resource` that calls
`backend/scripts/build_layer.py` whenever `requirements.txt` or `shared/*.py` changes.
Function handler code is zipped directly from source by `archive_file` data sources.
No manual build steps are needed.

### 1.1 Network requirements

Lambda functions run in **private subnets** in the central VPC.
Before deploying, you need:

- At least 2 private subnets (different AZs) for Lambda ENI placement
- A security group allowing **egress HTTPS (443)** to spoke account VPC CIDRs
  (via Transit Gateway, VPC peering, or PrivateLink)
- A **VPC Gateway Endpoint for DynamoDB** (free — avoids NAT charges for DynamoDB traffic)
- A **NAT Gateway** (or VPC interface endpoints) for Lambda to call public AWS APIs
  (STS, EKS, EC2, ELB, IAM, CloudWatch) — required because Lambda is VPC-attached

```bash
# Verify the subnets and SG exist before running terraform apply
aws ec2 describe-subnets --subnet-ids subnet-aaa subnet-bbb \
  --query "Subnets[].{ID:SubnetId,AZ:AvailabilityZone,VPC:VpcId}" --output table

aws ec2 describe-security-groups --group-ids sg-xxx \
  --query "SecurityGroups[].{ID:GroupId,Name:GroupName}" --output table
```

### 1.2 Deploy

```bash
cd eks-kubectl-agent/infrastructure/terraform

terraform init

# Plan first — review all resources before creating them
terraform plan \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var='vpc_subnet_ids=["subnet-aaa","subnet-bbb"]' \
  -var='vpc_security_group_ids=["sg-xxx"]' \
  -var="cors_origin=*"

# Apply
terraform apply \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var='vpc_subnet_ids=["subnet-aaa","subnet-bbb"]' \
  -var='vpc_security_group_ids=["sg-xxx"]' \
  -var="cors_origin=*"
```

Terraform will:
1. Build the Lambda layer (pip install + copy `shared/` → `.layer_build/`)
2. Zip each function handler from its source directory
3. Create DynamoDB table, IAM roles, Lambda functions, API Gateway, S3 bucket, CloudFront

### 1.3 Note the outputs

```bash
terraform output api_gateway_url      # e.g. https://abc123.execute-api.us-east-1.amazonaws.com/prod
terraform output cloudfront_url       # e.g. https://dXXXXXXXXXXX.cloudfront.net
terraform output s3_bucket_name
```

Save the **CloudFront URL** — it is your `NEXT_PUBLIC_API_URL` base.

### 1.4 Re-deploy backend after code changes

```bash
# Terraform detects source file changes via archive_file content hashes
terraform apply \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var='vpc_subnet_ids=["subnet-aaa","subnet-bbb"]' \
  -var='vpc_security_group_ids=["sg-xxx"]' \
  -var="cors_origin=https://dXXXXXXXXXXX.cloudfront.net"
```

### 1.5 Tear down

```bash
terraform destroy \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var='vpc_subnet_ids=["subnet-aaa","subnet-bbb"]' \
  -var='vpc_security_group_ids=["sg-xxx"]'
```

> **Tip:** Use a `terraform.tfvars` file to avoid repeating variables:
>
> ```hcl
> # infrastructure/terraform/terraform.tfvars  (do NOT commit to git)
> aws_region             = "us-east-1"
> environment            = "prod"
> spoke_role_name        = "eks-agent-spoke-role"
> vpc_subnet_ids         = ["subnet-aaa", "subnet-bbb"]
> vpc_security_group_ids = ["sg-xxx"]
> cors_origin            = "https://dXXXXXXXXXXX.cloudfront.net"
> ```

---

## Step 2 — Deploy Frontend (S3 + CloudFront)

### 2.1 Install dependencies

```bash
cd eks-kubectl-agent/frontend
npm install
```

### 2.2 Configure environment

```bash
# Set the API base URL to the CloudFront domain (proxies /api/* to API Gateway)
echo "NEXT_PUBLIC_API_URL=https://dXXXXXXXXXXX.cloudfront.net/api/v1" > .env.local
```

### 2.3 Build static export

```bash
npm run build
# Output: frontend/out/
```

### 2.4 Upload to S3

Two-pass sync: hashed static assets get a 1-year immutable cache;
HTML and manifests get no-cache so re-deploys are instant.

```bash
BUCKET=$(cd ../infrastructure/terraform && terraform output -raw s3_bucket_name)

# Pass 1 — Next.js hashed assets (JS/CSS) — immutable
aws s3 sync out/_next/static/ s3://$BUCKET/_next/static/ \
  --cache-control "max-age=31536000,public,immutable" \
  --delete

# Pass 2 — everything else — no cache
aws s3 sync out/ s3://$BUCKET/ \
  --cache-control "max-age=0,no-cache,no-store,must-revalidate" \
  --exclude "_next/static/*" \
  --delete
```

### 2.5 Invalidate CloudFront cache

```bash
CF_ID=$(cd ../infrastructure/terraform && terraform output -raw cloudfront_distribution_id 2>/dev/null || \
  aws cloudfront list-distributions \
    --query "DistributionList.Items[?Comment=='eks-kubectl-agent-prod frontend'].Id" \
    --output text)

aws cloudfront create-invalidation --distribution-id $CF_ID --paths "/*"
```

### 2.6 Lock down CORS

Once the frontend is deployed, re-apply Terraform with the real CloudFront URL to
restrict API Gateway CORS to that domain only:

```bash
cd infrastructure/terraform
terraform apply \
  -var="cors_origin=https://dXXXXXXXXXXX.cloudfront.net" \
  # ... other vars or use terraform.tfvars
```

---

## Step 3 — CLI Agent (Local / Bastion)

The Python CLI runs on any host that has **network access to the private EKS API endpoints**
(e.g. via VPN, AWS Client VPN, Direct Connect, or an EC2 bastion in the VPC).

### 3.1 Install

```bash
cd eks-kubectl-agent

python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 3.2 Authenticate

```bash
# SSO (most common for multi-account)
aws sso login --profile <central-account-profile>

# Or assume a spoke role directly
aws sts assume-role \
  --role-arn arn:aws:iam::<SPOKE_ACCOUNT>:role/eks-agent-spoke-role \
  --role-session-name local-diag \
  --query "Credentials" --output json

# Update kubeconfig for the target cluster
aws eks update-kubeconfig \
  --name <CLUSTER_NAME> \
  --region <REGION> \
  --role-arn arn:aws:iam::<SPOKE_ACCOUNT>:role/eks-agent-spoke-role
```

### 3.3 Run a diagnosis

```bash
# Full cluster diagnosis (uses current kubeconfig context)
python main.py diagnose

# Explicit cluster + region
python main.py diagnose --cluster my-eks-cluster --region us-east-1

# Scope to one namespace
python main.py diagnose --namespace kube-system
```

### 3.4 Apply a fix (with confirmation)

```bash
# List fix recommendations from last diagnosis
python main.py fix --list

# Apply a specific fix — always prompts for confirmation
python main.py fix FIX-001
```

### 3.5 Generate incident report

```bash
python main.py report
# Writes: eks-incident-report.md
```

---

## End-to-End Deployment Order

```
1. Deploy spoke roles in every target account         (Step 0)
      ↓
2. terraform apply  — backend + S3 + CloudFront       (Step 1)
      ↓  note CloudFront URL
3. Set NEXT_PUBLIC_API_URL and npm run build          (Step 2)
      ↓
4. aws s3 sync + CloudFront invalidation              (Step 2)
      ↓
5. Re-run terraform apply with CorsOrigin=<CF URL>    (Step 2.6)
```

---

## Variable Reference

| Terraform variable | Required | Default | Description |
|--------------------|----------|---------|-------------|
| `aws_region` | no | `us-east-1` | Central account region |
| `environment` | no | `prod` | `dev` / `staging` / `prod` |
| `project` | no | `eks-kubectl-agent` | Resource name prefix |
| `spoke_role_name` | no | `eks-agent-spoke-role` | IAM role name in spoke accounts |
| `vpc_subnet_ids` | **yes** | — | Private subnet IDs for Lambda ENIs |
| `vpc_security_group_ids` | **yes** | — | SG IDs for Lambda ENIs |
| `dynamodb_table_name` | no | `eks-agent-jobs` | DynamoDB table name |
| `cors_origin` | no | `*` | Restrict to CloudFront URL in prod |
| `api_throttle_rate` | no | `20` | API GW requests/second |
| `api_throttle_burst` | no | `50` | API GW burst limit |

| Frontend env var | Required | Description |
|------------------|----------|-------------|
| `NEXT_PUBLIC_API_URL` | **yes** | Full API base URL, e.g. `https://<CF>/api/v1` |

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| Lambda `dial tcp: i/o timeout` | Lambda VPC cannot reach cluster private endpoint | Add VPC peering / TGW attachment + route between central and spoke VPC |
| Lambda `AccessDenied` on `sts:AssumeRole` | Central Lambda role missing `sts:AssumeRole` on spoke role | Re-apply Terraform; verify `spoke_role_name` matches |
| Lambda `not authorized` from Kubernetes | Spoke role not in `aws-auth` / EKS access entry | Add role to `aws-auth` or create EKS access entry (Step 0) |
| Lambda `ModuleNotFoundError: shared` | Layer not built or not attached | Run `terraform apply`; check `null_resource.build_layer` output |
| Layer `exec format error` | Layer built for wrong CPU arch | `build_layer.py` uses `--platform manylinux2014_aarch64`; ensure pip supports `--platform` flag (`pip >= 22`) |
| Frontend blank page / 404 | Wrong `NEXT_PUBLIC_API_URL` | Rebuild with correct URL in `.env.local` |
| API returns 403 CORS | `cors_origin` mismatch | Re-apply Terraform with exact CloudFront domain |
| Diagnosis stays `pending` | Worker Lambda not invoked | Check `diagnose_start` CloudWatch logs; verify `lambda:InvokeFunction` IAM permission |
| `kubectl: not found` (CLI agent) | kubectl missing from PATH | Install kubectl 1.29+ |
| CLI agent `Cannot connect` | No network path to private endpoint | Run from bastion / VPN host inside the VPC |


---

## Prerequisites

| Tool | Min Version | Install |
|------|-------------|---------|
| Python | 3.12 | python.org |
| Node.js | 18 | nodejs.org |
| AWS CLI v2 | 2.15 | [docs](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html) |
| AWS SAM CLI | 1.115 | [docs](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html) |
| Terraform | 1.6+ | terraform.io (only if using Terraform instead of SAM) |
| kubectl | 1.29+ | kubernetes.io/docs/tasks/tools |

AWS credentials must have permissions for:
`eks:*`, `ec2:Describe*`, `elasticloadbalancing:Describe*`, `iam:Get*`, `iam:List*`, `autoscaling:Describe*`, `sts:GetCallerIdentity`, `lambda:*`, `apigateway:*`, `s3:*`, `cloudfront:*`, `dynamodb:*`, `iam:CreateRole`, `iam:AttachRolePolicy`

---

## Part 1 — CLI Agent (Local)

The Python CLI runs locally against whichever cluster is in your current kubeconfig context.

### 1.1 Install

```bash
cd eks-kubectl-agent

# Create and activate a virtual environment
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 1.2 Verify tools

```bash
kubectl version --client
aws --version
helm version
```

### 1.3 Configure

Edit `config.yaml` to set defaults:

```yaml
default_region: "us-east-1"      # your cluster region
default_namespace: "all"          # or a specific namespace
log_level: "INFO"
dry_run: false                    # set true to preview commands only
```

### 1.4 Run a diagnosis

```bash
# Full cluster diagnosis (auto-detects cluster from kubeconfig)
python main.py diagnose

# Specify cluster explicitly
python main.py diagnose --cluster my-eks-cluster --region us-east-1

# Scope to a single namespace
python main.py diagnose --namespace kube-system
```

### 1.5 Apply a fix (with confirmation)

After `diagnose` runs it saves `eks-fixes-cache.json` with all recommendations.

```bash
# List recommended fixes
python main.py fix --list

# Apply a specific fix (prompts for confirmation before executing)
python main.py fix FIX-001
```

### 1.6 Generate incident report

```bash
python main.py report
# Output: eks-incident-report.md (configurable in config.yaml)
```

---

## Part 2 — Backend (Lambda + API Gateway + DynamoDB)

Two deployment paths are provided: **AWS SAM** (recommended, faster) and **Terraform** (for teams already using Terraform).

---

### Option A — AWS SAM (Recommended)

#### 2A.1 Build the Lambda layer

The shared layer packages `boto3`, `kubernetes`, and the `shared/` modules.

```bash
cd eks-kubectl-agent/backend

# Create the layer directory structure that SAM expects
mkdir -p layer/python

# Install dependencies into the layer
pip install -r requirements.txt \
    --platform manylinux2014_aarch64 \
    --only-binary=:all: \
    --target layer/python

# Copy shared modules into the layer
cp -r shared/ layer/python/shared
```

> **Why `--platform manylinux2014_aarch64`?**  
> Lambda functions are deployed on `arm64`. Installing with the correct platform ensures compiled
> extensions (e.g., `cryptography` used by `kubernetes`) are binary-compatible.

#### 2A.2 Build and deploy

```bash
# From the backend/ directory
sam build

sam deploy \
  --stack-name eks-kubectl-agent-prod \
  --region us-east-1 \
  --capabilities CAPABILITY_IAM \
  --parameter-overrides \
      Environment=prod \
      CorsOrigin="*"

# After the frontend is deployed, re-deploy with the real CloudFront URL:
sam deploy \
  --stack-name eks-kubectl-agent-prod \
  --region us-east-1 \
  --capabilities CAPABILITY_IAM \
  --no-confirm-changeset \
  --parameter-overrides \
      Environment=prod \
      CorsOrigin="https://dXXXXXXXXXXX.cloudfront.net"
```

#### 2A.3 Note the API endpoint

```bash
aws cloudformation describe-stacks \
  --stack-name eks-kubectl-agent-prod \
  --query "Stacks[0].Outputs[?OutputKey=='ApiUrl'].OutputValue" \
  --output text
```

Save this value — it is your `NEXT_PUBLIC_API_URL` base for the frontend.

#### 2A.4 Tear down

```bash
sam delete --stack-name eks-kubectl-agent-prod --region us-east-1
```

---

### Option B — Terraform

#### 2B.1 Package the Lambda code

```bash
cd eks-kubectl-agent/backend

# Build the shared layer zip
mkdir -p layer/python
pip install -r requirements.txt \
    --platform manylinux2014_aarch64 \
    --only-binary=:all: \
    --target layer/python
cp -r shared/ layer/python/shared
cd layer && zip -r ../layer.zip . && cd ..

# Package all function handlers into a single zip
zip -r functions.zip functions/
```

#### 2B.2 Initialize and apply Terraform

```bash
cd eks-kubectl-agent/infrastructure/terraform

terraform init

terraform plan \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var="lambda_layer_path=../../backend/layer.zip" \
  -var="lambda_functions_path=../../backend/functions.zip"

terraform apply \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var="lambda_layer_path=../../backend/layer.zip" \
  -var="lambda_functions_path=../../backend/functions.zip"
```

#### 2B.3 Note the outputs

```bash
terraform output api_gateway_url
terraform output cloudfront_url
```

#### 2B.4 Tear down

```bash
terraform destroy \
  -var="aws_region=us-east-1" \
  -var="environment=prod" \
  -var="lambda_layer_path=../../backend/layer.zip" \
  -var="lambda_functions_path=../../backend/functions.zip"
```

---

## Part 3 — Frontend (Next.js → S3 + CloudFront)

### 3.1 Install dependencies

```bash
cd eks-kubectl-agent/frontend
npm install
```

### 3.2 Configure environment

```bash
# Copy the example file
cp .env.example .env.local

# Edit .env.local — set your API Gateway endpoint:
# NEXT_PUBLIC_API_URL=https://<id>.execute-api.us-east-1.amazonaws.com/prod
```

For production, point `NEXT_PUBLIC_API_URL` at the CloudFront `/api/v1` path instead, so
all traffic flows through a single domain and avoids CORS issues:

```
NEXT_PUBLIC_API_URL=https://dXXXXXXXXXXX.cloudfront.net/api/v1
```

### 3.3 Build the static export

```bash
npm run build
# Output is written to frontend/out/
```

### 3.4 Create S3 bucket (first deploy only)

If you deployed via **SAM**, create the bucket manually (SAM does not create the S3 frontend bucket).
If you deployed via **Terraform**, the bucket was created for you — skip this step.

```bash
# Replace ACCOUNT_ID and REGION with real values
aws s3 mb s3://eks-kubectl-agent-prod-frontend-ACCOUNT_ID --region REGION
aws s3api put-public-access-block \
  --bucket eks-kubectl-agent-prod-frontend-ACCOUNT_ID \
  --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
```

### 3.5 Upload to S3

Two-pass sync: immutable hashed assets get long TTL, everything else gets no-cache so deploys
are instant.

```bash
BUCKET=eks-kubectl-agent-prod-frontend-ACCOUNT_ID

# Pass 1: Next.js hashed static assets (JS/CSS) — immutable 1-year cache
aws s3 sync out/_next/static/ s3://$BUCKET/_next/static/ \
  --cache-control "max-age=31536000,public,immutable" \
  --delete

# Pass 2: Everything else (HTML, manifest, etc.) — no cache
aws s3 sync out/ s3://$BUCKET/ \
  --cache-control "max-age=0,no-cache,no-store,must-revalidate" \
  --exclude "_next/static/*" \
  --delete
```

### 3.6 Invalidate CloudFront cache (after every deploy)

```bash
CF_DIST_ID=$(aws cloudfront list-distributions \
  --query "DistributionList.Items[?Comment=='eks-kubectl-agent-prod frontend'].Id" \
  --output text)

aws cloudfront create-invalidation \
  --distribution-id $CF_DIST_ID \
  --paths "/*"
```

### 3.7 Verify

Open the CloudFront URL in a browser. The dashboard should load and show the New Diagnosis button.

```bash
# Get CloudFront URL (Terraform)
terraform -chdir=infrastructure/terraform output cloudfront_url

# Get CloudFront URL (SAM / manual)
aws cloudfront list-distributions \
  --query "DistributionList.Items[].{URL:DomainName,Id:Id}" \
  --output table
```

---

## End-to-End Deployment Order

```
1. Deploy Backend  (SAM or Terraform)
      ↓  note API Gateway URL
2. Build Frontend  (npm run build with NEXT_PUBLIC_API_URL set)
      ↓
3. Upload Frontend to S3
      ↓
4. Invalidate CloudFront
      ↓
5. Update Backend CORS  (re-deploy SAM/Terraform with CorsOrigin=<CloudFront URL>)
```

---

## Update / Re-deploy

### Backend only (SAM)

```bash
cd backend
# Rebuild layer if requirements changed:
pip install -r requirements.txt \
    --platform manylinux2014_aarch64 \
    --only-binary=:all: \
    --target layer/python
sam build
sam deploy --stack-name eks-kubectl-agent-prod --region us-east-1 \
  --capabilities CAPABILITY_IAM --no-confirm-changeset \
  --parameter-overrides Environment=prod CorsOrigin="https://dXXXXXXXXXXX.cloudfront.net"
```

### Frontend only

```bash
cd frontend
npm run build
aws s3 sync out/_next/static/ s3://$BUCKET/_next/static/ --cache-control "max-age=31536000,public,immutable" --delete
aws s3 sync out/ s3://$BUCKET/ --cache-control "max-age=0,no-cache,no-store,must-revalidate" --exclude "_next/static/*" --delete
aws cloudfront create-invalidation --distribution-id $CF_DIST_ID --paths "/*"
```

---

## Environment Variable Reference

| Variable | Where set | Description |
|----------|-----------|-------------|
| `NEXT_PUBLIC_API_URL` | `frontend/.env.local` | Full base URL for API calls, e.g. `https://<CF>/api/v1` |
| `DYNAMODB_TABLE` | Lambda env (SAM/Terraform) | DynamoDB table name, default `eks-agent-jobs` |
| `CORS_ORIGIN` | Lambda env (SAM/Terraform) | Allowed CORS origin — set to CloudFront URL in prod |
| `LOG_LEVEL` | Lambda env (SAM/Terraform) | `INFO` or `DEBUG` |

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Frontend shows blank page | Wrong `NEXT_PUBLIC_API_URL` | Re-build with correct URL in `.env.local` |
| API returns 403 CORS | `CORS_ORIGIN` mismatch | Re-deploy backend with exact CloudFront domain |
| Lambda cold start `ModuleNotFoundError: shared` | Layer not built properly | Rebuild layer — ensure `shared/` copied into `layer/python/` |
| Lambda `exec format error` | Layer built for wrong arch | Rebuild with `--platform manylinux2014_aarch64` |
| Diagnosis stays "pending" | Worker Lambda not invoked | Check `diagnose_start` logs; verify `lambda:InvokeFunction` IAM permission |
| `kubectl: command not found` (CLI agent) | kubectl not in PATH | Install kubectl and ensure it's on `$PATH` |
| CLI agent `ToolNotFoundError` | Missing aws/helm | Install missing tools; helm is optional |
