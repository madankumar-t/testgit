"""
DynamoDB storage helpers for diagnosis jobs.
"""
from __future__ import annotations

import json
import os
import time
from typing import Any, Optional

import boto3
from boto3.dynamodb.conditions import Key

TABLE_NAME = os.environ.get("DYNAMODB_TABLE", "eks-agent-jobs")
TTL_HOURS = int(os.environ.get("JOB_TTL_HOURS", "24"))

_dynamodb = None


def _get_table():
    global _dynamodb
    if _dynamodb is None:
        region = os.environ.get("AWS_REGION", "us-east-1")
        _dynamodb = boto3.resource("dynamodb", region_name=region).Table(TABLE_NAME)
    return _dynamodb


def put_job(job_dict: dict[str, Any]) -> None:
    """Create or replace a job record."""
    table = _get_table()
    job_dict["ttl"] = int(time.time()) + TTL_HOURS * 3600
    # DynamoDB doesn't support nested list/dict with Decimal; serialize complex fields
    for key in ("findings", "fixes", "executed_commands", "cluster_context"):
        if key in job_dict and isinstance(job_dict[key], (list, dict)):
            job_dict[key] = json.dumps(job_dict[key])
    table.put_item(Item=job_dict)


def get_job(job_id: str) -> Optional[dict[str, Any]]:
    """Retrieve a job record by ID."""
    table = _get_table()
    response = table.get_item(Key={"job_id": job_id})
    item = response.get("Item")
    if item is None:
        return None
    # Deserialize JSON fields
    for key in ("findings", "fixes", "executed_commands", "cluster_context"):
        if key in item and isinstance(item[key], str):
            try:
                item[key] = json.loads(item[key])
            except (json.JSONDecodeError, TypeError):
                pass
    return item


def update_job_status(job_id: str, status: str, **kwargs) -> None:
    """Update job status and any additional fields."""
    table = _get_table()
    update_expr_parts = ["#st = :status"]
    expr_names = {"#st": "status"}
    expr_values: dict[str, Any] = {":status": status}

    for k, v in kwargs.items():
        safe_k = f"#{k}"
        update_expr_parts.append(f"{safe_k} = :{k}")
        expr_names[safe_k] = k
        if isinstance(v, (list, dict)):
            expr_values[f":{k}"] = json.dumps(v)
        else:
            expr_values[f":{k}"] = v

    table.update_item(
        Key={"job_id": job_id},
        UpdateExpression="SET " + ", ".join(update_expr_parts),
        ExpressionAttributeNames=expr_names,
        ExpressionAttributeValues=expr_values,
    )
