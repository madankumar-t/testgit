"""
AWS-native diagnostic checks using boto3.
Returns structured data dicts ready for analysis.
"""
from __future__ import annotations

import logging
import os
from typing import Any

import boto3

logger = logging.getLogger(__name__)


def _session(role_arn: str | None = None) -> boto3.Session:
    """
    Return a boto3 Session.  If role_arn is given, assumes that cross-account
    IAM role first and returns a session backed by the temporary credentials.
    """
    if not role_arn:
        return boto3.session.Session()
    sts = boto3.client("sts")
    creds = sts.assume_role(
        RoleArn=role_arn,
        RoleSessionName="eks-agent-aws-diag",
        DurationSeconds=3600,
    )["Credentials"]
    return boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
    )


def _safe(fn, default=None):
    try:
        return fn()
    except Exception as exc:
        logger.warning("AWS check failed: %s", exc)
        return default


# ---------------------------------------------------------------------------
# STS / Identity
# ---------------------------------------------------------------------------

def get_caller_identity(region: str, role_arn: str | None = None) -> dict[str, Any]:
    sts = _session(role_arn).client("sts", region_name=region)
    return _safe(lambda: sts.get_caller_identity(), {})


# ---------------------------------------------------------------------------
# EKS Cluster
# ---------------------------------------------------------------------------

def get_eks_cluster(cluster_name: str, region: str, role_arn: str | None = None) -> dict[str, Any]:
    eks = _session(role_arn).client("eks", region_name=region)
    resp = _safe(lambda: eks.describe_cluster(name=cluster_name), {})
    return resp.get("cluster", {}) if resp else {}


def get_eks_nodegroups(cluster_name: str, region: str, role_arn: str | None = None) -> list[dict[str, Any]]:
    eks = _session(role_arn).client("eks", region_name=region)
    ng_names = _safe(
        lambda: eks.list_nodegroups(clusterName=cluster_name).get("nodegroups", []),
        [],
    )
    result = []
    for ng in ng_names:
        info = _safe(
            lambda: eks.describe_nodegroup(
                clusterName=cluster_name, nodegroupName=ng
            ).get("nodegroup", {}),
            {},
        )
        if info:
            result.append({
                "name": ng,
                "status": info.get("status"),
                "instance_types": info.get("instanceTypes", []),
                "scaling_config": info.get("scalingConfig", {}),
                "ami_type": info.get("amiType"),
                "node_role": info.get("nodeRole"),
            })
    return result


def get_eks_addons(cluster_name: str, region: str, role_arn: str | None = None) -> list[dict[str, Any]]:
    eks = _session(role_arn).client("eks", region_name=region)
    addon_names = _safe(
        lambda: eks.list_addons(clusterName=cluster_name).get("addons", []),
        [],
    )
    result = []
    for addon in addon_names:
        info = _safe(
            lambda: eks.describe_addon(
                clusterName=cluster_name, addonName=addon
            ).get("addon", {}),
            {},
        )
        if info:
            result.append({
                "name": addon,
                "status": info.get("status"),
                "addon_version": info.get("addonVersion"),
                "health": info.get("health", {}),
            })
    return result


# ---------------------------------------------------------------------------
# ALB / NLB
# ---------------------------------------------------------------------------

def get_load_balancers(region: str, role_arn: str | None = None) -> list[dict[str, Any]]:
    elbv2 = _session(role_arn).client("elbv2", region_name=region)
    lbs = _safe(
        lambda: elbv2.describe_load_balancers().get("LoadBalancers", []),
        [],
    )
    return [
        {
            "arn": lb["LoadBalancerArn"],
            "name": lb["LoadBalancerName"],
            "dns_name": lb["DNSName"],
            "state": lb.get("State", {}).get("Code", "unknown"),
            "type": lb["Type"],
            "scheme": lb["Scheme"],
            "vpc_id": lb.get("VpcId"),
            "created_time": str(lb.get("CreatedTime", "")),
        }
        for lb in lbs
    ]


def get_target_groups(region: str, role_arn: str | None = None) -> list[dict[str, Any]]:
    elbv2 = _session(role_arn).client("elbv2", region_name=region)
    tgs = _safe(
        lambda: elbv2.describe_target_groups().get("TargetGroups", []),
        [],
    )
    result = []
    for tg in tgs:
        arn = tg["TargetGroupArn"]
        health = _safe(
            lambda: elbv2.describe_target_health(TargetGroupArn=arn).get(
                "TargetHealthDescriptions", []
            ),
            [],
        )
        healthy = sum(1 for h in health if h.get("TargetHealth", {}).get("State") == "healthy")
        total = len(health)
        result.append({
            "arn": arn,
            "name": tg["TargetGroupName"],
            "protocol": tg.get("Protocol"),
            "port": tg.get("Port"),
            "target_type": tg.get("TargetType"),
            "healthy_count": healthy,
            "total_count": total,
            "health_check_path": tg.get("HealthCheckPath"),
            "health_check_port": tg.get("HealthCheckPort"),
            "target_health": [
                {
                    "id": h.get("Target", {}).get("Id"),
                    "port": h.get("Target", {}).get("Port"),
                    "state": h.get("TargetHealth", {}).get("State"),
                    "reason": h.get("TargetHealth", {}).get("Reason"),
                    "description": h.get("TargetHealth", {}).get("Description"),
                }
                for h in health
            ],
        })
    return result


# ---------------------------------------------------------------------------
# VPC / Networking
# ---------------------------------------------------------------------------

def get_subnets(region: str, vpc_id: str | None = None, role_arn: str | None = None) -> list[dict[str, Any]]:
    ec2 = _session(role_arn).client("ec2", region_name=region)
    filters = [{"Name": "vpc-id", "Values": [vpc_id]}] if vpc_id else []
    subnets = _safe(
        lambda: ec2.describe_subnets(Filters=filters).get("Subnets", []),
        [],
    )
    return [
        {
            "subnet_id": s["SubnetId"],
            "vpc_id": s["VpcId"],
            "cidr": s["CidrBlock"],
            "az": s["AvailabilityZone"],
            "available_ips": s["AvailableIpAddressCount"],
            "public": s.get("MapPublicIpOnLaunch", False),
            "tags": {t["Key"]: t["Value"] for t in s.get("Tags", [])},
        }
        for s in subnets
    ]


def get_security_groups(region: str, group_ids: list[str] | None = None, role_arn: str | None = None) -> list[dict[str, Any]]:
    ec2 = _session(role_arn).client("ec2", region_name=region)
    kwargs = {}
    if group_ids:
        kwargs["GroupIds"] = group_ids
    sgs = _safe(lambda: ec2.describe_security_groups(**kwargs).get("SecurityGroups", []), [])
    return [
        {
            "group_id": sg["GroupId"],
            "group_name": sg["GroupName"],
            "vpc_id": sg.get("VpcId"),
            "description": sg.get("Description"),
            "ingress_rules": [
                {
                    "protocol": r.get("IpProtocol"),
                    "from_port": r.get("FromPort"),
                    "to_port": r.get("ToPort"),
                    "cidr_ranges": [c["CidrIp"] for c in r.get("IpRanges", [])],
                }
                for r in sg.get("IpPermissions", [])
            ],
        }
        for sg in sgs
    ]


# ---------------------------------------------------------------------------
# IAM / OIDC
# ---------------------------------------------------------------------------

def get_oidc_providers(region: str, role_arn: str | None = None) -> list[str]:
    iam = _session(role_arn).client("iam", region_name=region)
    providers = _safe(
        lambda: iam.list_open_id_connect_providers().get("OpenIDConnectProviderList", []),
        [],
    )
    return [p["Arn"] for p in providers]


def get_role(role_name: str, region: str, role_arn: str | None = None) -> dict[str, Any]:
    iam = _session(role_arn).client("iam", region_name=region)
    return _safe(lambda: iam.get_role(RoleName=role_name).get("Role", {}), {})


# ---------------------------------------------------------------------------
# Auto Scaling
# ---------------------------------------------------------------------------

def get_autoscaling_groups(region: str, role_arn: str | None = None) -> list[dict[str, Any]]:
    asg = _session(role_arn).client("autoscaling", region_name=region)
    groups = _safe(
        lambda: asg.describe_auto_scaling_groups().get("AutoScalingGroups", []),
        [],
    )
    return [
        {
            "name": g["AutoScalingGroupName"],
            "min_size": g["MinSize"],
            "max_size": g["MaxSize"],
            "desired_capacity": g["DesiredCapacity"],
            "status": g.get("Status"),
            "instances": len(g.get("Instances", [])),
            "health_check_type": g.get("HealthCheckType"),
        }
        for g in groups
    ]
