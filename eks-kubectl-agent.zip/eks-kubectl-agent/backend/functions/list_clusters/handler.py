"""
GET /api/v1/clusters?account_id=123456789012[&region=us-east-1]

Lists EKS clusters visible to the spoke role in the given account.
If *region* is omitted every region in EKS_REGIONS is queried in parallel.
"""
from __future__ import annotations

import concurrent.futures
import json
import logging
import os

import boto3

from shared.k8s_client import assume_role

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

SPOKE_ROLE_NAME = os.environ.get("SPOKE_ROLE_NAME", "eks-agent-spoke-role")

_DEFAULT_REGIONS = [
    r.strip()
    for r in os.environ.get(
        "EKS_REGIONS",
        "us-east-1,us-east-2,us-west-1,us-west-2,"
        "eu-west-1,eu-west-2,eu-central-1,"
        "ap-southeast-1,ap-southeast-2,ap-northeast-1",
    ).split(",")
    if r.strip()
]


def _cors_headers() -> dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,GET",
        "Content-Type": "application/json",
    }


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body),
    }


def _list_in_region(session: boto3.Session, region: str) -> list[dict]:
    """Return cluster summaries for one region; swallows per-region errors."""
    try:
        eks = session.client("eks", region_name=region)
        paginator = eks.get_paginator("list_clusters")
        names: list[str] = []
        for page in paginator.paginate():
            names.extend(page.get("clusters", []))

        results: list[dict] = []
        for name in names:
            try:
                c = eks.describe_cluster(name=name)["cluster"]
                results.append(
                    {
                        "name": c["name"],
                        "region": region,
                        "status": c.get("status", "UNKNOWN"),
                        "version": c.get("version", ""),
                        "endpoint": c.get("endpoint", ""),
                        "arn": c.get("arn", ""),
                        "tags": c.get("tags", {}),
                    }
                )
            except Exception as exc:
                logger.warning("describe_cluster %s/%s failed: %s", region, name, exc)
                results.append(
                    {
                        "name": name,
                        "region": region,
                        "status": "UNKNOWN",
                        "version": "",
                        "endpoint": "",
                        "arn": "",
                        "tags": {},
                    }
                )
        return results
    except Exception as exc:
        logger.warning("list_clusters in %s failed: %s", region, exc)
        return []


def handler(event: dict, context) -> dict:
    method = (
        event.get("requestContext", {}).get("http", {}).get("method")
        or event.get("httpMethod", "")
    )
    if method == "OPTIONS":
        return _response(200, {})

    params: dict = event.get("queryStringParameters") or {}
    account_id = (params.get("account_id") or "").strip()
    region = (params.get("region") or "").strip()

    if not account_id:
        return _response(400, {"error": "account_id query parameter is required"})
    if not account_id.isdigit() or len(account_id) != 12:
        return _response(400, {"error": "account_id must be a 12-digit number"})

    role_arn = f"arn:aws:iam::{account_id}:role/{SPOKE_ROLE_NAME}"
    try:
        session = assume_role(role_arn, f"list-clusters-{account_id}")
    except Exception as exc:
        logger.error("Failed to assume %s: %s", role_arn, exc)
        return _response(403, {"error": f"Cannot assume role in account {account_id}: {exc}"})

    regions_to_scan = [region] if region else _DEFAULT_REGIONS

    clusters: list[dict] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(_list_in_region, session, r) for r in regions_to_scan]
        for fut in concurrent.futures.as_completed(futures):
            clusters.extend(fut.result())

    # ACTIVE clusters first, then sort by region + name
    clusters.sort(key=lambda c: (0 if c["status"] == "ACTIVE" else 1, c["region"], c["name"]))

    logger.info("Found %d clusters in account %s", len(clusters), account_id)
    return _response(200, {"clusters": clusters, "account_id": account_id})
