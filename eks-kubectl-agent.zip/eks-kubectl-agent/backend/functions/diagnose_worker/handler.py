"""
Async worker Lambda — invoked by diagnose_start with InvocationType=Event.

Performs the full EKS diagnosis using the Kubernetes Python client + boto3,
then stores results in DynamoDB.
"""
from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

from shared.analyzers import run_all_analyzers
from shared.aws_diagnostics import (
    get_autoscaling_groups,
    get_caller_identity,
    get_eks_addons,
    get_eks_cluster,
    get_eks_nodegroups,
    get_load_balancers,
    get_oidc_providers,
    get_security_groups,
    get_subnets,
    get_target_groups,
)
from shared.k8s_client import (
    assume_role,
    get_apps_v1,
    get_autoscaling_v2,
    get_batch_v1,
    get_core_v1,
    get_networking_v1,
    get_policy_v1,
    get_storage_v1,
)
from shared.k8s_diagnostics import (
    get_cluster_context,
    get_daemonsets,
    get_deployments,
    get_endpoints,
    get_events,
    get_hpas,
    get_ingresses,
    get_nodes,
    get_pods,
    get_pvcs,
    get_services,
    get_statefulsets,
)
from shared.models import JobStatus
from shared.storage import update_job_status

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _step(commands: list[dict], step: int, command: str, purpose: str,
          success: bool, summary: str) -> int:
    commands.append({
        "step": step,
        "command": command,
        "purpose": purpose,
        "result_summary": ("OK" if success else f"FAILED: {summary[:100]}"),
        "success": success,
    })
    return step + 1


def handler(event: dict, context) -> None:
    job_id: str = event["job_id"]
    cluster_name: str = event["cluster_name"]
    region: str = event["region"]
    namespace: str = event.get("namespace", "all")
    role_arn: str = event.get("role_arn", "")

    logger.info("Worker starting for job %s cluster %s account-role %s",
                job_id, cluster_name, role_arn or "(central)")
    update_job_status(job_id, JobStatus.RUNNING.value)

    executed: list[dict] = []
    data: dict[str, Any] = {}
    step = 1

    # ---- Build k8s API clients ----
    try:
        core = get_core_v1(cluster_name, region, role_arn or None)
        apps = get_apps_v1(cluster_name, region, role_arn or None)
        networking = get_networking_v1(cluster_name, region, role_arn or None)
        autoscaling = get_autoscaling_v2(cluster_name, region, role_arn or None)
    except Exception as exc:
        logger.error("Cannot connect to EKS cluster: %s", exc)
        update_job_status(
            job_id, JobStatus.FAILED.value,
            error_message=f"Cannot connect to EKS API: {exc}",
            completed_at=datetime.now(timezone.utc).isoformat(),
        )
        return

    # ---- Step 1: Cluster context ----
    try:
        identity = get_caller_identity(region, role_arn or None)
        eks_info = get_eks_cluster(cluster_name, region, role_arn or None)
        ctx = get_cluster_context(core, cluster_name)
        ctx["aws_account"] = identity.get("Account", "unknown")
        ctx["aws_user"] = identity.get("Arn", "unknown")
        ctx["kubernetes_version"] = eks_info.get("version", "unknown")
        ctx["api_server"] = eks_info.get("endpoint", "unknown")
        step = _step(executed, step, "eks:DescribeCluster + sts:GetCallerIdentity",
                     "Cluster context", True, "OK")
    except Exception as exc:
        ctx = {"cluster_name": cluster_name, "region": region}
        step = _step(executed, step, "cluster-context", "Cluster context", False, str(exc))

    data["cluster_context"] = ctx

    # ---- Step 2: Nodes ----
    try:
        nodes = get_nodes(core)
        data["nodes"] = nodes
        step = _step(executed, step, "k8s:ListNode", "Node health", True, f"{len(nodes)} nodes")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListNode", "Node health", False, str(exc))

    # ---- Step 3: Pods ----
    try:
        pods = get_pods(core, namespace)
        data["pods"] = pods
        step = _step(executed, step, "k8s:ListPodForAllNamespaces", "Pod health", True, f"{len(pods)} pods")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListPodForAllNamespaces", "Pod health", False, str(exc))

    # ---- Step 4: Deployments ----
    try:
        deployments = get_deployments(apps, namespace)
        data["deployments"] = deployments
        step = _step(executed, step, "k8s:ListDeployment", "Deployments", True, f"{len(deployments)}")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListDeployment", "Deployments", False, str(exc))

    # ---- Step 5: DaemonSets ----
    try:
        daemonsets = get_daemonsets(apps, namespace)
        data["daemonsets"] = daemonsets
        step = _step(executed, step, "k8s:ListDaemonSet", "DaemonSets", True, f"{len(daemonsets)}")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListDaemonSet", "DaemonSets", False, str(exc))

    # ---- Step 6: StatefulSets ----
    try:
        statefulsets = get_statefulsets(apps, namespace)
        data["statefulsets"] = statefulsets
        step = _step(executed, step, "k8s:ListStatefulSet", "StatefulSets", True, f"{len(statefulsets)}")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListStatefulSet", "StatefulSets", False, str(exc))

    # ---- Step 7: Services + Endpoints ----
    try:
        services = get_services(core, namespace)
        endpoints = get_endpoints(core, namespace)
        data["services"] = services
        data["endpoints"] = endpoints
        step = _step(executed, step, "k8s:ListService + ListEndpoints", "Services/Endpoints",
                     True, f"{len(services)} svcs, {len(endpoints)} eps")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListService", "Services/Endpoints", False, str(exc))

    # ---- Step 8: Ingress ----
    try:
        ingresses = get_ingresses(networking, namespace)
        data["ingresses"] = ingresses
        step = _step(executed, step, "k8s:ListIngress", "Ingress resources", True, f"{len(ingresses)}")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListIngress", "Ingress resources", False, str(exc))

    # ---- Step 9: ALB / Target groups ----
    try:
        lbs = get_load_balancers(region, role_arn or None)
        tgs = get_target_groups(region, role_arn or None)
        data["load_balancers"] = lbs
        data["target_groups"] = tgs
        step = _step(executed, step, "elbv2:DescribeLoadBalancers + DescribeTargetGroups",
                     "ALB/NLB + Target Groups", True, f"{len(lbs)} LBs, {len(tgs)} TGs")
    except Exception as exc:
        step = _step(executed, step, "elbv2:Describe*", "ALB/NLB", False, str(exc))

    # ---- Step 10: Networking ----
    try:
        eks_info_full = get_eks_cluster(cluster_name, region, role_arn or None)
        vpc_id = eks_info_full.get("resourcesVpcConfig", {}).get("vpcId")
        subnets = get_subnets(region, vpc_id, role_arn or None)
        sgs = get_security_groups(region, role_arn=role_arn or None)
        data["subnets"] = subnets
        data["security_groups"] = sgs
        step = _step(executed, step, "ec2:DescribeSubnets + DescribeSecurityGroups",
                     "VPC networking", True, f"{len(subnets)} subnets")
    except Exception as exc:
        step = _step(executed, step, "ec2:Describe*", "VPC networking", False, str(exc))

    # ---- Step 11: Storage / PVCs ----
    try:
        pvcs = get_pvcs(core, namespace)
        data["pvcs"] = pvcs
        step = _step(executed, step, "k8s:ListPersistentVolumeClaim", "PVCs", True, f"{len(pvcs)}")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListPersistentVolumeClaim", "PVCs", False, str(exc))

    # ---- Step 12: HPA ----
    try:
        hpas = get_hpas(autoscaling, namespace)
        data["hpas"] = hpas
        step = _step(executed, step, "k8s:ListHPA", "HPA", True, f"{len(hpas)}")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListHPA", "HPA", False, str(exc))

    # ---- Step 13: Nodegroups + ASGs ----
    try:
        nodegroups = get_eks_nodegroups(cluster_name, region, role_arn or None)
        asgs = get_autoscaling_groups(region, role_arn or None)
        data["nodegroups"] = nodegroups
        data["autoscaling_groups"] = asgs
        step = _step(executed, step, "eks:ListNodegroups + autoscaling:DescribeASGs",
                     "Nodegroups + ASGs", True, f"{len(nodegroups)} nodegroups")
    except Exception as exc:
        step = _step(executed, step, "eks:ListNodegroups", "Nodegroups", False, str(exc))

    # ---- Step 14: Add-ons ----
    try:
        addons = get_eks_addons(cluster_name, region, role_arn or None)
        data["addons"] = addons
        step = _step(executed, step, "eks:ListAddons + DescribeAddon", "EKS add-ons",
                     True, f"{len(addons)} add-ons")
    except Exception as exc:
        step = _step(executed, step, "eks:ListAddons", "EKS add-ons", False, str(exc))

    # ---- Step 15: IAM / OIDC ----
    try:
        oidc = get_oidc_providers(region, role_arn or None)
        data["oidc_providers"] = oidc
        step = _step(executed, step, "iam:ListOpenIDConnectProviders", "OIDC / IRSA",
                     True, f"{len(oidc)} providers")
    except Exception as exc:
        step = _step(executed, step, "iam:ListOpenIDConnectProviders", "OIDC / IRSA", False, str(exc))

    # ---- Step 16: Events ----
    try:
        events = get_events(core, namespace)
        data["events"] = events
        step = _step(executed, step, "k8s:ListEvent", "Kubernetes events",
                     True, f"{len(events)} warning events")
    except Exception as exc:
        step = _step(executed, step, "k8s:ListEvent", "Events", False, str(exc))

    # ---- Run analyzers ----
    findings, fixes, root_cause = run_all_analyzers(data)
    logger.info("Job %s: %d findings, %d fixes", job_id, len(findings), len(fixes))

    # ---- Persist results ----
    update_job_status(
        job_id,
        JobStatus.COMPLETE.value,
        completed_at=datetime.now(timezone.utc).isoformat(),
        cluster_context=ctx,
        executed_commands=executed,
        findings=findings,
        fixes=fixes,
        root_cause=root_cause,
    )
    logger.info("Job %s complete", job_id)
