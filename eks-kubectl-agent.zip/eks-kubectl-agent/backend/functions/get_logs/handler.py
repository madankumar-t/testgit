"""
POST /api/v1/logs

Fetches pod logs from EKS using the Kubernetes Python client.
Body: { cluster_name, region, namespace, pod_name, container?, tail_lines?, previous? }
"""
from __future__ import annotations

import json
import logging
import os

from shared.k8s_client import get_core_v1
from shared.k8s_diagnostics import get_pod_logs, get_pods

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _cors_headers() -> dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Content-Type": "application/json",
    }


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body, default=str),
    }


def handler(event: dict, context) -> dict:
    if event.get("httpMethod") == "OPTIONS":
        return _response(200, {})

    # Handle pod list (GET-style via POST with action=list)
    http_method = event.get("httpMethod", "POST")
    query_params = event.get("queryStringParameters") or {}
    action = query_params.get("action", "logs")

    try:
        body = json.loads(event.get("body") or "{}")
    except (json.JSONDecodeError, TypeError):
        return _response(400, {"error": "Invalid JSON body"})

    cluster_name = body.get("cluster_name", "").strip()
    region = body.get("region", "").strip()
    namespace = body.get("namespace", "default").strip()
    role_arn = body.get("role_arn", "").strip() or None

    if not cluster_name or not region:
        return _response(400, {"error": "cluster_name and region are required"})

    try:
        core = get_core_v1(cluster_name, region, role_arn)
    except Exception as exc:
        return _response(503, {"error": f"Cannot connect to cluster: {exc}"})

    # List pods in namespace
    if action == "list_pods":
        try:
            pods = get_pods(core, namespace)
            return _response(200, {"pods": pods})
        except Exception as exc:
            return _response(500, {"error": str(exc)})

    # Fetch logs
    pod_name = body.get("pod_name", "").strip()
    container = body.get("container") or None
    tail_lines = int(body.get("tail_lines", 200))
    previous = bool(body.get("previous", False))

    if not pod_name:
        return _response(400, {"error": "pod_name is required for log retrieval"})

    # Clamp tail_lines for safety
    tail_lines = min(max(tail_lines, 1), 2000)

    try:
        logs = get_pod_logs(
            core,
            namespace=namespace,
            pod_name=pod_name,
            container=container,
            tail_lines=tail_lines,
            previous=previous,
        )
        return _response(200, {
            "cluster_name": cluster_name,
            "namespace": namespace,
            "pod_name": pod_name,
            "container": container,
            "tail_lines": tail_lines,
            "previous": previous,
            "logs": logs,
        })
    except Exception as exc:
        logger.error("Failed to fetch logs for %s/%s: %s", namespace, pod_name, exc)
        return _response(500, {"error": str(exc)})
