"""
GET /api/v1/diagnose/{jobId}

Returns the current status and results of a diagnosis job from DynamoDB.
"""
from __future__ import annotations

import json
import os

from shared.storage import get_job


def _cors_headers() -> dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Content-Type": "application/json",
    }


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body, default=str),
    }


def handler(event: dict, context) -> dict:
    if event.get("httpMethod") == "OPTIONS":
        return _response(200, {})

    path_params = event.get("pathParameters") or {}
    job_id = path_params.get("jobId", "").strip()

    if not job_id:
        return _response(400, {"error": "jobId path parameter is required"})

    job = get_job(job_id)
    if job is None:
        return _response(404, {"error": f"Job '{job_id}' not found"})

    # Shape the response
    payload = {
        "job_id": job["job_id"],
        "status": job.get("status"),
        "cluster_name": job.get("cluster_name"),
        "region": job.get("region"),
        "namespace": job.get("namespace"),
        "started_at": job.get("started_at"),
        "completed_at": job.get("completed_at"),
        "cluster_context": job.get("cluster_context"),
        "executed_commands": job.get("executed_commands", []),
        "findings": job.get("findings", []),
        "fixes": job.get("fixes", []),
        "root_cause": job.get("root_cause", ""),
        "error_message": job.get("error_message"),
        # Derived summary counts
        "summary": _build_summary(job.get("findings", [])),
    }

    return _response(200, payload)


def _build_summary(findings: list[dict]) -> dict:
    counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    components: set[str] = set()
    namespaces: set[str] = set()
    for f in findings:
        sev = f.get("severity", "Info")
        counts[sev] = counts.get(sev, 0) + 1
        components.add(f.get("component", ""))
        ns = f.get("namespace", "")
        if ns not in ("aws", "cluster", "unknown", ""):
            namespaces.add(ns)
    return {
        "total": len(findings),
        "by_severity": counts,
        "affected_components": sorted(components),
        "affected_namespaces": sorted(namespaces),
    }
