"""
GET /api/v1/accounts

Returns the list of registered spoke accounts from the SPOKE_ACCOUNT_IDS
environment variable so the frontend can populate an account selector.

Format: comma-separated account IDs with optional labels
  "123456789012:Production,234567890123:Staging,345678901234"
If no label is given the account ID is used as the label.
"""
from __future__ import annotations

import json
import logging
import os

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Comma-separated account entries, e.g.:
#   "123456789012:Production,234567890123:Staging,345678901234"
SPOKE_ACCOUNT_IDS = os.environ.get("SPOKE_ACCOUNT_IDS", "")


def _cors_headers() -> dict[str, str]:
    return {
        "Access-Control-Allow-Origin": os.environ.get("CORS_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,GET",
        "Content-Type": "application/json",
    }


def _response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body),
    }


def handler(event: dict, context) -> dict:
    method = (
        event.get("requestContext", {}).get("http", {}).get("method")
        or event.get("httpMethod", "")
    )
    if method == "OPTIONS":
        return _response(200, {})

    accounts: list[dict] = []
    for entry in SPOKE_ACCOUNT_IDS.split(","):
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            account_id, label = entry.split(":", 1)
            account_id = account_id.strip()
            label = label.strip()
        else:
            account_id = entry
            label = entry

        if not account_id.isdigit() or len(account_id) != 12:
            logger.warning("Skipping invalid account entry: %s", entry)
            continue

        accounts.append({"account_id": account_id, "label": label})

    logger.info("Returning %d registered accounts", len(accounts))
    return _response(200, {"accounts": accounts})
