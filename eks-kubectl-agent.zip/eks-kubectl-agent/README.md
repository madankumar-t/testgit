# EKS Troubleshooting Agent

A Python 3.12+ CLI-based EKS troubleshooting agent that safely diagnoses Amazon EKS cluster issues across all namespaces using `kubectl`, `aws` CLI, and `helm`. It generates a structured Markdown incident report and presents fix recommendations that **require explicit user confirmation** before execution.

---

## Features

- **Fully read-only by default** — diagnosis never modifies cluster state
- **Safety classification** — every command is classified as `READ_ONLY` or `MUTATING` before execution
- **Structured incident report** — Markdown output covering all Kubernetes and AWS dimensions
- **Fix recommendations** — generated from findings, never auto-applied
- **Confirmation gate** — mutating fixes require `yes` at the prompt before running
- **Rich terminal UI** — tables, progress spinners, colour-coded severities

---

## Requirements

| Tool | Minimum Version | Notes |
|---|---|---|
| Python | 3.12+ | |
| kubectl | 1.25+ | Must be on PATH and have valid kubeconfig |
| aws CLI | v2 | Must be authenticated (SSO, IAM keys, or role) |
| helm | 3.x | Optional — helm checks skip gracefully if missing |

---

## Setup

```bash
# 1. Clone / navigate to the project
cd eks-kubectl-agent

# 2. Create and activate a virtual environment
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt
```

---

## AWS Authentication

The agent uses the standard AWS CLI credential chain. Authenticate before running:

```bash
# SSO login (most common for enterprise)
aws sso login --profile <your-profile>

# Verify identity
aws sts get-caller-identity
```

---

## kubeconfig Requirements

Your kubeconfig must point to the target EKS cluster:

```bash
# Update kubeconfig for your cluster
aws eks update-kubeconfig --name <cluster-name> --region <region>

# Verify context
kubectl config current-context
kubectl get nodes
```

---

## Required IAM Permissions

The IAM identity running the agent needs at minimum:

```json
{
  "Effect": "Allow",
  "Action": [
    "eks:DescribeCluster",
    "eks:ListClusters",
    "eks:ListNodegroups",
    "eks:DescribeNodegroup",
    "eks:DescribeAddon",
    "eks:ListAddons",
    "elbv2:Describe*",
    "ec2:Describe*",
    "iam:GetRole",
    "iam:GetPolicy",
    "iam:GetPolicyVersion",
    "iam:ListAttachedRolePolicies",
    "iam:ListOpenIDConnectProviders",
    "iam:GetOpenIDConnectProvider",
    "logs:DescribeLogGroups",
    "logs:DescribeLogStreams",
    "logs:FilterLogEvents",
    "cloudwatch:GetMetricStatistics",
    "autoscaling:DescribeAutoScalingGroups",
    "sts:GetCallerIdentity"
  ],
  "Resource": "*"
}
```

For mutating fixes (applied only after confirmation), additional permissions may be required depending on the fix type.

---

## Usage

### Run a full diagnosis

```bash
python main.py diagnose --cluster-name my-cluster --region us-east-2
```

### Scope to a specific namespace

```bash
python main.py diagnose --cluster-name my-cluster --region us-east-2 --namespace production
```

### Save the report to a custom path

```bash
python main.py diagnose --cluster-name my-cluster --region us-east-2 --output /tmp/report.md
```

### Dry-run mode (print commands, don't execute)

```bash
python main.py diagnose --cluster-name my-cluster --region us-east-2 --dry-run
```

### Enable verbose/debug logging

```bash
python main.py diagnose --cluster-name my-cluster --region us-east-2 --verbose
```

### View a saved report in the terminal

```bash
python main.py report --report eks-incident-report.md
```

### Apply a fix (with confirmation)

```bash
python main.py fix --fix-id FIX-001-EXEC
```

The agent will display:
1. Fix description
2. Exact command to be run
3. Risk level
4. Rollback plan
5. Prompt: **"Do you approve running this fix? (yes = execute, no = abort)"**

The fix **only executes** if you type `yes`.

---

## Project Structure

```
eks-kubectl-agent/
├── main.py              # Typer CLI entry point (diagnose / fix / report)
├── requirements.txt     # Python dependencies
├── config.yaml          # Runtime configuration defaults
├── README.md
└── agent/
    ├── __init__.py
    ├── models.py         # Shared dataclasses (CommandResult, Finding, etc.)
    ├── executor.py       # Safe subprocess wrapper — never shell=True
    ├── safety.py         # Command classification: READ_ONLY vs MUTATING
    ├── diagnostics.py    # EksDiagnosticAgent — orchestrates all checks
    ├── analyzers.py      # Parse command output → Finding objects
    ├── fixes.py          # Generate FixRecommendation from findings
    └── reporter.py       # Markdown incident report generator
```

---

## Diagnostic Coverage

The agent covers these areas in order:

| # | Area | Examples |
|---|---|---|
| 1 | Cluster context | kubectl context, AWS identity, cluster version |
| 2 | Node health | NotReady, MemoryPressure, DiskPressure |
| 3 | Namespaces | All namespace enumeration |
| 4 | Pod health | CrashLoopBackOff, ImagePullBackOff, OOMKilled, Pending, Evicted |
| 5 | Workloads | Deployments, ReplicaSets, DaemonSets, StatefulSets, Jobs, CronJobs |
| 6 | Services | Empty endpoints, selector mismatches |
| 7 | Ingress / ALB | Ingress resources, TargetGroupBindings, ALB/NLB, target health |
| 8 | ALB Controller | IAM errors, reconciliation failures, IRSA |
| 9 | Networking | VPC CNI, subnet IPs, security groups, route tables, NAT |
| 10 | DNS | CoreDNS pod health, DNS errors, SERVFAIL |
| 11 | Storage | Pending PVCs, EBS CSI driver health |
| 12 | Autoscaling | HPA, PDB, node groups, Karpenter |
| 13 | IAM / IRSA | OIDC provider, role annotations, AccessDenied |
| 14 | Events | All Kubernetes warning events |
| 15 | Add-ons | vpc-cni, coredns, kube-proxy, aws-ebs-csi-driver |

---

## Safety Rules

| Rule | Detail |
|---|---|
| No `shell=True` | All subprocesses use `list[str]` args |
| Read-only diagnosis | `kubectl get`, `describe`, `logs`, AWS `describe-*` — always safe |
| Confirmation required | Any `kubectl apply/delete/patch/edit/rollout restart`, `helm upgrade`, AWS mutating APIs |
| `--force` flag | Always escalated to MUTATING regardless of verb |
| Dry-run mode | Prints commands without executing — safe for testing |

---

## Limitations

- The agent does not have access to application code or databases
- CloudWatch Container Insights metrics require the add-on to be configured
- Karpenter NodeClaim/NodePool checks require Karpenter CRDs to be installed
- IRSA analysis checks for patterns in logs — does not validate trust policies automatically
- `kubectl top` requires metrics-server to be installed in the cluster

---

## Incident Report Sections

The generated Markdown report contains:

1. **Incident Summary** — counts, affected namespaces, components
2. **Cluster Context** — cluster name, account, region, version, nodes
3. **Commands Executed** — table of every command with result status
4. **Findings** — grouped by component with evidence, impact, severity
5. **Root Cause** — derived from highest-severity findings
6. **Recommended Fixes** — command, risk, expected result, rollback
7. **Confirmation Required** — list of fixes needing approval
8. **Post-Fix Validation Plan** — commands to verify each fix
9. **Escalation Notes** — when to involve AWS Support or platform team
