# ---------------------------------------------------------------------------
# Spoke Role Deployment
#
# Terraform writes a JSON config file, then calls deploy_spoke_roles.py which:
#   1. Assumes var.bootstrap_role_name in each member account
#      (default: OrganizationAccountAccessRole — created automatically by
#       AWS Organizations in every account provisioned through the console
#       or AWS Control Tower)
#   2. Deploys / updates a CloudFormation stack with infrastructure/member-account/spoke-role.yaml
#      which creates arn:aws:iam::{member_id}:role/{spoke_role_name}
#
# Re-runs automatically whenever:
#   • spoke_accounts changes (new / removed accounts)
#   • spoke-role.yaml template changes
#   • deploy_spoke_roles.py script changes
# ---------------------------------------------------------------------------

locals {
  # Absolute path makes the Python script work regardless of where terraform is invoked from
  spoke_roles_config_path = abspath("${path.module}/../../backend/.spoke_roles_config.json")
  spoke_roles_script_path = abspath("${path.module}/../../backend/scripts/deploy_spoke_roles.py")
  spoke_role_template_path = abspath("${path.module}/../member-account/spoke-role.yaml")
  spoke_stack_name        = "${local.prefix}-spoke-role"
}

# Write the configuration as JSON so the Python script can read it without
# any shell quoting / escaping issues (critical on Windows PowerShell).
resource "local_file" "spoke_roles_config" {
  count    = var.deploy_spoke_roles ? 1 : 0
  filename = local.spoke_roles_config_path
  content  = jsonencode({
    central_account_id  = data.aws_caller_identity.current.account_id
    spoke_role_name     = var.spoke_role_name
    bootstrap_role_name = var.bootstrap_role_name
    region              = var.aws_region
    stack_name          = local.spoke_stack_name
    template_path       = local.spoke_role_template_path
    accounts            = var.spoke_accounts
  })
}

resource "null_resource" "deploy_spoke_roles" {
  count = var.deploy_spoke_roles ? 1 : 0

  # Re-run when accounts change, the role template changes, or the script changes
  triggers = {
    accounts_hash    = sha256(jsonencode(var.spoke_accounts))
    central_account  = data.aws_caller_identity.current.account_id
    spoke_role_name  = var.spoke_role_name
    bootstrap_role   = var.bootstrap_role_name
    template_hash    = filemd5(local.spoke_role_template_path)
    script_hash      = filemd5(local.spoke_roles_script_path)
  }

  provisioner "local-exec" {
    command = "python \"${local.spoke_roles_script_path}\" --config \"${local.spoke_roles_config_path}\""
  }

  depends_on = [local_file.spoke_roles_config]
}
