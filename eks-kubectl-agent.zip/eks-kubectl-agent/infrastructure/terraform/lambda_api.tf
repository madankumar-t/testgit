# ---------------------------------------------------------------------------
# Build Lambda layer via null_resource (pip install) + archive_file
# Triggers automatically when requirements.txt or any shared/*.py changes.
# ---------------------------------------------------------------------------

locals {
  backend_dir    = "${path.module}/../../backend"
  layer_build_dir = "${path.module}/../../backend/.layer_build"
  layer_zip_path  = "${path.module}/../../backend/.layer.zip"
}

resource "null_resource" "build_layer" {
  triggers = {
    requirements = filemd5("${local.backend_dir}/requirements.txt")
    shared_src   = sha1(join("", [
      for f in sort(fileset("${local.backend_dir}/shared", "**/*.py")) :
      filemd5("${local.backend_dir}/shared/${f}")
    ]))
  }

  provisioner "local-exec" {
    # Python is already required for the project; this script is cross-platform.
    command = "python \"${path.module}/../../backend/scripts/build_layer.py\" \"${local.backend_dir}\""
  }
}

data "archive_file" "layer" {
  type        = "zip"
  source_dir  = local.layer_build_dir
  output_path = local.layer_zip_path
  depends_on  = [null_resource.build_layer]
}

# ---------------------------------------------------------------------------
# Lambda layer version
# ---------------------------------------------------------------------------

resource "aws_lambda_layer_version" "shared" {
  layer_name               = "${local.prefix}-shared-layer"
  filename                 = data.archive_file.layer.output_path
  source_code_hash         = data.archive_file.layer.output_base64sha256
  compatible_runtimes      = ["python3.12"]
  compatible_architectures = ["arm64"]
}

# ---------------------------------------------------------------------------
# Function code — one archive_file per function (zipped from source)
# Re-zipped automatically whenever handler.py changes.
# ---------------------------------------------------------------------------

data "archive_file" "fn_diagnose_start" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/diagnose_start"
  output_path = "${local.backend_dir}/.build/diagnose_start.zip"
}

data "archive_file" "fn_diagnose_worker" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/diagnose_worker"
  output_path = "${local.backend_dir}/.build/diagnose_worker.zip"
}

data "archive_file" "fn_diagnose_status" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/diagnose_status"
  output_path = "${local.backend_dir}/.build/diagnose_status.zip"
}

data "archive_file" "fn_get_logs" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/get_logs"
  output_path = "${local.backend_dir}/.build/get_logs.zip"
}

data "archive_file" "fn_apply_fix" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/apply_fix"
  output_path = "${local.backend_dir}/.build/apply_fix.zip"
}

data "archive_file" "fn_list_accounts" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/list_accounts"
  output_path = "${local.backend_dir}/.build/list_accounts.zip"
}

data "archive_file" "fn_list_clusters" {
  type        = "zip"
  source_dir  = "${local.backend_dir}/functions/list_clusters"
  output_path = "${local.backend_dir}/.build/list_clusters.zip"
}

# ---------------------------------------------------------------------------
# Common Lambda settings
# ---------------------------------------------------------------------------

locals {
  lambda_env = {
    DYNAMODB_TABLE          = var.dynamodb_table_name
    CORS_ORIGIN             = var.cors_origin
    POWERTOOLS_SERVICE_NAME = "eks-kubectl-agent"
    LOG_LEVEL               = "INFO"
    SPOKE_ROLE_NAME         = var.spoke_role_name
    # "123456789012:Production,234567890123:Staging" — parsed by list_accounts Lambda
    SPOKE_ACCOUNT_IDS       = join(",", [for id, label in var.spoke_accounts : "${id}:${label}"])
    EKS_REGIONS             = var.eks_regions
  }
  lambda_arch    = ["arm64"]
  lambda_runtime = "python3.12"
  lambda_layers  = [aws_lambda_layer_version.shared.arn]
  # Use subnets/SGs from networking.tf locals — resolves to either
  # newly created resources (create_networking=true) or user-supplied IDs.
  lambda_vpc     = {
    subnet_ids         = local.effective_subnet_ids
    security_group_ids = local.effective_sg_ids
  }
}

# ---------------------------------------------------------------------------
# diagnose_start — POST /api/v1/diagnose
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "diagnose_start" {
  function_name    = "${local.prefix}-diagnose-start"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_diagnose_start.output_path
  source_code_hash = data.archive_file.fn_diagnose_start.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 30
  memory_size      = 256

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = merge(local.lambda_env, {
      WORKER_FUNCTION_NAME = aws_lambda_function.diagnose_worker.function_name
    })
  }

  tracing_config {
    mode = "Active"
  }
}

# ---------------------------------------------------------------------------
# diagnose_worker — async background job (invoked by start)
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "diagnose_worker" {
  function_name    = "${local.prefix}-diagnose-worker"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_diagnose_worker.output_path
  source_code_hash = data.archive_file.fn_diagnose_worker.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 840   # 14 minutes — full diagnosis
  memory_size      = 1024

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = local.lambda_env
  }

  tracing_config {
    mode = "Active"
  }
}

# ---------------------------------------------------------------------------
# diagnose_status — GET /api/v1/diagnose/{jobId}
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "diagnose_status" {
  function_name    = "${local.prefix}-diagnose-status"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_diagnose_status.output_path
  source_code_hash = data.archive_file.fn_diagnose_status.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 30
  memory_size      = 256

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = local.lambda_env
  }

  tracing_config {
    mode = "Active"
  }
}

# ---------------------------------------------------------------------------
# get_logs — POST /api/v1/logs
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "get_logs" {
  function_name    = "${local.prefix}-get-logs"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_get_logs.output_path
  source_code_hash = data.archive_file.fn_get_logs.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 60
  memory_size      = 512

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = local.lambda_env
  }

  tracing_config {
    mode = "Active"
  }
}

# ---------------------------------------------------------------------------
# apply_fix — POST /api/v1/fix/apply
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "apply_fix" {
  function_name    = "${local.prefix}-apply-fix"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_apply_fix.output_path
  source_code_hash = data.archive_file.fn_apply_fix.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 120
  memory_size      = 512

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = local.lambda_env
  }

  tracing_config {
    mode = "Active"
  }
}

# ---------------------------------------------------------------------------
# CloudWatch Log Groups (explicit, with retention)
# ---------------------------------------------------------------------------

resource "aws_cloudwatch_log_group" "diagnose_start" {
  name              = "/aws/lambda/${aws_lambda_function.diagnose_start.function_name}"
  retention_in_days = 14
}

resource "aws_cloudwatch_log_group" "diagnose_worker" {
  name              = "/aws/lambda/${aws_lambda_function.diagnose_worker.function_name}"
  retention_in_days = 30
}

resource "aws_cloudwatch_log_group" "diagnose_status" {
  name              = "/aws/lambda/${aws_lambda_function.diagnose_status.function_name}"
  retention_in_days = 14
}

resource "aws_cloudwatch_log_group" "get_logs" {
  name              = "/aws/lambda/${aws_lambda_function.get_logs.function_name}"
  retention_in_days = 14
}

resource "aws_cloudwatch_log_group" "apply_fix" {
  name              = "/aws/lambda/${aws_lambda_function.apply_fix.function_name}"
  retention_in_days = 14
}

# ---------------------------------------------------------------------------
# list_accounts — GET /api/v1/accounts
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "list_accounts" {
  function_name    = "${local.prefix}-list-accounts"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_list_accounts.output_path
  source_code_hash = data.archive_file.fn_list_accounts.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 10
  memory_size      = 128

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = local.lambda_env
  }

  tracing_config {
    mode = "Active"
  }
}

resource "aws_cloudwatch_log_group" "list_accounts" {
  name              = "/aws/lambda/${aws_lambda_function.list_accounts.function_name}"
  retention_in_days = 14
}

# ---------------------------------------------------------------------------
# list_clusters — GET /api/v1/clusters?account_id=xxx[&region=yyy]
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "list_clusters" {
  function_name    = "${local.prefix}-list-clusters"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.fn_list_clusters.output_path
  source_code_hash = data.archive_file.fn_list_clusters.output_base64sha256
  handler          = "handler.handler"
  runtime          = local.lambda_runtime
  architectures    = local.lambda_arch
  layers           = local.lambda_layers
  timeout          = 120   # scanning 10 regions in parallel
  memory_size      = 256

  vpc_config {
    subnet_ids         = local.lambda_vpc.subnet_ids
    security_group_ids = local.lambda_vpc.security_group_ids
  }

  environment {
    variables = local.lambda_env
  }

  tracing_config {
    mode = "Active"
  }
}

resource "aws_cloudwatch_log_group" "list_clusters" {
  name              = "/aws/lambda/${aws_lambda_function.list_clusters.function_name}"
  retention_in_days = 14
}

# ---------------------------------------------------------------------------
# API Gateway HTTP API (v2)
# ---------------------------------------------------------------------------

resource "aws_apigatewayv2_api" "eks_agent" {
  name          = "${local.prefix}-api"
  protocol_type = "HTTP"
  description   = "EKS Kubectl Agent API"

  cors_configuration {
    allow_origins  = [var.cors_origin]
    allow_methods  = ["GET", "POST", "OPTIONS"]
    allow_headers  = ["Content-Type", "Authorization", "X-Amz-Date", "X-Api-Key"]
    expose_headers = ["X-Request-Id"]
    max_age        = 3600
  }
}

resource "aws_apigatewayv2_stage" "prod" {
  api_id      = aws_apigatewayv2_api.eks_agent.id
  name        = var.environment
  auto_deploy = true

  default_route_settings {
    throttling_rate_limit  = var.api_throttle_rate
    throttling_burst_limit = var.api_throttle_burst
  }

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_gateway.arn
  }
}

resource "aws_cloudwatch_log_group" "api_gateway" {
  name              = "/aws/apigateway/${local.prefix}"
  retention_in_days = 14
}

# ---------------------------------------------------------------------------
# Lambda integrations + routes
# ---------------------------------------------------------------------------

locals {
  routes = {
    "POST /api/v1/diagnose"       = aws_lambda_function.diagnose_start
    "GET /api/v1/diagnose/{jobId}" = aws_lambda_function.diagnose_status
    "POST /api/v1/logs"           = aws_lambda_function.get_logs
    "POST /api/v1/fix/apply"      = aws_lambda_function.apply_fix
  }
}

resource "aws_apigatewayv2_integration" "diagnose_start" {
  api_id             = aws_apigatewayv2_api.eks_agent.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.diagnose_start.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_integration" "diagnose_status" {
  api_id             = aws_apigatewayv2_api.eks_agent.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.diagnose_status.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_integration" "get_logs" {
  api_id             = aws_apigatewayv2_api.eks_agent.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.get_logs.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_integration" "apply_fix" {
  api_id             = aws_apigatewayv2_api.eks_agent.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.apply_fix.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_integration" "list_accounts" {
  api_id             = aws_apigatewayv2_api.eks_agent.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.list_accounts.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_integration" "list_clusters" {
  api_id             = aws_apigatewayv2_api.eks_agent.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.list_clusters.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "post_diagnose" {
  api_id    = aws_apigatewayv2_api.eks_agent.id
  route_key = "POST /api/v1/diagnose"
  target    = "integrations/${aws_apigatewayv2_integration.diagnose_start.id}"
}

resource "aws_apigatewayv2_route" "get_diagnosis_status" {
  api_id    = aws_apigatewayv2_api.eks_agent.id
  route_key = "GET /api/v1/diagnose/{jobId}"
  target    = "integrations/${aws_apigatewayv2_integration.diagnose_status.id}"
}

resource "aws_apigatewayv2_route" "post_logs" {
  api_id    = aws_apigatewayv2_api.eks_agent.id
  route_key = "POST /api/v1/logs"
  target    = "integrations/${aws_apigatewayv2_integration.get_logs.id}"
}

resource "aws_apigatewayv2_route" "post_fix_apply" {
  api_id    = aws_apigatewayv2_api.eks_agent.id
  route_key = "POST /api/v1/fix/apply"
  target    = "integrations/${aws_apigatewayv2_integration.apply_fix.id}"
}

resource "aws_apigatewayv2_route" "get_accounts" {
  api_id    = aws_apigatewayv2_api.eks_agent.id
  route_key = "GET /api/v1/accounts"
  target    = "integrations/${aws_apigatewayv2_integration.list_accounts.id}"
}

resource "aws_apigatewayv2_route" "get_clusters" {
  api_id    = aws_apigatewayv2_api.eks_agent.id
  route_key = "GET /api/v1/clusters"
  target    = "integrations/${aws_apigatewayv2_integration.list_clusters.id}"
}

# ---------------------------------------------------------------------------
# Lambda permissions — allow API Gateway to invoke each function
# ---------------------------------------------------------------------------

resource "aws_lambda_permission" "apigw_diagnose_start" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.diagnose_start.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.eks_agent.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_diagnose_status" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.diagnose_status.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.eks_agent.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_get_logs" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.get_logs.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.eks_agent.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_apply_fix" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.apply_fix.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.eks_agent.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_list_accounts" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.list_accounts.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.eks_agent.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_list_clusters" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.list_clusters.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.eks_agent.execution_arn}/*/*"
}
