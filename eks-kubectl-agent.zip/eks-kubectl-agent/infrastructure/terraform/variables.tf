variable "aws_region" {
  description = "AWS region to deploy infrastructure"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  default     = "prod"
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Must be dev, staging, or prod."
  }
}

variable "project" {
  description = "Project tag prefix"
  type        = string
  default     = "eks-kubectl-agent"
}

variable "dynamodb_table_name" {
  description = "DynamoDB table name for job storage"
  type        = string
  default     = "eks-agent-jobs"
}

variable "frontend_build_path" {
  description = "Local path to the Next.js static export output directory"
  type        = string
  default     = "../frontend/out"
}

variable "cors_origin" {
  description = "Allowed CORS origin. Set to CloudFront URL after first deploy."
  type        = string
  default     = "*"
}

variable "cloudfront_price_class" {
  description = "CloudFront price class"
  type        = string
  default     = "PriceClass_100"  # US, Canada, Europe only — cheapest
}

variable "job_ttl_hours" {
  description = "Hours before DynamoDB job records expire (TTL)"
  type        = number
  default     = 24
}

variable "api_throttle_rate" {
  description = "API Gateway throttle rate limit (requests/second)"
  type        = number
  default     = 20
}

variable "api_throttle_burst" {
  description = "API Gateway throttle burst limit"
  type        = number
  default     = 50
}

variable "spoke_role_name" {
  description = "Name of the IAM role deployed in every spoke (target) account. The central Lambda assumes arn:aws:iam::{account_id}:role/{spoke_role_name}."
  type        = string
  default     = "eks-agent-spoke-role"
}

# Map of spoke account IDs → human-readable labels.
# This is the single place to register all target accounts.
#
# In terraform.tfvars:
#   spoke_accounts = {
#     "123456789012" = "Production"
#     "234567890123" = "Staging"
#     "345678901234" = "Dev"
#   }
variable "spoke_accounts" {
  description = "Map of spoke AWS account IDs to human-readable labels. Keys must be 12-digit account IDs."
  type        = map(string)
  default     = {}
}

variable "deploy_spoke_roles" {
  description = "When true, Terraform automatically deploys the spoke IAM role CloudFormation stack into every account in spoke_accounts by assuming bootstrap_role_name."
  type        = bool
  default     = true
}

variable "bootstrap_role_name" {
  description = "IAM role name that already exists in each member account and trusts the master account. Terraform assumes this role to deploy the spoke CloudFormation stack. AWS creates OrganizationAccountAccessRole automatically in accounts provisioned via AWS Organizations."
  type        = string
  default     = "OrganizationAccountAccessRole"
}

variable "eks_regions" {
  description = "Comma-separated list of AWS regions scanned by list_clusters when no region filter is supplied."
  type        = string
  default     = "us-east-1,us-east-2,us-west-1,us-west-2,eu-west-1,eu-west-2,eu-central-1,ap-southeast-1,ap-southeast-2,ap-northeast-1"
}

# ---------------------------------------------------------------------------
# Networking — bring-your-own (default) or let Terraform create it
# ---------------------------------------------------------------------------

variable "create_networking" {
  description = "When false (default): provide existing vpc_subnet_ids and vpc_security_group_ids — Terraform creates no VPC resources. When true: Terraform creates a VPC, private subnets, NAT Gateway, and optional VPC endpoints."
  type        = bool
  default     = false
}

variable "vpc_subnet_ids" {
  description = "Existing private subnet IDs for Lambda ENIs. Required when create_networking = false."
  type        = list(string)
  default     = []
}

variable "vpc_security_group_ids" {
  description = "Existing SG IDs for Lambda ENIs. Required when create_networking = false."
  type        = list(string)
  default     = []
}

# --- Options used only when create_networking = true ----------------------

variable "vpc_cidr" {
  description = "CIDR block for the new VPC (only when create_networking = true)."
  type        = string
  default     = "10.100.0.0/16"
}

variable "availability_zones" {
  description = "AZs for private subnets (only when create_networking = true). Defaults to first 2 in the region."
  type        = list(string)
  default     = []
}

variable "create_vpc_endpoints" {
  description = "When create_networking = true, also create VPC Gateway endpoint for DynamoDB/S3 and Interface endpoints for STS, EKS, EC2, ELB, IAM, CloudWatch Logs. Reduces NAT Gateway traffic."
  type        = bool
  default     = true
}

variable "spoke_vpc_cidrs" {
  description = "CIDR ranges of spoke-account VPCs. Lambda SG will allow HTTPS egress to these CIDRs (only when create_networking = true). If empty, egress 0.0.0.0/0 is used."
  type        = list(string)
  default     = []
}

# --- Transit Gateway attachment (optional, works with both modes) ----------

variable "attach_to_existing_tgw" {
  description = "When true, create a Transit Gateway VPC attachment on the central VPC. Use this if your existing TGW needs the central VPC attached. If VPC peering or TGW attachments already exist, leave false."
  type        = bool
  default     = false
}

variable "existing_tgw_id" {
  description = "ID of the existing Transit Gateway to attach to (required when attach_to_existing_tgw = true)."
  type        = string
  default     = ""
}

variable "existing_vpc_id" {
  description = "VPC ID of the central VPC (required when attach_to_existing_tgw = true AND create_networking = false)."
  type        = string
  default     = ""
}

variable "tags" {
  description = "Additional resource tags"
  type        = map(string)
  default     = {}
}
