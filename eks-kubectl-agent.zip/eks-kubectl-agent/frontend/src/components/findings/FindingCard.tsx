'use client'
import { useState } from 'react'
import { ChevronDown, ChevronRight, Copy, Check } from 'lucide-react'
import { SeverityBadge } from '@/components/common/SeverityBadge'
import { cn } from '@/lib/utils'
import type { Finding } from '@/lib/types'

interface Props {
  finding: Finding
  defaultOpen?: boolean
}

export function FindingCard({ finding, defaultOpen = false }: Props) {
  const [open, setOpen] = useState(defaultOpen)
  const [copied, setCopied] = useState(false)

  function copyCmd(cmd: string) {
    navigator.clipboard.writeText(cmd)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="rounded-lg border border-slate-700/60 bg-slate-800/40 overflow-hidden">
      {/* Header row */}
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-slate-700/30 transition-colors"
      >
        {open ? (
          <ChevronDown size={14} className="text-slate-500 shrink-0" />
        ) : (
          <ChevronRight size={14} className="text-slate-500 shrink-0" />
        )}
        <SeverityBadge severity={finding.severity} />
        <span className="text-sm font-medium text-slate-200 truncate">{finding.resource}</span>
        <span className="text-xs text-slate-500 ml-auto shrink-0">
          {finding.namespace !== 'aws' && finding.namespace !== 'cluster'
            ? `ns: ${finding.namespace}`
            : finding.namespace}
        </span>
      </button>

      {/* Expanded body */}
      {open && (
        <div className="px-4 pb-4 space-y-3 border-t border-slate-700/40">
          {/* Impact */}
          <div className="pt-3">
            <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Impact</p>
            <p className="text-sm text-slate-300">{finding.impact}</p>
          </div>

          {/* Evidence */}
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Evidence</p>
            <pre className="log-output text-xs bg-slate-900/60 rounded p-3 text-slate-300 border border-slate-700/40 overflow-x-auto">
              {finding.evidence}
            </pre>
          </div>

          {/* Recommended fix */}
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Recommended Fix</p>
            <p className="text-sm text-slate-300">{finding.recommended_fix}</p>
          </div>

          {/* Fix command */}
          {finding.fix_command && (
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Fix Command</p>
              <div className="relative group">
                <pre className="log-output text-xs bg-slate-900/60 rounded p-3 text-green-300 border border-slate-700/40 overflow-x-auto pr-10">
                  {finding.fix_command}
                </pre>
                <button
                  onClick={() => copyCmd(finding.fix_command!)}
                  className="absolute top-2 right-2 p-1.5 rounded text-slate-500 hover:text-slate-300 hover:bg-slate-700/50 transition-all opacity-0 group-hover:opacity-100"
                >
                  {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
                </button>
              </div>
            </div>
          )}

          {/* Fix ID */}
          {finding.fix_id && (
            <p className="text-xs text-slate-600">Fix ID: <code className="text-slate-500">{finding.fix_id}</code></p>
          )}
        </div>
      )}
    </div>
  )
}
