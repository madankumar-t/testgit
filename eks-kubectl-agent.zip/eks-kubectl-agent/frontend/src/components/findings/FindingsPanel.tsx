'use client'
import { useState, useMemo } from 'react'
import { FindingCard } from './FindingCard'
import { SeverityBadge } from '@/components/common/SeverityBadge'
import type { Finding, Severity } from '@/lib/types'
import { SEVERITY_ORDER } from '@/lib/types'

const COMPONENTS = [
  'All', 'Nodes', 'Pods', 'Deployments', 'Services', 'Ingress / ALB',
  'AWS Load Balancer Controller', 'Networking', 'DNS', 'Storage',
  'IAM / IRSA', 'Logs and Events', 'Autoscaling', 'Security / RBAC',
]

interface Props { findings: Finding[] }

export function FindingsPanel({ findings }: Props) {
  const [activeComponent, setActiveComponent] = useState('All')
  const [activeSeverity, setActiveSeverity] = useState<Severity | 'All'>('All')
  const [search, setSearch] = useState('')

  const filtered = useMemo(() => {
    return findings
      .filter((f) => activeComponent === 'All' || f.component === activeComponent)
      .filter((f) => activeSeverity === 'All' || f.severity === activeSeverity)
      .filter((f) => {
        if (!search) return true
        const q = search.toLowerCase()
        return (
          f.resource.toLowerCase().includes(q) ||
          f.namespace.toLowerCase().includes(q) ||
          f.impact.toLowerCase().includes(q) ||
          f.evidence.toLowerCase().includes(q)
        )
      })
      .sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity])
  }, [findings, activeComponent, activeSeverity, search])

  const components = useMemo(() => {
    const set = new Set(findings.map((f) => f.component))
    return ['All', ...COMPONENTS.slice(1).filter((c) => set.has(c))]
  }, [findings])

  const severityCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const f of findings) counts[f.severity] = (counts[f.severity] ?? 0) + 1
    return counts
  }, [findings])

  if (!findings.length) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <p className="text-4xl mb-3">✅</p>
        <p className="text-sm">No issues detected</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Severity filter pills */}
      <div className="flex flex-wrap gap-2">
        {(['All', 'Critical', 'High', 'Medium', 'Low'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setActiveSeverity(s)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all
              ${activeSeverity === s
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                : 'bg-slate-800 text-slate-400 border border-slate-700 hover:border-slate-500'}`}
          >
            {s === 'All' ? `All (${findings.length})` : `${s} (${severityCounts[s] ?? 0})`}
          </button>
        ))}
      </div>

      <div className="flex gap-4">
        {/* Component sidebar */}
        <div className="w-52 shrink-0 space-y-1">
          {components.map((c) => (
            <button
              key={c}
              onClick={() => setActiveComponent(c)}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-all
                ${activeComponent === c
                  ? 'bg-blue-500/15 text-blue-300 border border-blue-500/25'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/40'}`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Findings list */}
        <div className="flex-1 space-y-2">
          {/* Search */}
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search findings…"
            className="w-full px-3 py-2 text-sm bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500/50"
          />

          <p className="text-xs text-slate-500">
            Showing {filtered.length} of {findings.length} findings
          </p>

          {filtered.length === 0 ? (
            <p className="text-sm text-slate-500 py-8 text-center">No findings match the current filter.</p>
          ) : (
            filtered.map((f, i) => (
              <FindingCard key={`${f.fix_id}-${i}`} finding={f} />
            ))
          )}
        </div>
      </div>
    </div>
  )
}
