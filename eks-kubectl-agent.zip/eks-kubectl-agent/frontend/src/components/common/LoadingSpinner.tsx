import { cn } from '@/lib/utils'

interface Props { className?: string; size?: 'sm' | 'md' | 'lg' }

export function LoadingSpinner({ className, size = 'md' }: Props) {
  const dim = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-10 h-10' }[size]
  return (
    <div
      className={cn(
        'rounded-full border-2 border-slate-700 border-t-blue-500 animate-spin',
        dim,
        className
      )}
    />
  )
}

export function PageLoader({ message = 'Loading...' }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-64 gap-4">
      <LoadingSpinner size="lg" />
      <p className="text-slate-400 text-sm">{message}</p>
    </div>
  )
}
