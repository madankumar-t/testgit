import { cn, statusBg, statusColor, statusLabel } from '@/lib/utils'
import type { JobStatus } from '@/lib/types'

interface Props {
  status: JobStatus
  className?: string
  pulse?: boolean
}

export function StatusBadge({ status, className, pulse }: Props) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border',
        statusBg(status),
        statusColor(status),
        className
      )}
    >
      <span
        className={cn(
          'w-1.5 h-1.5 rounded-full',
          status === 'running' && pulse ? 'pulse-blue bg-blue-500' : '',
          status === 'complete' ? 'bg-green-500' : '',
          status === 'failed' ? 'bg-red-500' : '',
          status === 'pending' ? 'bg-slate-500' : '',
        )}
      />
      {statusLabel(status)}
    </span>
  )
}
