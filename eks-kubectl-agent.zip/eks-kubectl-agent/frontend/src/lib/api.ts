import axios from 'axios'
import type {
  AccountInfo,
  ApplyFixRequest,
  ApplyFixResponse,
  ClusterInfo,
  DiagnosisJob,
  LogRequest,
  LogResponse,
  PodInfo,
  StartDiagnoseRequest,
  StartDiagnoseResponse,
} from './types'

const BASE_URL = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? ''

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 60_000,
  headers: { 'Content-Type': 'application/json' },
})

// -------------------------------------------------------------------------
// Diagnosis
// -------------------------------------------------------------------------

export async function startDiagnosis(
  req: StartDiagnoseRequest
): Promise<StartDiagnoseResponse> {
  const { data } = await api.post<StartDiagnoseResponse>('/api/v1/diagnose', req)
  return data
}

export async function getDiagnosis(jobId: string): Promise<DiagnosisJob> {
  const { data } = await api.get<DiagnosisJob>(`/api/v1/diagnose/${jobId}`)
  return data
}

// -------------------------------------------------------------------------
// Logs
// -------------------------------------------------------------------------

export async function getPodLogs(req: LogRequest): Promise<LogResponse> {
  const { data } = await api.post<LogResponse>('/api/v1/logs', req)
  return data
}

export async function listPods(
  clusterName: string,
  region: string,
  namespace: string
): Promise<PodInfo[]> {
  const { data } = await api.post<{ pods: PodInfo[] }>(
    '/api/v1/logs?action=list_pods',
    { cluster_name: clusterName, region, namespace }
  )
  return data.pods
}

// -------------------------------------------------------------------------
// Multi-account / cluster discovery
// -------------------------------------------------------------------------

export async function listAccounts(): Promise<AccountInfo[]> {
  const { data } = await api.get<{ accounts: AccountInfo[] }>('/api/v1/accounts')
  return data.accounts
}

export async function listClusters(
  accountId: string,
  region?: string
): Promise<ClusterInfo[]> {
  const params: Record<string, string> = { account_id: accountId }
  if (region) params.region = region
  const { data } = await api.get<{ clusters: ClusterInfo[] }>('/api/v1/clusters', { params })
  return data.clusters
}

// -------------------------------------------------------------------------
// Fix
// -------------------------------------------------------------------------

export async function applyFix(req: ApplyFixRequest): Promise<ApplyFixResponse> {
  const { data } = await api.post<ApplyFixResponse>('/api/v1/fix/apply', req)
  return data
}

// -------------------------------------------------------------------------
// Local history (stored in localStorage)
// -------------------------------------------------------------------------

const HISTORY_KEY = 'eks-agent:history'
const MAX_HISTORY = 20

export interface HistoryEntry {
  job_id: string
  cluster_name: string
  account_id: string
  region: string
  status: string
  started_at: string
}

export function saveToHistory(entry: HistoryEntry): void {
  if (typeof window === 'undefined') return
  const existing: HistoryEntry[] = getHistory()
  const updated = [entry, ...existing.filter((e) => e.job_id !== entry.job_id)].slice(
    0,
    MAX_HISTORY
  )
  localStorage.setItem(HISTORY_KEY, JSON.stringify(updated))
}

export function getHistory(): HistoryEntry[] {
  if (typeof window === 'undefined') return []
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) ?? '[]')
  } catch {
    return []
  }
}

export function updateHistoryStatus(jobId: string, status: string): void {
  if (typeof window === 'undefined') return
  const existing = getHistory()
  const updated = existing.map((e) => (e.job_id === jobId ? { ...e, status } : e))
  localStorage.setItem(HISTORY_KEY, JSON.stringify(updated))
}
