import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import type { Severity, FixRisk, JobStatus } from './types'

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs))
}

export function severityColor(severity: Severity): string {
  return {
    Critical: 'text-red-400',
    High: 'text-orange-400',
    Medium: 'text-yellow-400',
    Low: 'text-green-400',
    Info: 'text-slate-400',
  }[severity] ?? 'text-slate-400'
}

export function severityBg(severity: Severity): string {
  return {
    Critical: 'bg-red-500/10 border border-red-500/30',
    High: 'bg-orange-500/10 border border-orange-500/30',
    Medium: 'bg-yellow-500/10 border border-yellow-500/30',
    Low: 'bg-green-500/10 border border-green-500/30',
    Info: 'bg-slate-500/10 border border-slate-500/30',
  }[severity] ?? 'bg-slate-500/10'
}

export function severityDot(severity: Severity): string {
  return {
    Critical: 'bg-red-500',
    High: 'bg-orange-500',
    Medium: 'bg-yellow-500',
    Low: 'bg-green-500',
    Info: 'bg-slate-500',
  }[severity] ?? 'bg-slate-500'
}

export function riskColor(risk: FixRisk): string {
  return { High: 'text-red-400', Medium: 'text-yellow-400', Low: 'text-green-400' }[risk] ?? 'text-slate-400'
}

export function statusColor(status: JobStatus): string {
  return {
    pending: 'text-slate-400',
    running: 'text-blue-400',
    complete: 'text-green-400',
    failed: 'text-red-400',
  }[status] ?? 'text-slate-400'
}

export function statusBg(status: JobStatus): string {
  return {
    pending: 'bg-slate-500/10 border-slate-500/30',
    running: 'bg-blue-500/10 border-blue-500/30',
    complete: 'bg-green-500/10 border-green-500/30',
    failed: 'bg-red-500/10 border-red-500/30',
  }[status] ?? ''
}

export function statusLabel(status: JobStatus): string {
  return { pending: 'Pending', running: 'Running', complete: 'Complete', failed: 'Failed' }[status] ?? status
}

export function formatRelativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const s = Math.floor(diff / 1000)
  if (s < 60) return `${s}s ago`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  return `${Math.floor(h / 24)}d ago`
}

export function formatDuration(start: string, end?: string): string {
  const from = new Date(start).getTime()
  const to = end ? new Date(end).getTime() : Date.now()
  const s = Math.floor((to - from) / 1000)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  return `${m}m ${s % 60}s`
}

export function truncate(str: string, max = 80): string {
  return str.length > max ? str.slice(0, max) + '…' : str
}
