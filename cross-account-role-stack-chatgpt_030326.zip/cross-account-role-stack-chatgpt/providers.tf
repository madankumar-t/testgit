# Default provider: used by Spacelift (Sharedsvcs2 account credentials)
provider "aws" {
  region = var.region
}

# Target account providers: Spacelift assumes a role in each account to create resources.
# Terraform requires static provider blocks; aliases must match the keys in var.target_accounts.
provider "aws" {
  alias  = "sandbox1"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["sandbox1"]}:role/${var.spacelift_execution_role_name}"
  }
}

provider "aws" {
  alias  = "sandbox2"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["sandbox2"]}:role/${var.spacelift_execution_role_name}"
  }
}

provider "aws" {
  alias  = "security"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["security"]}:role/${var.spacelift_execution_role_name}"
  }
}
