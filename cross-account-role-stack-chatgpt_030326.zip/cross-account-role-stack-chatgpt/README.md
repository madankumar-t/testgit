# Cross-Account IAM Role Stack (Spacelift)

Creates the **same IAM role** in multiple target AWS accounts (Sandbox1, Sandbox2, Security) with a **single trust policy** so the **Sharedsvcs2** account can assume those roles and run actions in each account. Everything is managed with **one Spacelift stack**.

---

## Architecture (What This Does)

```
Sharedsvcs2 (source account)
    │
    ├──► Sandbox1  ──►  IAM Role (Trust Policy + Policy)
    ├──► Sandbox2  ──►  IAM Role (Trust Policy + Policy)
    └──► Security   ──►  IAM Role (Trust Policy + Policy)
```

- **Sharedsvcs2**: Account where Spacelift runs and where your team assumes roles. This account “owns” the ability to assume the roles in the other accounts.
- **Sandbox1, Sandbox2, Security**: Target accounts. In each, this stack creates one IAM role with:
  - **Trust policy**: Only the Sharedsvcs2 account (`arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root`) is allowed to assume the role.
  - **Permissions policy**: Same policy in every account (e.g. S3 list/get, EC2 describe). You can change this in the module.

So: **one stack, one trust policy, one role name in three accounts**; Sharedsvcs2 can assume and execute in Sandbox1, Sandbox2, and Security.

---

## What Gets Created in Each Target Account

In **every** target account (Sandbox1, Sandbox2, Security), this stack creates:

| Resource | Description |
|----------|-------------|
| **IAM Role** | `crossaccountrolewithsharedsvcs2` |
| **Trust policy** | Attached to the role via `assume_role_policy` — allows only Sharedsvcs2 (`arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root`) to call `sts:AssumeRole`. |
| **IAM Policy** | A managed policy (e.g. `crossaccountrolewithsharedsvcs2-policy`) with the permissions (S3, EC2 describe, etc.). |
| **Policy attachment** | The permissions policy is attached to the role so the role has both the trust relationship and the permissions. |

So in each account you get: **role + trust policy + permissions policy + attachment**. No extra steps required.

---

## Input: Only AWS Account Numbers

You only need to provide **AWS account IDs** (and the Sharedsvcs2 account ID). No need to specify role names per account.

- **`sharedsvcs2_account_id`** — 12-digit account ID of Sharedsvcs2.
- **`target_accounts`** — Map of logical name → account ID, e.g. `sandbox1 = "222222222222"`, `sandbox2 = "333333333333"`, `security = "444444444444"`.

Optional: **`spacelift_execution_role_name`** — Name of the role Spacelift assumes in each target account (default: `SpaceliftExecutionRole`). Only change this if you use a different role name.

---

## Checklist

| Requirement | How It’s Done |
|------------|----------------|
| Same IAM role in multiple accounts | `for_each` over `target_accounts` (Sandbox1, Sandbox2, Security); one `cross-account-role` module per account. |
| Same trust policy | Single module `modules/cross-account-role` defines the trust policy; every account gets the same document. |
| Sharedsvcs2 can assume roles | Trust policy allows `arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root` with `sts:AssumeRole`. |
| Managed in Spacelift | One Spacelift stack; stack uses AWS integration for Sharedsvcs2 and assumes a role in each target account to create the role. |

---

## Role Name and Trust Policy

- **Role name (in each target account):** `crossaccountrolewithsharedsvcs2`
- **Trust policy:** Allows the Sharedsvcs2 account root to call `sts:AssumeRole` on this role.

Defined in `modules/cross-account-role/main.tf`:

- Trust: `arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root` → `sts:AssumeRole`
- Permissions: Custom policy (e.g. S3 list/get, EC2 describe). Adjust in the module if needed.

---

## Prerequisites

1. **SpaceliftExecutionRole (or equivalent) in each target account**  
   In Sandbox1, Sandbox2, and Security you need a role that:
   - Spacelift (running in Sharedsvcs2) can assume (e.g. trust Spacelift’s OIDC or Sharedsvcs2 account).
   - Has permissions to create/update/delete IAM roles and policies (e.g. `iam:CreateRole`, `iam:PutRolePolicy`, `iam:AttachRolePolicy`, etc.).

2. **Spacelift AWS integration**  
   In Spacelift, attach an AWS integration that uses **Sharedsvcs2** credentials (e.g. OIDC or access keys for Sharedsvcs2). The stack will use this to assume the execution role in each target account.

3. **Terraform variables**  
   You must set:
   - `sharedsvcs2_account_id` = Sharedsvcs2 account ID (e.g. `"111111111111"`).
   - `target_accounts` = map of logical name → account ID only (see `terraform.tfvars.example`).

---

## Repo Layout

```
.
├── .spacelift/
│   └── config.yml          # Spacelift stack config (project root, Terraform version)
├── modules/
│   └── cross-account-role/
│       ├── main.tf         # IAM role, trust policy, custom policy
│       ├── variables.tf
│       └── outputs.tf      # role_arn
├── main.tf                 # for_each over target_accounts → module per account
├── providers.tf            # Default provider + aliased providers (assume role per account)
├── variables.tf
├── outputs.tf              # role_arns, role_arn_list
├── versions.tf
├── terraform.tfvars.example
└── README.md
```

---

## Spacelift Setup (Step by Step)

1. **Create a stack** in Spacelift and connect this repository.
2. **Set the stack slug** (or name) so it matches the key under `stacks` in `.spacelift/config.yml` (e.g. `cross-account-role-stack`).
3. **Attach the AWS integration** that uses the **Sharedsvcs2** account (the one that will assume the cross-account roles).
4. **Set Terraform variables** (in the stack’s “Terraform variables” or via `terraform.tfvars` in the repo):
   - `sharedsvcs2_account_id` = your Sharedsvcs2 account ID.
   - `target_accounts` = map of name → account ID only, e.g. `sandbox1 = "222222222222"`, `sandbox2 = "333333333333"`, `security = "444444444444"`.
5. **Run Plan / Apply.**  
   Spacelift will use Sharedsvcs2 credentials, assume `SpaceliftExecutionRole` in each target account, and create the IAM role with the same name and trust policy in Sandbox1, Sandbox2, and Security.

---

## Config and Variables

- **`terraform.tfvars.example`**  
  Copy to `terraform.tfvars` and set real account IDs (only account numbers):

  - `sharedsvcs2_account_id`: Sharedsvcs2 account ID (e.g. `"111111111111"`).
  - `target_accounts`: map of logical name → 12-digit AWS account ID (e.g. `sandbox1 = "222222222222"`). Optionally set `spacelift_execution_role_name` if you use a different role name than `SpaceliftExecutionRole`.

- **`.spacelift/config.yml`**  
  Sets project root and Terraform version for the stack. Adjust `terraform_version` if you need a different one.

---

## Outputs

After apply, the stack exposes:

- **`role_arns`**: Map of account key → role ARN (e.g. `sandbox1` → `arn:aws:iam::222222222222:role/crossaccountrolewithsharedsvcs2`).
- **`role_arn_list`**: List of all created role ARNs.

Use these in Sharedsvcs2 (e.g. in other automation or IAM policies) when assuming these roles.

---

## How Sharedsvcs2 Assumes the Roles

From the **Sharedsvcs2** account, users or automation can assume the role in a target account, for example:

```bash
aws sts assume-role \
  --role-arn "arn:aws:iam::TARGET_ACCOUNT_ID:role/crossaccountrolewithsharedsvcs2" \
  --role-session-name "my-session"
```

Use the returned credentials to call APIs in Sandbox1, Sandbox2, or Security. The same role name and trust policy are used in all three accounts.

---

## Summary

- **One Spacelift stack** creates the **same IAM role** in **Sandbox1, Sandbox2, and Security**.
- **Same trust policy**: only **Sharedsvcs2** can assume the role.
- **Sharedsvcs2** can assume and execute in all three target accounts.
- **Spacelift** manages the lifecycle (plan/apply/destroy) using one stack and the repo’s `.spacelift/config.yml`.
