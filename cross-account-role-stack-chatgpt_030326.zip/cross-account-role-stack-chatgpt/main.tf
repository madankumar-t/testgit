# Create the same IAM role (with trust policy + permissions policy) in each target account.
# Terraform requires static provider references, so we use one module per account.

module "cross_account_role_sandbox1" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.sandbox1
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}

module "cross_account_role_sandbox2" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.sandbox2
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}

module "cross_account_role_security" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.security
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}
