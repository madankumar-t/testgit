# Role ARNs created in each target account (for Sharedsvcs2 to assume)
output "role_arns" {
  description = "Map of account key to IAM role ARN created in that account"
  value = {
    sandbox1 = module.cross_account_role_sandbox1.role_arn
    sandbox2 = module.cross_account_role_sandbox2.role_arn
    security = module.cross_account_role_security.role_arn
  }
}

# Convenience: list of all role ARNs (e.g. for automation or documentation)
output "role_arn_list" {
  description = "List of all cross-account role ARNs"
  value = [
    module.cross_account_role_sandbox1.role_arn,
    module.cross_account_role_sandbox2.role_arn,
    module.cross_account_role_security.role_arn,
  ]
}
