variable "region" {
  description = "AWS region for provider configuration"
  type        = string
  default     = "us-east-1"
}

variable "sharedsvcs2_account_id" {
  description = "AWS account ID of Sharedsvcs2 (the account that will assume the roles)"
  type        = string
}

variable "target_accounts" {
  description = "Map of logical name to AWS account ID. Keys must be: sandbox1, sandbox2, security. Only account numbers are required."
  type        = map(string)

  validation {
    condition     = keys(var.target_accounts) == toset(["sandbox1", "sandbox2", "security"])
    error_message = "target_accounts must have exactly these keys: sandbox1, sandbox2, security."
  }
}

variable "spacelift_execution_role_name" {
  description = "Name of the IAM role that Spacelift assumes in each target account to create resources"
  type        = string
  default     = "SpaceliftExecutionRole"
}
