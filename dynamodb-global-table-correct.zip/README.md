# Terraform DynamoDB Global Table (Correct)

This project creates a REAL DynamoDB Global Table using:
- DynamoDB Streams
- replica {} blocks (Global Tables v2)

Toggle using:
table_mode = REGIONAL | GLOBAL
