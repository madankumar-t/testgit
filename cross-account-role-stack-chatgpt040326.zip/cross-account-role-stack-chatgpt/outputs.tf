# Role ARNs created in each account (trust policy: SharedSvc2 only)
output "role_arns" {
  description = "Map of account key to IAM role ARN created in that account"
  value = {
    dcli_sharedsvcs2   = module.cross_account_role_dcli_sharedsvcs2.role_arn
    dcli_sandbox1      = module.cross_account_role_dcli_sandbox1.role_arn
    dcli_sandbox2      = module.cross_account_role_dcli_sandbox2.role_arn
    dcli_security_test = module.cross_account_role_dcli_security_test.role_arn
  }
}

# Convenience: list of all role ARNs (e.g. for automation or documentation)
output "role_arn_list" {
  description = "List of all cross-account role ARNs"
  value = [
    module.cross_account_role_dcli_sharedsvcs2.role_arn,
    module.cross_account_role_dcli_sandbox1.role_arn,
    module.cross_account_role_dcli_sandbox2.role_arn,
    module.cross_account_role_dcli_security_test.role_arn,
  ]
}
