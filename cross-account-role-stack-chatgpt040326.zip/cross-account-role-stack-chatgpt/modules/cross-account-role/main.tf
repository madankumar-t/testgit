# -----------------------------------------------------------------------------
# Trust policy: only Sharedsvcs2 account can assume this role
# -----------------------------------------------------------------------------
data "aws_iam_policy_document" "trust_policy" {
  statement {
    effect = "Allow"

    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${var.sharedsvcs2_account_id}:root"]
    }

    actions = ["sts:AssumeRole"]
  }
}

# -----------------------------------------------------------------------------
# IAM Role with trust policy attached (created in each target account)
# -----------------------------------------------------------------------------
resource "aws_iam_role" "cross_account_role" {
  name               = var.role_name
  assume_role_policy = data.aws_iam_policy_document.trust_policy.json
}

# -----------------------------------------------------------------------------
# Permissions policy (what the role can do when assumed by Sharedsvcs2)
# -----------------------------------------------------------------------------
data "aws_iam_policy_document" "custom_policy_doc" {
  statement {
    effect = "Allow"

    actions = [
      "s3:ListBucket",
      "s3:GetObject",
      "ec2:DescribeInstances",
      "ec2:DescribeVolumes"
    ]

    resources = ["*"]
  }
}

resource "aws_iam_policy" "custom_policy" {
  name   = "${var.role_name}-policy"
  policy = data.aws_iam_policy_document.custom_policy_doc.json
}

# -----------------------------------------------------------------------------
# Attach the permissions policy to the role
# -----------------------------------------------------------------------------
resource "aws_iam_role_policy_attachment" "attach_custom" {
  role       = aws_iam_role.cross_account_role.name
  policy_arn = aws_iam_policy.custom_policy.arn
}
