variable "sharedsvcs2_account_id" {
  type = string
}

variable "role_name" {
  type = string
}
