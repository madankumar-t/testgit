# Default provider: used by Spacelift (e.g. SharedSvc2 or runner account credentials)
provider "aws" {
  region = var.region
}

# Target account providers: Spacelift assumes a role in each account to create resources.
# Four accounts: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test.
# Trust policy on the created role is always SharedSvc2 account only.
provider "aws" {
  alias  = "dcli_sharedsvcs2"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["dcli_sharedsvcs2"]}:role/${var.spacelift_execution_role_name}"
  }
}

provider "aws" {
  alias  = "dcli_sandbox1"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["dcli_sandbox1"]}:role/${var.spacelift_execution_role_name}"
  }
}

provider "aws" {
  alias  = "dcli_sandbox2"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["dcli_sandbox2"]}:role/${var.spacelift_execution_role_name}"
  }
}

provider "aws" {
  alias  = "dcli_security_test"
  region = var.region
  assume_role {
    role_arn = "arn:aws:iam::${var.target_accounts["dcli_security_test"]}:role/${var.spacelift_execution_role_name}"
  }
}
