# Cross-Account IAM Role Stack (Spacelift)

Creates the **same IAM role** (IAM Role + IAM Policy + Trust Policy) in **four** AWS accounts using **one Spacelift stack**. **Trust policy is always SharedSvc2 account only** — only SharedSvc2 (975678945875) can assume the role in every account.

---

## Architecture (What This Does)

```
Spacelift
    │
    ├──► dcli_sharedsvcs2   ──►  IAM Role + IAM Policy + Trust Policy (SharedSvc2 only)
    ├──► dcli_sandbox1      ──►  IAM Role + IAM Policy + Trust Policy (SharedSvc2 only)
    ├──► dcli_sandbox2      ──►  IAM Role + IAM Policy + Trust Policy (SharedSvc2 only)
    └──► dcli_security_test ──►  IAM Role + IAM Policy + Trust Policy (SharedSvc2 only)
```

- **Spacelift** runs this stack and deploys to all four accounts (assuming an execution role in each).
- **dcli_sharedsvcs2 (975678945875)**: SharedSvc2 account; the only principal allowed to assume the created role in any account.
- **dcli_sandbox1, dcli_sandbox2, dcli_security_test**: In each, this stack creates the same IAM role with:
  - **Trust policy**: Only SharedSvc2 (`arn:aws:iam::975678945875:root` or your `sharedsvcs2_account_id`) can assume the role.
  - **Permissions policy**: Same in every account (e.g. S3, EC2 describe). Adjust in the module.

So: **one stack, four accounts, same role name, trust policy is always SharedSvc2 only**.

---

## What Gets Created in Each Account

In **each** of the four accounts (dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test), this stack creates:

| Resource | Description |
|----------|-------------|
| **IAM Role** | `crossaccountrolewithsharedsvcs2` |
| **Trust policy** | Attached to the role — **SharedSvc2 account only** (`arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root` can call `sts:AssumeRole`). |
| **IAM Policy** | A managed policy (e.g. `crossaccountrolewithsharedsvcs2-policy`) with the permissions (S3, EC2 describe, etc.). |
| **Policy attachment** | The permissions policy is attached to the role. |

---

## Input: Only AWS Account Numbers

- **`sharedsvcs2_account_id`** — 12-digit account ID of SharedSvc2 (trust policy allows this account only).
- **`target_accounts`** — Map with keys: `dcli_sharedsvcs2`, `dcli_sandbox1`, `dcli_sandbox2`, `dcli_security_test` → account IDs (e.g. `dcli_sharedsvcs2 = "975678945875"`, `dcli_sandbox1 = "529088296711"`, …).

Optional: **`spacelift_execution_role_name`** — Role name Spacelift assumes in each account to run this stack (default: `SpaceliftExecutionRole`).

---

## Checklist

| Requirement | How It’s Done |
|------------|----------------|
| Stacks in multiple accounts via Spacelift | One Spacelift stack; one `cross-account-role` module per account (dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test). |
| Same IAM role + policy + trust in all four | Single module creates IAM Role, IAM Policy, and Trust Policy in each account. |
| Trust policy is always SharedSvc2 only | Trust policy allows only `arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root` to `sts:AssumeRole`. |
| Managed in Spacelift | One stack; Spacelift assumes an execution role in each account to create the role. |

---

## Role Name and Trust Policy

- **Role name (in each account):** `crossaccountrolewithsharedsvcs2`
- **Trust policy:** **SharedSvc2 account only** — allows `arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root` to call `sts:AssumeRole` on this role.

Defined in `modules/cross-account-role/main.tf`:

- Trust: `arn:aws:iam::SHAREDSVCS2_ACCOUNT_ID:root` → `sts:AssumeRole`
- Permissions: Custom policy (e.g. S3 list/get, EC2 describe). Adjust in the module if needed.

---

## Prerequisites

1. **Execution role in each of the four accounts**  
   In dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, and dcli_security_test you need a role (e.g. `SpaceliftExecutionRole` or `spacelift_iac`) that:
   - Spacelift can assume (trust the account/OIDC where Spacelift runs).
   - Has permissions to create/update/delete IAM roles and policies.

2. **Spacelift AWS integration**  
   Attach an AWS integration in Spacelift. The stack will assume that execution role in each of the four accounts to create the IAM role (trust policy: SharedSvc2 only).

3. **Terraform variables**  
   - `sharedsvcs2_account_id` = SharedSvc2 account ID (e.g. `"975678945875"`). **Trust policy is always this account only.**
   - `target_accounts` = map with keys `dcli_sharedsvcs2`, `dcli_sandbox1`, `dcli_sandbox2`, `dcli_security_test` → account IDs (see `terraform.tfvars.example`).

---

## Fixing 403 (AssumeRole) when using the same Spacelift role in all accounts

Spacelift runs with **one** AWS integration (one account + one role, e.g. `spacelift_iac`). This stack then tries to **assume that same role** in each of the **four** accounts (dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test). You get **403 AccessDenied** if that execution role in an account does not trust the account Spacelift runs from.

**What’s happening**

- **Caller:** `arn:aws:sts::RUNNER_ACCOUNT:assumed-role/ROLE_NAME/session-id` (e.g. Spacelift in `687360398174` with role `spacelift_iac`).
- **Target:** For each of the four accounts, Terraform calls `AssumeRole` on `arn:aws:iam::TARGET_ACCOUNT:role/ROLE_NAME`.
- **403** means: in that target account, the role `ROLE_NAME` either doesn’t exist or its **trust policy** does not allow that caller to assume it.

**Fix: trust policy on the execution role in every target account**

The role that Spacelift assumes (e.g. `spacelift_iac`) must exist in **each** target account and must trust the **Spacelift runner account** (the account where your Spacelift AWS integration runs). Use one of the trust policies below.

Replace `RUNNER_ACCOUNT_ID` with the account where Spacelift runs (e.g. `687360398174`). Replace `spacelift_iac` with your `spacelift_execution_role_name` if different.

**Option A – Trust the whole runner account (simplest)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::RUNNER_ACCOUNT_ID:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Option B – Trust only the runner role (more restrictive)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::RUNNER_ACCOUNT_ID:role/spacelift_iac"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Same account (e.g. Sandbox2 = runner account)**

If one of your “target” accounts is the **same** as the runner account (e.g. Sandbox2 = `687360398174`), the role in that account must still be assumable from the same account. Option A (`root`) allows that. If you use Option B, add a second statement so the role can assume itself:

```json
{
  "Effect": "Allow",
  "Principal": {
    "AWS": "arn:aws:iam::RUNNER_ACCOUNT_ID:role/spacelift_iac"
  },
  "Action": "sts:AssumeRole"
}
```

(So in the runner account, the role’s trust policy should allow at least `arn:aws:iam::RUNNER_ACCOUNT_ID:root` or `arn:aws:iam::RUNNER_ACCOUNT_ID:role/spacelift_iac`.)

**Summary**

| Where | What to do |
|-------|------------|
| **Runner account** (e.g. 687360398174) | Role `spacelift_iac` must trust `arn:aws:iam::687360398174:root` (or the same role ARN) so same-account assume works. |
| **Other target accounts** (e.g. 529088296711, 307946672793) | Create role `spacelift_iac` (or your name) with a trust policy that allows `arn:aws:iam::687360398174:root` (or the runner role ARN). |

After these trust policies are in place, the 403s should stop and the stack can assume the role in all three accounts.

---

## Repo Layout

```
.
├── .spacelift/
│   └── config.yml          # Spacelift stack config (project root, Terraform version)
├── modules/
│   └── cross-account-role/
│       ├── main.tf         # IAM role, trust policy, custom policy
│       ├── versions.tf     # required_providers (fixes "undefined provider" warning)
│       ├── variables.tf
│       └── outputs.tf      # role_arn
├── main.tf                 # four modules: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test
├── providers.tf            # Default provider + aliased providers (assume role per account)
├── variables.tf
├── outputs.tf              # role_arns, role_arn_list
├── versions.tf
├── terraform.tfvars.example
└── README.md
```

---

## Spacelift Setup (Step by Step)

1. **Create a stack** in Spacelift and connect this repository.
2. **Set the stack slug** (or name) so it matches the key under `stacks` in `.spacelift/config.yml` (e.g. `cross-account-role-stack`).
3. **Attach the AWS integration** that uses the **Sharedsvcs2** account (the one that will assume the cross-account roles).
4. **Set Terraform variables** (in the stack’s “Terraform variables” or via `terraform.tfvars` in the repo):
   - `sharedsvcs2_account_id` = SharedSvc2 account ID (e.g. `"975678945875"`). **Trust policy is always this account only.**
   - `target_accounts` = map with keys `dcli_sharedsvcs2`, `dcli_sandbox1`, `dcli_sandbox2`, `dcli_security_test` → account IDs.
5. **Run Plan / Apply.**  
   Spacelift will assume the execution role in each of the four accounts and create the IAM role (IAM Role + IAM Policy + Trust Policy) in each; trust policy is always SharedSvc2 only.

---

## Config and Variables

- **`terraform.tfvars.example`**  
  Copy to `terraform.tfvars` and set real account IDs (only account numbers):

  - `sharedsvcs2_account_id`: SharedSvc2 account ID (e.g. `"975678945875"`). Trust policy on the created role is always this account only.
  - `target_accounts`: map with keys `dcli_sharedsvcs2`, `dcli_sandbox1`, `dcli_sandbox2`, `dcli_security_test` → 12-digit AWS account IDs. Optionally set `spacelift_execution_role_name` if you use a different execution role name.

- **`.spacelift/config.yml`**  
  Sets project root and Terraform version for the stack. Adjust `terraform_version` if you need a different one.

---

## Outputs

After apply, the stack exposes:

- **`role_arns`**: Map of account key → role ARN (e.g. `dcli_sharedsvcs2`, `dcli_sandbox1`, `dcli_sandbox2`, `dcli_security_test`).
- **`role_arn_list`**: List of all created role ARNs.

Use these in Sharedsvcs2 (e.g. in other automation or IAM policies) when assuming these roles.

---

## How Sharedsvcs2 Assumes the Roles

From the **Sharedsvcs2** account, users or automation can assume the role in a target account, for example:

```bash
aws sts assume-role \
  --role-arn "arn:aws:iam::TARGET_ACCOUNT_ID:role/crossaccountrolewithsharedsvcs2" \
  --role-session-name "my-session"
```

Use the returned credentials to call APIs in Sandbox1, Sandbox2, or Security. The same role name and trust policy are used in all three accounts.

---

## Summary

- **One Spacelift stack** creates the **same IAM role** (IAM Role + IAM Policy + Trust Policy) in **four accounts**: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test.
- **Trust policy is always SharedSvc2 account only** — only SharedSvc2 can assume the role in every account.
- **Spacelift** manages the lifecycle (plan/apply/destroy) using one stack and the repo’s `.spacelift/config.yml`.
