# How Spacelift Executes This Stack in Multiple Accounts

Yes, this setup **will work from Spacelift** when the execution roles and trust are configured correctly. Here is how Spacelift runs Terraform across the four accounts.

---

## Execution flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Spacelift (one stack, one run)                                              │
│                                                                              │
│  1. Spacelift starts with ONE AWS integration                                │
│     (e.g. OIDC or static credentials for account A)                           │
│                                                                              │
│  2. Terraform runs with that identity (default provider = account A)         │
│                                                                              │
│  3. For each target account, Terraform calls sts:AssumeRole:                 │
│     • Assume role in dcli_sharedsvcs2 (975678945875)  → create IAM role there│
│     • Assume role in dcli_sandbox1    (529088296711)  → create IAM role there│
│     • Assume role in dcli_sandbox2    (687360398174)  → create IAM role there│
│     • Assume role in dcli_security_test (307946672793) → create IAM role there│
│                                                                              │
│  4. Each aliased provider uses the assumed-role credentials to create        │
│     the IAM role + policy + trust in that account.                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

- **One** Spacelift stack run = **one** Terraform plan/apply.
- **One** AWS integration in Spacelift = the **initial** credentials (account A).
- Terraform then **assumes** the same execution role name (e.g. `spacelift_iac`) in **each** of the four accounts.
- So Spacelift does **not** need four integrations; it needs **one** integration, and **four** roles (one per account) that trust that integration.

---

## What Spacelift needs

| Requirement | Details |
|-------------|--------|
| **One AWS integration** | In Spacelift, attach a single AWS integration (OIDC or static credentials) for the account that will **assume** the execution role in the other accounts. That can be dcli_sharedsvcs2 or any other “runner” account. |
| **Execution role in every account** | In **each** of the four accounts (dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test), an IAM role must exist with the name you set in `spacelift_execution_role_name` (e.g. `spacelift_iac`). |
| **Trust on the execution role** | In each of those four roles, the **trust policy** must allow the identity that Spacelift uses (the account from the AWS integration) to assume it. Otherwise you get **403** when Terraform tries to assume the role in that account. See `docs/fix-403-trust-policy.md`. |
| **Terraform variables** | In the stack (UI or `terraform.tfvars`): `sharedsvcs2_account_id`, `target_accounts` (all four keys: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test). Optionally `spacelift_execution_role_name` if you don’t use the default. |

---

## Will it work from Spacelift?

**Yes**, provided:

1. The Spacelift stack is tied to this repo and uses this project root (and optionally the stack name in `.spacelift/config.yml`).
2. **One** AWS integration is attached to the stack (account that will assume the four execution roles).
3. The **execution role** (e.g. `spacelift_iac`) exists in **all four** accounts and **trusts** that Spacelift identity (see 403 doc).
4. Variables are set so Terraform knows the four account IDs and (if needed) the execution role name.

Then:

- On **Plan** or **Apply**, Spacelift runs `terraform plan` / `terraform apply` once.
- Terraform uses the default provider (Spacelift’s integration) only to **call AssumeRole**.
- The four aliased providers (dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test) each assume the execution role in the corresponding account and create the IAM role there.

So **Spacelift executes in multiple accounts** by: one run, one integration, and Terraform assuming one role per account via the aliased AWS providers.
