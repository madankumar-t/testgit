# Fix 403 AssumeRole: Trust policy for Spacelift execution role in each account

## Account IDs (four accounts)

| Account              | Account ID   |
|----------------------|--------------|
| **dcli_sharedsvcs2** | 975678945875 |
| **dcli_sandbox1**    | 529088296711 |
| **dcli_sandbox2**    | 687360398174 |
| **dcli_security_test** | 307946672793 |

- **dcli_sharedsvcs2 (975678945875)** is the only account allowed to assume the **created** role (`crossaccountrolewithsharedsvcs2`) — **trust policy is always SharedSvc2 only**.
- Spacelift runs using one AWS integration (e.g. role `spacelift_iac`). This stack assumes that execution role in **all four** accounts to create the IAM role in each.
- **403** means the **execution** role (e.g. `spacelift_iac`) in that account does not trust the account Spacelift runs from.

---

## What to do

In **each** of the **four** accounts (dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test), set the **trust policy** of the role **`spacelift_iac`** (or your execution role name) so it allows the account where **Spacelift runs** to assume it.

**If Spacelift runs from Sandbox2 (687360398174)** — use the policy below as-is.  
**If Spacelift runs from Sharedsvcs2 (975678945875)** — replace `687360398174` with `975678945875` in the trust policy.

---

## Trust policy (copy this)

Use this as the **Trust policy** for the **execution** role (e.g. `spacelift_iac`) in **all four accounts**: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test.  
Replace `RUNNER_ACCOUNT_ID` with the account where your Spacelift AWS integration runs (e.g. `687360398174` or `975678945875`).

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::RUNNER_ACCOUNT_ID:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Example — Spacelift runs from Sandbox2 (687360398174):**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::687360398174:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Example — Spacelift runs from Sharedsvcs2 (975678945875):**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::975678945875:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

---

## Steps in AWS Console (per target account)

Apply in **all four accounts**: dcli_sharedsvcs2 (975678945875), dcli_sandbox1 (529088296711), dcli_sandbox2 (687360398174), dcli_security_test (307946672793):

1. Sign in to the target account.
2. Go to **IAM** → **Roles**.
3. Open the role **`spacelift_iac`** (create it if it does not exist).
4. Open the **Trust relationships** tab → **Edit trust policy**.
5. Paste the appropriate JSON above (using the account ID where Spacelift runs).
6. Save.

Repeat for all four accounts, then re-run Plan in Spacelift.
