variable "region" {
  description = "AWS region for provider configuration"
  type        = string
  default     = "us-east-1"
}

variable "sharedsvcs2_account_id" {
  description = "AWS account ID of Sharedsvcs2 (the account that will assume the roles)"
  type        = string
}

variable "target_accounts" {
  description = "Map of logical name to AWS account ID. Keys must be: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test. Trust policy in each account allows only SharedSvc2 to assume the role."
  type        = map(string)

  validation {
    condition     = toset(keys(var.target_accounts)) == toset(["dcli_sharedsvcs2", "dcli_sandbox1", "dcli_sandbox2", "dcli_security_test"])
    error_message = "target_accounts must have exactly these keys: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test."
  }
}

variable "spacelift_execution_role_name" {
  description = "Name of the IAM role that Spacelift assumes in each target account to create resources"
  type        = string
  default     = "SpaceliftExecutionRole"
}
