# Create the same IAM role (IAM Role + IAM Policy + Trust Policy) in four accounts via Spacelift.
# Trust policy is always SharedSvc2 account only (sharedsvcs2_account_id).
# Accounts: dcli_sharedsvcs2, dcli_sandbox1, dcli_sandbox2, dcli_security_test.

module "cross_account_role_dcli_sharedsvcs2" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.dcli_sharedsvcs2
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}

module "cross_account_role_dcli_sandbox1" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.dcli_sandbox1
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}

module "cross_account_role_dcli_sandbox2" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.dcli_sandbox2
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}

module "cross_account_role_dcli_security_test" {
  source = "./modules/cross-account-role"
  providers = {
    aws = aws.dcli_security_test
  }
  sharedsvcs2_account_id = var.sharedsvcs2_account_id
  role_name              = "crossaccountrolewithsharedsvcs2"
}
