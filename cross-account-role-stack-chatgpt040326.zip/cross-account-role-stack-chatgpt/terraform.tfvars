# Sharedsvcs2 account ID (the account that will assume the cross-account roles)
sharedsvcs2_account_id = "111111111111"

# Target accounts: logical name -> AWS account ID (only account numbers needed)
target_accounts = {
  sandbox1 = "222222222222"
  sandbox2 = "333333333333"
  security = "444444444444"
}

# Optional: role name Spacelift assumes in each target account (default: SpaceliftExecutionRole)
# spacelift_execution_role_name = "SpaceliftExecutionRole"
