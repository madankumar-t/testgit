
import json, boto3

def allowed(service, groups):
    if "admins" in groups:
        return True
    if "read-only" in groups and service in ["ec2","s3"]:
        return True
    return False

def lambda_handler(event, context):
    claims = event["requestContext"]["authorizer"]["claims"]
    groups = claims.get("cognito:groups","").split(",")
    qs = event.get("queryStringParameters") or {}
    service = qs.get("service","ec2")

    if not allowed(service, groups):
        return {"statusCode":403,"body":"Access denied"}

    return {
        "statusCode":200,
        "headers":{"Access-Control-Allow-Origin":"*"},
        "body":json.dumps({"service":service,"access":"granted","groups":groups})
    }
