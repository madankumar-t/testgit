
import { CognitoUserPool, AuthenticationDetails, CognitoUser } from "amazon-cognito-identity-js"
import { useState } from "react"

const API="REPLACE_API"
const pool=new CognitoUserPool({UserPoolId:"REPLACE_POOL",ClientId:"REPLACE_CLIENT"})

export default function App(){
  const [token,setToken]=useState(null)
  const [msg,setMsg]=useState("")

  const login=(u,p)=>{
    const user=new CognitoUser({Username:u,Pool:pool})
    const auth=new AuthenticationDetails({Username:u,Password:p})
    user.authenticateUser(auth,{onSuccess:r=>setToken(r.getIdToken().getJwtToken())})
  }

  const call=()=>{
    fetch(API+"?service=ec2",{headers:{Authorization:token}})
      .then(r=>r.text()).then(setMsg)
  }

  if(!token) return <button onClick={()=>login("admin","Temp123!")}>Login</button>

  return <div><button onClick={call}>Call API</button><pre>{msg}</pre></div>
}
