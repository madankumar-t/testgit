
# AWS Inventory Dashboard – Enterprise Deployment Guide

## Architecture
- S3 + CloudFront (React frontend)
- Cognito User Pool (Auth)
- Cognito Groups (RBAC)
- API Gateway (JWT Authorizer)
- Lambda (Inventory)
- IAM Roles (Least privilege)

---

## Cognito Groups → Access Model

| Group | Access |
|------|-------|
| admins | All services |
| read-only | EC2 + S3 only |

Group is evaluated in Lambda via JWT claims.

---

## IAM Roles

### 1. Lambda Execution Role (Auto-created by SAM)

Attached policies:
- EC2 read
- S3 read
- IAM read
- RDS read
- DynamoDB read
- Lambda read

### 2. Cognito Auth Role (Optional – future STS)
Not required for API Gateway JWT auth.

---

## Deployment Steps

### 1. Backend

```bash
cd backend
sam build
sam deploy --guided
```

Capture outputs:
- ApiUrl
- UserPoolId
- ClientId

---

### 2. Create Cognito Groups

```bash
aws cognito-idp create-group   --group-name admins   --user-pool-id <POOL_ID>

aws cognito-idp create-group   --group-name read-only   --user-pool-id <POOL_ID>
```

---

### 3. Create Users & Assign Groups

```bash
aws cognito-idp admin-create-user   --user-pool-id <POOL_ID>   --username admin   --temporary-password Temp123!

aws cognito-idp admin-add-user-to-group   --user-pool-id <POOL_ID>   --username admin   --group-name admins
```

---

### 4. Frontend

Edit `frontend-react/src/App.jsx`:
- API URL
- UserPoolId
- ClientId

```bash
npm install
npm run build
aws s3 sync dist/ s3://inventory-ui
```

---

## Production Hardening
- CloudFront OAC
- WAF
- HTTPS only
- Disable public S3
- Enable CloudWatch logs
