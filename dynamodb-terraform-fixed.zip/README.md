# Terraform DynamoDB – Regional or Global Tables (Fixed)

Supports:
- REGIONAL DynamoDB tables
- GLOBAL DynamoDB tables (Global Tables v2)

Switch with:
table_mode = "REGIONAL" | "GLOBAL"
